# src/notificaciones/core/api.py

import requests
from typing import Dict, List, Optional
from urllib.parse import urljoin

from notificaciones.core.config import load_config


class API:
    """
    Cliente mínimo para consumir la API de Smartlink (solo stats de latencia).
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)
        self.base = self.cfg.get("api.base_url", "").rstrip("/")

    def _get(self, endpoint: str, params: Dict[str, str]) -> Optional[dict]:
        """
        Hace GET contra la API y devuelve JSON si ok.
        """
        url = urljoin(self.base + "/", endpoint.lstrip("/"))
        try:
            r = requests.get(url, params=params, timeout=30)
            if r.status_code == 200:
                return r.json()
            print(f"❌ API {url} -> {r.status_code}: {r.text[:200]}")
        except Exception as e:
            print(f"❌ Error API {url}: {e}")
        return None

    def get_stats(
        self,
        start_date: str,
        end_date: str,
        limit: int = 1000,
        offset: int = 0,
        aprox_date: bool = True,
    ) -> List[dict]:
        """
        Obtiene estadísticas detalladas de latencia por equipo.
        """
        ep = self.cfg.get(
            "api.latencia.get_latencia_stats",
            "/latencia/get_latencia_stats",
        )
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit": str(limit),
            "offset": str(offset),
            "aprox_date": str(aprox_date).lower(),
        }
        data = self._get(ep, params)
        if isinstance(data, dict) and "data" in data:
            return data["data"] or []
        return data or []

    def get_stats_summary(self, start_date: str, end_date: str) -> dict:
        """
        Obtiene el resumen global de estadísticas de latencia.
        """
        ep = self.cfg.get(
            "api.latencia.get_latencia_stats_summary",
            "/latencia/get_latencia_stats_summary",
        )
        params = {"start_date": start_date, "end_date": end_date}
        data = self._get(ep, params)
        if isinstance(data, dict) and "data" in data and isinstance(data["data"], dict):
            return data["data"]
        return data or {}
