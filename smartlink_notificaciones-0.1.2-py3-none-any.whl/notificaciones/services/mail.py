# src/notificaciones/services/mail.py
# -*- coding: utf-8 -*-

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Dict, Optional

from notificaciones.core.config import load_config
from notificaciones.core.ai import get_openai_client, mensaje_chat_gpt


def _build_email_html_table(empresa: str, horas: int, stats_equipos: List[Dict], stats_global: Dict) -> str:
    """
    SOLO tabla/resumen HTML (determinístico). El texto 'intro' lo genera GPT aparte.
    """
    columnas = [
        ("tag", "Equipo"),
        ("ip", "IP"),
        ("marca", "Marca"),
        ("tipo", "Tipo"),
        ("promedio_latencia", "Prom. (ms)"),
        ("max_latencia", "Máx (ms)"),
        ("min_latencia", "Mín (ms)"),
        ("total_mediciones", "Mediciones"),
        ("latencia_100_200", "100-200"),
        ("latencia_mayor_200", ">200"),
        ("desconexiones", "Desconexiones"),
        ("porcentaje_latencia_alta", "% Alta"),
    ]

    def fmt(v, key):
        if v is None:
            return ""
        try:
            if key in {"promedio_latencia", "max_latencia", "min_latencia"}:
                return f"{float(v):.1f}"
            if key == "porcentaje_latencia_alta":
                return f"{float(v):.2f}%"
        except Exception:
            return v
        return v

    html = []

    # Resumen global
    html.append("<h3>Resumen global</h3><ul>")
    mapping = [
        ("total_ips", "Total de IPs"),
        ("total_mediciones", "Total de mediciones"),
        ("total_mediciones_validas", "Mediciones válidas (>0)"),
        ("desconexiones", "Desconexiones (≤0)"),
        ("promedio_general", "Promedio general (ms)"),
        ("max_global", "Máximo (ms)"),
        ("min_global", "Mínimo (ms)"),
        ("mediciones_altas", "Mediciones >100 ms"),
        ("porcentaje_latencia_alta", "% Latencia alta (sobre válidas)"),
    ]
    for key, label in mapping:
        if key in stats_global and stats_global[key] is not None:
            val = stats_global[key]
            try:
                if key in {"promedio_general", "max_global", "min_global"}:
                    val = f"{float(val):.1f}"
            except Exception:
                pass
            html.append(f"<li><b>{label}:</b> {val}</li>")
    html.append("</ul>")

    # Tabla por equipo
    html.append("<h3>Estadísticas por equipo</h3>")
    if not stats_equipos:
        html.append("<p>No hay datos disponibles.</p>")
    else:
        html.append(
            "<table border='1' cellpadding='6' cellspacing='0' "
            "style='border-collapse:collapse;font-size:13px;'>"
        )
        html.append("<thead style='background:#f2f2f2'><tr>")
        for _, header in columnas:
            html.append(f"<th>{header}</th>")
        html.append("</tr></thead><tbody>")

        for row in stats_equipos:
            html.append("<tr>")
            for key, _ in columnas:
                html.append(f"<td>{fmt(row.get(key), key)}</td>")
            html.append("</tr>")

        html.append("</tbody></table>")

    return "".join(html)


def _sanitize_gpt_html(s: Optional[str]) -> str:
    if not s:
        return ""
    # elimina bloques de código tipo ```html ...``` o ``` ...
    s = s.replace("```html", "").replace("```HTML", "").replace("```", "")
    return s.strip()

def _email_intro_with_gpt(empresa: str, stats_equipos: List[Dict], stats_global: Dict) -> Optional[str]:
    """
    Pide a GPT un párrafo/análisis breve (HTML) para abrir el reporte.
    - Sin código ni tablas.
    - Tono profesional, no alarmista si los % son bajos.
    """
    client = get_openai_client()
    if not client:
        return None

    # top 6 por % alta y, como respaldo, por >200ms
    equipos = stats_equipos or []
    def fnum(x): 
        try: return float(x or 0)
        except: return 0.0
    top_pct = sorted(equipos, key=lambda e: fnum(e.get("porcentaje_latencia_alta")), reverse=True)[:6]
    top_200 = sorted(equipos, key=lambda e: fnum(e.get("latencia_mayor_200")), reverse=True)[:6]

    resumen = {
        "empresa": empresa,
        "global": stats_global or {},
        "top_porcentaje": top_pct,
        "top_mayor_200ms": top_200,
    }

    prompt = (
        "Eres un asistente que redacta un *reporte* técnico breve en HTML (Chile, español) "
        "para abrir un correo. No uses tablas ni estilos inline. Usa <p>, <strong> y viñetas <ul><li> si ayuda. "
        "Debes: (1) dar una lectura general del estado; (2) mencionar 3-5 IPs/etiquetas más críticas "
        "si sus porcentajes altos son relevantes; (3) comentar marcas/tipos si hay patrón; "
        "y (4) cerrar con una recomendación sobria. Si los valores son bajos, sé optimista. "
        "NO devuelvas bloques de código como ```html. Devuelve solo HTML plano.\n\n"
        f"DATOS JSON:\n{resumen}\n"
    )

    html = mensaje_chat_gpt(client, prompt, is_windows=False)
    return _sanitize_gpt_html(html)



class MailService:
    """
    Servicio de envío de correos HTML.
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _cfg_email(self) -> dict:
        e = self.cfg.get("email", {})
        env_pwd = os.getenv("EMAIL_PASSWORD")
        if env_pwd:
            e["smtp_password"] = env_pwd

        required = ["remitente", "smtp_password", "destinatarios"]
        faltantes = [r for r in required if not e.get(r)]
        if faltantes:
            raise ValueError(f"Faltan campos en email config: {', '.join(faltantes)}")
        return e

    def send_html(self, subject: str, html: str) -> bool:
        e = self._cfg_email()
        remitente = e["remitente"]
        clave = e["smtp_password"]
        to = e["destinatarios"]
        cc = e.get("cc", [])
        server = e.get("smtp_server", "smtp.gmail.com")
        port = int(e.get("smtp_port", 587))

        msg = MIMEMultipart("alternative")
        msg["From"] = remitente
        msg["To"] = ", ".join(to)
        if cc:
            msg["Cc"] = ", ".join(cc)
        msg["Subject"] = subject
        msg.attach(MIMEText(html, "html"))

        try:
            smtp = smtplib.SMTP(server, port)
            smtp.starttls()
            smtp.login(remitente, clave)
            smtp.sendmail(remitente, to + cc, msg.as_string())
            smtp.quit()
            print(f"✅ Email enviado a {len(to)} destinatarios (+{len(cc)} cc)")
            return True
        except Exception as ex:
            print(f"❌ Error SMTP: {ex}")
            return False

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,                    # lo seguimos recibiendo para la CLI, pero NO lo mostramos
        stats_equipos: List[Dict],
        stats_global: Dict,
    ) -> bool:
        # Asunto: fijo, de turno. Si quieres la empresa en el asunto, descomenta la línea de abajo.
        subject_tpl = self.cfg.get("mensajes.email_subject", "Reporte del turno")
        # Forzar mayúscula inicial en empresa para cualquier uso en el HTML
        Empresa = (empresa[:1].upper() + empresa[1:]) if empresa else "Cliente"

        intro_html = _email_intro_with_gpt(Empresa, stats_equipos, stats_global) or ""
        tabla_html = _build_email_html_table(Empresa, horas, stats_equipos, stats_global)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"<h2>Reporte de latencia - {Empresa}</h2>"   # sin '(últimas Nh)'
            f"{intro_html}"
            f"{tabla_html}"
            "<br><p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )

        return self.send_html(subject_tpl, html)


