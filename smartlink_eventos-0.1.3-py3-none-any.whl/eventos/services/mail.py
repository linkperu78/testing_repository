import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Dict, Optional, Any
from datetime import datetime

from ..core.config import get_config_manager
from ..core.api_client import get_api_client
from ..core.chat_gpt import get_chatgpt_client
from ..utils.time_utils import get_iso_string_hours_ago, saludo_inicial_hora
from ..utils.message_utils import (
    clasificar_alertas,
    crear_tabla_html,
    guardar_html_archivo,
    validar_email_destinatarios
)


class MailService:
    """Servicio para envio de correos electronicos con alertas."""
    
    def __init__(self):
        """Inicializa el servicio de correo."""
        self.config_manager = get_config_manager()
        self.api_client = get_api_client()
        self.chatgpt_client = get_chatgpt_client()
    
    def enviar_correo_html(
        self,
        remitente: str,
        clave: str,
        destinatarios: List[str],
        con_copia: List[str],
        asunto: str,
        html: str,
        smtp_server: str = "smtp.gmail.com",
        smtp_puerto: int = 587
    ) -> bool:
        """
        Envia un correo electronico con contenido HTML.
        
        Args:
            remitente: Email del remitente
            clave: Contraseha SMTP del remitente
            destinatarios: Lista de emails destinatarios
            con_copia: Lista de emails en copia
            asunto: Asunto del correo
            html: Contenido HTML del correo
            smtp_server: Servidor SMTP
            smtp_puerto: Puerto SMTP
            
        Returns:
            bool: True si el envio fue exitoso
        """
        print("Enviando correo...")
        
        # Validar destinatarios
        if not validar_email_destinatarios(destinatarios):
            print("❌ Destinatarios principales invalidos")
    def enviar_estadisticas_por_email(
        self,
        empresa: str,
        hours_ago: int = 12,
        guardar_tabla: bool = True,
        asunto_personalizado: Optional[str] = None
    ) -> bool:
        """
        Proceso completo de envio de estadisticas de latencia por email.
        
        Args:
            empresa: Nombre de la empresa
            hours_ago: Horas hacia atras para buscar estadisticas
            guardar_tabla: Si True, guarda la tabla HTML en archivo
            asunto_personalizado: Asunto personalizado (opcional)
            
        Returns:
            bool: True si el envio fue exitoso
        """
        try:
            print(f"\n--- Iniciando envio de estadisticas por email para {empresa} ---")
            
            # Obtener configuracion
            email_config = self.obtener_configuracion_email()
            
            # Obtener estadisticas
            stats_equipos, stats_global = self.obtener_estadisticas_latencia(hours_ago)
            
            # Verificar si hay datos para enviar
            if not stats_equipos and not stats_global:
                print("ℹ️ No hay estadisticas de latencia para enviar por email")
                return True  # No es un error, simplemente no hay datos
            
            print(f"📊 Procesando estadisticas de {len(stats_equipos)} equipos")
            if stats_global:
                print(f"📊 Estadisticas globales: {stats_global.get('total_mediciones', 0)} mediciones")
            
            # Generar tabla HTML
            html_tabla_equipos = self.generar_tabla_estadisticas_html(
                stats_equipos, 
                guardar_tabla
            )
            
            # Generar mensaje del correo
            mensaje_html = self.generar_mensaje_correo_stats(
                html_tabla_equipos, 
                stats_global, 
                empresa, 
                hours_ago
            )
            
            # Configurar asunto
            if asunto_personalizado:
                asunto = asunto_personalizado
            else:
                asunto = f"Estadísticas de latencia - {empresa} ({hours_ago}h)"
            
            # Enviar correo
            exito = self.enviar_correo_html(
                remitente=email_config["remitente"],
                clave=email_config["smtp_password"],
                destinatarios=email_config["destinatarios"],
                con_copia=email_config.get("con_copia", []),
                asunto=asunto,
                html=mensaje_html,
                smtp_server=email_config.get("smtp_server", "smtp.gmail.com"),
                smtp_puerto=email_config.get("smtp_puerto", 587)
            )
            
            if exito:
                print(f"✅ Estadisticas enviadas exitosamente por email para {empresa}")
            else:
                print(f"❌ Fallo el envio de estadisticas por email para {empresa}")
            
            return exito
            
        except Exception as e:
            print(f"❌ Error en proceso de envio de estadisticas por email: {e}")
            return False
        
        if not validar_email_destinatarios(con_copia):
            print("❌ Destinatarios en copia invalidos")
            return False
        
        try:
            # Crear mensaje
            mensaje = MIMEMultipart("alternative")
            mensaje["From"] = remitente
            mensaje["To"] = ", ".join(destinatarios)
            mensaje["Cc"] = ", ".join(con_copia)
            mensaje["Subject"] = asunto
            
            # Adjuntar HTML al mensaje
            mensaje.attach(MIMEText(html, "html"))
            
            # Configurar servidor SMTP
            servidor = smtplib.SMTP(smtp_server, smtp_puerto)
            servidor.starttls()
            
            print(f"Conectando con {smtp_server}:{smtp_puerto} como {remitente}")
            servidor.login(remitente, clave)
            
            # Enviar email
            todos_destinatarios = destinatarios + con_copia
            servidor.sendmail(remitente, todos_destinatarios, mensaje.as_string())
            servidor.quit()
            
            print("✅ Correo HTML enviado con exito")
            print(f"📧 Enviado a: {len(destinatarios)} destinatarios principales")
            print(f"📧 Copia a: {len(con_copia)} destinatarios")
            
            return True
            
        except smtplib.SMTPAuthenticationError:
            print("❌ Error de autenticacion SMTP - Verifica email y contraseha")
            return False
        except smtplib.SMTPRecipientsRefused as e:
            print(f"❌ Destinatarios rechazados: {e}")
            return False
        except smtplib.SMTPServerDisconnected:
            print("❌ Servidor SMTP desconectado")
            return False
        except Exception as e:
            print(f"❌ Error al enviar el correo: {e}")
            return False
    
    def obtener_alertas_urgentes(
        self, 
        hours_ago: int = 1, 
        minutes_ago: int = 5
    ) -> tuple[List[Dict], List[Dict]]:
        """
        Obtiene alertas urgentes desde la API.
        
        Args:
            hours_ago: Horas hacia atras para buscar
            minutes_ago: Minutos hacia atras para buscar
            
        Returns:
            tuple: (senhal_deficientes, interferencias)
        """
        # Calcular fecha desde cuando buscar
        fecha_busqueda = get_iso_string_hours_ago(hours=hours_ago, minutes=minutes_ago)
        
        # Obtener alertas urgentes
        alertas = self.api_client.get_eventos_urgentes(fecha_busqueda)
        
        if not alertas:
            print("No hay alertas urgentes para email")
            return [], []
        
        print(f"Encontradas {len(alertas)} alertas urgentes para email")
        
        # Clasificar alertas
    def obtener_estadisticas_latencia(
        self, 
        hours_ago: int = 12
    ) -> tuple[List[Dict], Optional[Dict]]:
        """
        Obtiene estadisticas de latencia desde las nuevas APIs.
        
        Args:
            hours_ago: Horas hacia atras para buscar estadisticas
            
        Returns:
            tuple: (estadisticas_por_equipo, estadisticas_globales)
        """
        from ..utils.time_utils import get_iso_string_hours_ago, get_current_iso_string
        
        # Calcular rango de fechas
        start_date = get_iso_string_hours_ago(hours=hours_ago)
        end_date = get_current_iso_string()
        
        print(f"📊 Obteniendo estadisticas de latencia para email desde {start_date} hasta {end_date}")
        
        # Obtener estadisticas por equipo
        stats_equipos = self.api_client.get_latencia_stats(start_date, end_date)
        
        # Obtener estadisticas globales
        stats_global = self.api_client.get_latencia_stats_summary(start_date, end_date)
        
        if not stats_equipos:
            print("No se encontraron estadisticas de equipos para email")
            stats_equipos = []
        else:
            print(f"Encontradas estadisticas de {len(stats_equipos)} equipos para email")
        
        if not stats_global:
            print("No se encontraron estadisticas globales para email")
        else:
            print(f"Estadisticas globales para email: {stats_global.get('total_mediciones', 0)} mediciones")
        
        return stats_equipos, stats_global
    
    def generar_tabla_estadisticas_html(
        self, 
        stats_equipos: List[Dict],
        guardar_archivo: bool = True
    ) -> str:
        """
        Genera tabla HTML con estadisticas de latencia por equipo.
        
        Args:
            stats_equipos: Lista de estadisticas por equipo
            guardar_archivo: Si True, guarda la tabla en archivo HTML
            
        Returns:
            str: Tabla HTML generada
        """
        print(f"Creando tabla de estadisticas para {len(stats_equipos)} equipos")
        
        if not stats_equipos:
            html = "<h2>Estadísticas de Latencia</h2><p>No hay datos para mostrar.</p>"
        else:
            # Columnas para la tabla de estadisticas
            columnas = [
                "tag", "ip", "marca", "tipo", 
                "promedio_latencia", "max_latencia", "min_latencia",
                "total_mediciones", "latencia_100_200", "latencia_mayor_200",
                "porcentaje_latencia_alta"
            ]
            
            # Encabezado
            html = "<h2 style='color:#2E86C1;'>Estadísticas de Latencia por Equipo</h2>"
            html += "<table border='1' cellpadding='6' cellspacing='0' style='border-collapse: collapse; font-size: 13px; font-family: Arial;'>"
            html += "<thead style='background-color:#f2f2f2;'><tr>"
            
            # Headers de tabla
            headers = {
                "tag": "Equipo",
                "ip": "IP",
                "marca": "Marca", 
                "tipo": "Tipo",
                "promedio_latencia": "Prom. (ms)",
                "max_latencia": "Max (ms)",
                "min_latencia": "Min (ms)",
                "total_mediciones": "Mediciones",
                "latencia_100_200": "Lat 100-200",
                "latencia_mayor_200": "Lat >200",
                "porcentaje_latencia_alta": "% Alta"
            }
            
            for col in columnas:
                html += f"<th>{headers.get(col, col)}</th>"
            html += "</tr></thead><tbody>"
            
            # Filas de datos
            for equipo in stats_equipos:
                html += "<tr>"
                for col in columnas:
                    valor = equipo.get(col, "")
                    
                    # Formatear valores numericos
                    if col in ["promedio_latencia", "max_latencia", "min_latencia"] and valor:
                        valor = f"{float(valor):.1f}"
                    elif col == "porcentaje_latencia_alta" and valor:
                        valor = f"{float(valor):.1f}%"
                    elif valor is None:
                        valor = "N/A"
                    
                    html += f"<td>{valor}</td>"
                html += "</tr>"
            
            html += "</tbody></table><br>"
        
        # Guardar archivo si se solicita
        if guardar_archivo:
            guardar_html_archivo(html, "tabla_estadisticas_latencia.html")
        
        return html
    
    def generar_tablas_html(
        self, 
        senhal_deficientes: List[Dict], 
        interferencias: List[Dict],
        guardar_archivos: bool = True
    ) -> Dict[str, str]:
        """
        Genera tablas HTML para las alertas.
        
        Args:
            senhal_deficientes: Lista de alertas de senhal deficiente
            interferencias: Lista de alertas de interferencias
            guardar_archivos: Si True, guarda las tablas en archivos HTML
            
        Returns:
            dict: Diccionario con las tablas HTML generadas
        """
        # Generar tablas HTML
        tabla_senhales = crear_tabla_html(senhal_deficientes, "senhal deficiente")
        tabla_interferencias = crear_tabla_html(interferencias, "interferencias")
        
        # Guardar archivos si se solicita
        if guardar_archivos:
            guardar_html_archivo(tabla_senhales, "tabla_poor_latency.html")
            guardar_html_archivo(tabla_interferencias, "tabla_interferencias.html")
        
        return {
            "tabla_senhales": tabla_senhales,
            "tabla_interferencias": tabla_interferencias
        }
    
    def generar_mensaje_correo(
        self, 
        html_tablas: Dict[str, str], 
        empresa: str
    ) -> str:
        """
        Genera el mensaje del correo usando ChatGPT.
        
        Args:
            html_tablas: Diccionario con tablas HTML
            empresa: Nombre de la empresa
            
        Returns:
            str: Mensaje HTML para el correo
        """
    def generar_mensaje_correo_stats(
        self, 
        html_tabla_equipos: str,
        stats_global: Optional[Dict],
        empresa: str,
        periodo_horas: int = 12
    ) -> str:
        """
        Genera el mensaje del correo usando estadisticas con ChatGPT.
        
        Args:
            html_tabla_equipos: Tabla HTML con estadisticas por equipo
            stats_global: Estadisticas globales del sistema
            empresa: Nombre de la empresa
            periodo_horas: Periodo de horas analizado
            
        Returns:
            str: Mensaje HTML para el correo
        """
        return self.chatgpt_client.generar_mensaje_correo_stats(
            html_tabla_equipos, 
            stats_global or {}, 
            empresa, 
            periodo_horas
        )
    
    def obtener_configuracion_email(self) -> Dict[str, Any]:
        """
        Obtiene la configuracion de email desde el config.
        
        Returns:
            dict: Configuracion de email
        """
        email_config = self.config_manager.get_email_config()
        
        # Validar configuracion requerida
        campos_requeridos = ["remitente", "smtp_password", "destinatarios"]
        for campo in campos_requeridos:
            if campo not in email_config:
                raise ValueError(f"Campo requerido '{campo}' no encontrado en configuracion de email")
        
        return email_config
    
    def enviar_alertas_por_email(
        self,
        empresa: str,
        hours_ago: int = 1,
        minutes_ago: int = 5,
        guardar_tablas: bool = True,
        asunto_personalizado: Optional[str] = None
    ) -> bool:
        """
        Proceso completo de envio de alertas por email.
        
        Args:
            empresa: Nombre de la empresa
            hours_ago: Horas hacia atras para buscar alertas
            minutes_ago: Minutos hacia atras para buscar alertas
            guardar_tablas: Si True, guarda las tablas HTML en archivos
            asunto_personalizado: Asunto personalizado (opcional)
            
        Returns:
            bool: True si el envio fue exitoso
        """
        try:
            print(f"\n--- Iniciando envio de alertas por email para {empresa} ---")
            
            # Obtener configuracion
            email_config = self.obtener_configuracion_email()
            
            # Obtener alertas urgentes
            senhal_deficientes, interferencias = self.obtener_alertas_urgentes(hours_ago, minutes_ago)
            
            # Verificar si hay alertas para enviar
            total_alertas = len(senhal_deficientes) + len(interferencias)
            if total_alertas == 0:
                print("ℹ️ No hay alertas para enviar por email")
                return True  # No es un error, simplemente no hay alertas
            
            print(f"📊 Procesando {len(senhal_deficientes)} alertas de senhal deficiente")
            print(f"📊 Procesando {len(interferencias)} alertas de interferencias")
            
            # Generar tablas HTML
            html_tablas = self.generar_tablas_html(
                senhal_deficientes, 
                interferencias, 
                guardar_tablas
            )
            
            # Generar mensaje del correo
            mensaje_html = self.generar_mensaje_correo(html_tablas, empresa)
            
            # Configurar asunto
            if asunto_personalizado:
                asunto = asunto_personalizado
            else:
                asunto = f"Alertas y alarmas de {empresa}"
            
            # Enviar correo
            exito = self.enviar_correo_html(
                remitente=email_config["remitente"],
                clave=email_config["smtp_password"],
                destinatarios=email_config["destinatarios"],
                con_copia=email_config.get("con_copia", []),
                asunto=asunto,
                html=mensaje_html,
                smtp_server=email_config.get("smtp_server", "smtp.gmail.com"),
                smtp_puerto=email_config.get("smtp_puerto", 587)
            )
            
            if exito:
                print(f"✅ Alertas enviadas exitosamente por email para {empresa}")
            else:
                print(f"❌ Fallo el envio de email para {empresa}")
            
            return exito
            
        except Exception as e:
            print(f"❌ Error en proceso de envio de email: {e}")
            return False
    
    def validar_configuracion_email(self) -> bool:
        """
        Valida que la configuracion de email sea correcta.
        
        Returns:
            bool: True si la configuracion es valida
        """
        try:
            email_config = self.obtener_configuracion_email()
            
            # Validar remitente
            if not email_config.get("remitente"):
                print("❌ Remitente no configurado")
                return False
            
            # Validar contraseha
            if not email_config.get("smtp_password"):
                print("❌ Contraseha SMTP no configurada")
                return False
            
            # Validar destinatarios
            destinatarios = email_config.get("destinatarios", [])
            if not destinatarios:
                print("❌ No hay destinatarios configurados")
                return False
            
            if not validar_email_destinatarios(destinatarios):
                print("❌ Destinatarios principales invalidos")
                return False
            
            # Validar destinatarios en copia (opcional)
            con_copia = email_config.get("con_copia", [])
            if con_copia and not validar_email_destinatarios(con_copia):
                print("❌ Destinatarios en copia invalidos")
                return False
            
            print("✅ Configuracion de email valida")
            return True
            
        except Exception as e:
            print(f"❌ Error validando configuracion de email: {e}")
            return False
    
    def obtener_estadisticas_configuracion(self) -> Dict[str, Any]:
        """
        Obtiene estadisticas de la configuracion de email.
        
        Returns:
            dict: Estadisticas de configuracion
        """
        try:
            email_config = self.obtener_configuracion_email()
            
            return {
                "remitente": email_config.get("remitente", "No configurado"),
                "total_destinatarios": len(email_config.get("destinatarios", [])),
                "total_con_copia": len(email_config.get("con_copia", [])),
                "smtp_server": email_config.get("smtp_server", "smtp.gmail.com"),
                "smtp_puerto": email_config.get("smtp_puerto", 587),
                "configuracion_valida": self.validar_configuracion_email()
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "configuracion_valida": False
            }


# Instancia global del servicio
_mail_service: Optional[MailService] = None


def get_mail_service() -> MailService:
    """
    Retorna la instancia global del servicio de correo.
    
    Returns:
        MailService: Instancia del servicio
    """
    global _mail_service
    
    if _mail_service is None:
        _mail_service = MailService()
    
    return _mail_service