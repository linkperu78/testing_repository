# src/notificaciones/services/mail.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Dict, List, Optional, Tuple

from notificaciones.core.config import load_config, Config
from notificaciones.core.ai import get_openai_client, mensaje_chat_gpt


# =========================
# Aliases / Normalización
# =========================

def _get_first(d: dict, keys: List[str], default=""):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return default


def _fmt_unit(val, unit: str) -> str:
    if val in ("", None):
        return ""
    try:
        v = float(val)
    except Exception:
        return str(val)
    return f"{v:.1f} {unit}"


def _suffix_for_metric(metric: str) -> str:
    return {"snr_h": "_h", "snr_v": "_v", "rx": "_rx"}.get(metric, "")


def _aliases_for_metric(metric: str) -> Dict[str, List[str]]:
    """
    Alias robustos por métrica. Metadatos (ip, tag, marca, rol, tipo, total_mediciones)
    NO llevan sufijo. Valores numéricos SÍ llevan sufijo (en SNR/RX).
    """
    suf = _suffix_for_metric(metric)

    base = {
        # metadatos (sin sufijo)
        "tag":   ["tag", "equipo", "nombre", "name"],
        "ip":    ["ip", "direccion_ip"],
        "marca": ["marca", "brand"],
        "rol":   ["rol", "role"],
        "tipo":  ["tipo", "type"],
        "total_mediciones": ["total_mediciones", "total_samples", "count"],

        # valores principales (pueden tener sufijo en SNR/RX)
        "promedio": ["promedio", "prom", "avg", "promedio_latencia"],
        "maximo":   ["maximo", "max", "max_latencia"],
        "minimo":   ["minimo", "min", "min_latencia"],

        # rangos / conteos
        "obs":  ["observacion", "en_observacion", "obs", "count_obs", "rango_medio", "medio"],
        "crit": ["critico", "crit", "count_crit", "rango_bajo", "bajo"],

        # % no óptimos (si llega)
        "pct_no_opt": ["porcentaje_no_optimos", "%_no_optimos", "pct_no_optimos"],
    }

    if metric == "latencia":
        # latencia sin sufijos para valores y con nombres especiales para rangos
        base["obs"]  = ["latencia_100_200", "count_100_200", "entre_100_200"]
        base["crit"] = ["latencia_mayor_200", "count_mayor_200", "mayor_200"]
        return base

    # SNR-H / SNR-V / RX: valores principales y rangos con sufijo
    if suf:
        base["promedio"] = [f"promedio{suf}", f"prom{suf}", f"avg{suf}"] + base["promedio"]
        base["maximo"]   = [f"max{suf}", f"maximo{suf}"] + base["maximo"]
        base["minimo"]   = [f"min{suf}", f"minimo{suf}"] + base["minimo"]

        base["obs"]  = [f"total_alertas{suf}", f"alertas{suf}"] + base["obs"]
        base["crit"] = [f"total_alarmas{suf}", f"alarmas{suf}"] + base["crit"]

        base["pct_no_opt"] = [f"porcentaje_no_optimos{suf}", f"%_no_optimos{suf}"] + base["pct_no_opt"]

    return base


def _units_for_metric(metric: str) -> str:
    if metric == "rx":
        return "dBm"
    if metric in ("snr_h", "snr_v"):
        return "dB"
    return "ms"


def _range_headers(metric: str) -> Tuple[str, str]:
    if metric == "latencia":
        return ("100–200 ms", ">200 ms")
    if metric in ("snr_h", "snr_v"):
        return ("16–20 dB", "0–15 dB")
    if metric == "rx":
        return ("−80..−70 dBm", "−90..−80 dBm")
    return ("", "")


def _metric_label(metric: str) -> str:
    return {
        "latencia": "Latencia",
        "snr_h": "SNR-H",
        "snr_v": "SNR-V",
        "rx": "RX",
    }.get(metric, metric)


def _join_with_y(labels: List[str]) -> str:
    labels = [l for l in labels if l]
    if not labels:
        return ""
    if len(labels) == 1:
        return labels[0]
    return ", ".join(labels[:-1]) + " y " + labels[-1]


# =========================
# Cálculo de “problemáticos”
# =========================

def _pct_problematico(row: dict, metric: str) -> float:
    """
    Devuelve % no óptimos para la fila. Usa porcentaje_no_optimos_* si existe.
    Si no, calcula: (alertas + alarmas) / total_mediciones * 100.
    Para latencia usa (100-200 + >200) / total_mediciones * 100.
    """
    aliases = _aliases_for_metric(metric)

    # 1) Si viene porcentaje directo
    pct_key = _get_first(row, aliases.get("pct_no_opt", []), None)
    print("[DEBUG] pct_key de metrica ", metric, " es ", pct_key)
    if pct_key not in (None, ""):
        try:
            return float(pct_key)
        except Exception:
            pass

    total = _get_first(row, aliases["total_mediciones"], 0) or 0
    if not total:
        return 0.0
    try:
        obs = float(_get_first(row, aliases["obs"], 0) or 0)
        crit = float(_get_first(row, aliases["crit"], 0) or 0)
        return (obs + crit) * 100.0 / float(total)
    except Exception:
        return 0.0


def _is_problematic(row: dict, metric: str, threshold_pct: float) -> bool:
    return _pct_problematico(row, metric) >= float(threshold_pct)


# =========================
# Render de tablas FULL
# =========================

def _render_metric_table(metric: str, rows: List[dict]) -> str:
    """
    Tabla HTML para una métrica, mostrando lo que venga en rows (sin filtrar por umbral).
    """
    title = _metric_label(metric)
    unit = _units_for_metric(metric)
    h_obs, h_crit = _range_headers(metric)
    aliases = _aliases_for_metric(metric)

    if not rows:
        return f"<h3>{title}</h3><p>No hay datos disponibles para esta métrica.</p>"

    html = [f"<h3>{title}</h3>"]
    html.append("<table border='0' cellspacing='0' cellpadding='6' style='width:100%;border-collapse:collapse'>")
    html.append("<thead><tr>"
                "<th style='text-align:left'>Tag</th>"
                "<th style='text-align:left'>IP</th>"
                f"<th style='text-align:right'>Promedio ({unit})</th>"
                f"<th style='text-align:right'>Máximo ({unit})</th>"
                f"<th style='text-align:right'>Mínimo ({unit})</th>"
                f"<th style='text-align:right'>{h_obs}</th>"
                f"<th style='text-align:right'>{h_crit}</th>"
                "<th style='text-align:left'>Marca</th>"
                "<th style='text-align:left'>Rol</th>"
                "<th style='text-align:left'>Tipo</th>"
                "</tr></thead><tbody>")

    for r in rows:
        tag   = _get_first(r, aliases["tag"])
        ip    = _get_first(r, aliases["ip"])
        prom  = _fmt_unit(_get_first(r, aliases["promedio"]), unit)
        maxi  = _fmt_unit(_get_first(r, aliases["maximo"]),   unit)
        mini  = _fmt_unit(_get_first(r, aliases["minimo"]),   unit)
        obs   = _get_first(r, aliases["obs"], "")
        crit  = _get_first(r, aliases["crit"], "")
        marca = _get_first(r, aliases["marca"])
        rol   = _get_first(r, aliases["rol"])
        tipo  = _get_first(r, aliases["tipo"])

        html.append("<tr>"
                    f"<td>{tag}</td>"
                    f"<td>{ip}</td>"
                    f"<td style='text-align:right'>{prom}</td>"
                    f"<td style='text-align:right'>{maxi}</td>"
                    f"<td style='text-align:right'>{mini}</td>"
                    f"<td style='text-align:right'>{obs}</td>"
                    f"<td style='text-align:right'>{crit}</td>"
                    f"<td>{marca}</td>"
                    f"<td>{rol}</td>"
                    f"<td>{tipo}</td>"
                    "</tr>")

    html.append("</tbody></table>")
    return "\n".join(html)


# =========================
# IA: prompts
# =========================

def _read_prompt_file(path: Optional[str]) -> Optional[str]:
    if not path:
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return None


def _make_intro_with_ai(
    empresa: str,
    hours: int,
    metrics: List[str],
    stats_by_metric: Dict[str, List[dict]],
    metrics_problem: List[str],
    metrics_ok: List[str],
    prompt_file: Optional[str],
) -> str:
    """
    Genera la introducción con IA. Si no hay problemas o no hay cliente/clave,
    devuelve un texto simple (fallback).
    """

    # Etiquetas legibles y con conector "y"
    labels_all = _join_with_y([_metric_label(m) for m in metrics])
    labels_bad = _join_with_y([_metric_label(m) for m in metrics_problem]) or "ninguna"
    labels_ok  = _join_with_y([_metric_label(m) for m in metrics_ok]) or "ninguna"


    # 1) Fallback DIRECTO si NO hay métricas con problemas
    if not metrics_problem:
        # Mensaje estándar solicitado
        return f"<p>Equipos con {labels_all} dentro del rango estándar Operacional.</p>"

    # 2) Intentar con IA si hay problemas
    base_prompt = _read_prompt_file(prompt_file) or (
        "Eres un asistente que redacta un reporte breve en HTML para correo (Chile, español). "
        "Este reporte es generado por Smartlink, un software de HC-GROUP para monitoreo de equipos de telecomunicaciones "
        "en faenas mineras. El reporte corresponde al último turno. "
        "La empresa se llama HC-GROUP y siempre debe escribirse en mayúscula. "
        "Escribe SIEMPRE las unidades: ms, dB, dBm. "
        "Si solo hay problemas en algunas métricas, di explícitamente que las otras se mantienen dentro del rango estándar operacional, "
        "mencionandolo textualmente de esta forma: 'Equipos con <métricas> dentro del rango estándar Operacional.' "
        "No repitas tablas ni títulos; solo redacta 2–4 líneas de contexto y hallazgos."
    )

  

    datos = {
        "empresa": empresa.capitalize(),
        "horas": hours,
        "metricas_evaluadas": [_metric_label(m) for m in metrics],
        "metricas_con_problemas": [_metric_label(m) for m in metrics_problem],
        "metricas_ok": [_metric_label(m) for m in metrics_ok],
    }

    print("[DEBUG] metricas con problemas:", metrics_problem)
    print("[DEBUG] Datos para prompt IA:", datos)


    prompt = (
        f"{base_prompt}\n\n"
        f"Resumen del turno para {empresa.capitalize()} (últimas {hours} h).\n"
        f"Métricas evaluadas: {labels_all}.\n"
        f"Métricas con condiciones a observar: {labels_bad}.\n"
        f"Métricas dentro del rango estándar operacional: {labels_ok}.\n\n"
        f"JSON de apoyo (no cites literal): {datos}\n\n"
        "Devuelve SOLO HTML de párrafo(s) cortos, sin tablas. No uses bloques ```html ni títulos."
    )

    client = get_openai_client()
    if client is None:
        # Fallback sin IA si falta la clave/cliente
        return (
            f"<p>Durante el último turno (últimas {hours} h) se observaron condiciones a "
            f"monitorear en: {labels_bad}. El resto de las métricas ({labels_ok}) se mantiene "
            f"dentro del rango estándar operacional.</p>"
        )

    text = mensaje_chat_gpt(client, prompt, model="gpt-4o-mini", max_tokens=700)
    return f"<p>{text}</p>"


# =========================
# Envío de correo
# =========================

class MailService:
    def __init__(self, config_path: Optional[str] = None):
        self.cfg: Config = load_config(config_path)

    def _smtp_info(self):
        e = self.cfg.get("email", {})
        return (
            e.get("smtp_server"),
            int(e.get("smtp_puerto", 587)),
            e.get("remitente"),
            e.get("smtp_password"),
            e.get("destinatarios", []),
            e.get("con_copia", []),
        )

    # -----------------------

    def enviar_reporte_multi(
        self,
        empresa: str,
        hours: int,
        stats_by_metric: Dict[str, List[dict]],
        metrics: List[str],
        thresholds: Dict[str, float],
        full: bool = False,
        prompt_file: Optional[str] = None,
    ) -> bool:
        """
        Construye y envía el correo con:
        - Intro (IA opcional)
        - Si full=True: tablas por métrica (siempre)
        - Si full=False: solo listado breve de hasta 5 equipos "problemáticos"
        """
        empresa_cap = empresa.capitalize()
        labels_all = [ _metric_label(m) for m in metrics ]

        # 1) métrica(s) con problemas vs OK
        metrics_problem: List[str] = []
        metrics_ok: List[str] = []

        for m in metrics:
            th = float(thresholds.get(f"threshold_pct_{m}", thresholds.get("threshold_pct_latencia", 10.0)))
            print("[DEBUG] Metrica: ", m, "Threshold: ", th)
            rows = stats_by_metric.get(m) or []
            any_bad = any(_is_problematic(r, m, th) for r in rows)
            if any_bad:
                metrics_problem.append(m)
            else:
                metrics_ok.append(m)

        # 2) Intro
        intro_html = _make_intro_with_ai(
            empresa=empresa_cap,
            hours=hours,
            metrics=metrics,
            stats_by_metric=stats_by_metric,
            metrics_problem=metrics_problem,
            metrics_ok=metrics_ok,
            prompt_file=prompt_file,
        )

        # 3) Cuerpo por modo
        body_parts: List[str] = []
        if full:
            # Tablas por cada métrica, sin filtrar por umbral
            for m in metrics:
                rows = stats_by_metric.get(m) or []
                body_parts.append(_render_metric_table(m, rows))
        else:
            # Listado breve de equipos críticos (hasta 5 por métrica problemática)
            blocks = []
            for m in metrics_problem:
                rows = stats_by_metric.get(m) or []
                th = float(thresholds.get(f"threshold_pct_{m}", 10.0))
                # ordenar por % problemático desc
                def _key(row): return _pct_problematico(row, m)
                top = sorted(rows, key=_key, reverse=True)[:5]
                if not top:
                    continue
                unit = _units_for_metric(m)
                aliases = _aliases_for_metric(m)
                label = _metric_label(m)
                lines = []
                for r in top:
                    tag  = _get_first(r, aliases["tag"])
                    ip   = _get_first(r, aliases["ip"])
                    maxi = _fmt_unit(_get_first(r, aliases["maximo"]), unit)
                    prom = _fmt_unit(_get_first(r, aliases["promedio"]), unit)
                    marca= _get_first(r, aliases["marca"])
                    rol  = _get_first(r, aliases["rol"])
                    tipo = _get_first(r, aliases["tipo"])
                    lines.append(
                        f"<li><b>{tag}</b> ({ip}) — <b>[{label}]</b> Máx: {maxi} | Prom: {prom} | Marca: {marca} | Rol: {rol} | Tipo: {tipo}</li>"
                    )
                blocks.append(f"<p><b>{label}:</b></p><ul>{''.join(lines)}</ul>")
            print("[DEBUG] bloques problemáticos:", blocks)
            if not blocks:
                # Sin críticos en ninguna -> mensaje estándar
                body_parts.append(
                    f"<p>Equipos con {_join_with_y(labels_all)} dentro del rango estándar operacional.</p>"
                )
            else:
                # Además agregar nota de métricas OK si existen
                body_parts.extend(blocks)
                if metrics_ok:
                    body_parts.append(
                        f"<p>Para {_join_with_y([_metric_label(x) for x in metrics_ok])} "
                        "se mantienen dentro del rango estándar operacional.</p>"
                    )

        html_body = (
            f"<h2>Reporte del turno - {empresa_cap}</h2>"
            f"{intro_html}"
            + "\n".join(body_parts)
            + "<p style='color:#666;font-size:12px'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
        )

        subject_tpl = self.cfg.get("mensajes.templates.email_subject", "Reporte del turno - {empresa}")
        subject = subject_tpl.format(empresa=empresa_cap)

        return self._send_email_html(subject, html_body)

    # -----------------------

    def _send_email_html(self, subject: str, html: str) -> bool:
        smtp_server, smtp_port, remitente, smtp_password, destinatarios, cc = self._smtp_info()

        if not remitente or not smtp_server:
            print("❌ Config de email incompleta.")
            return False

        to_list = list(destinatarios or [])
        cc_list = list(cc or [])
        all_rcpt = to_list + cc_list
        if not all_rcpt:
            print("❌ No hay destinatarios.")
            return False

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = remitente
        msg["To"] = ", ".join(to_list)
        if cc_list:
            msg["Cc"] = ", ".join(cc_list)

        msg.attach(MIMEText(html, "html", "utf-8"))

        try:
            with smtplib.SMTP(smtp_server, smtp_port, timeout=30) as s:
                s.starttls()
                if smtp_password:
                    s.login(remitente, smtp_password)
                s.sendmail(remitente, all_rcpt, msg.as_string())
            print(f"✅ Email enviado a {len(all_rcpt)} destinatarios")
            return True
        except Exception as e:
            print(f"❌ Error enviando email: {e}")
            return False
