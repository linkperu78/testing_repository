# src/notificaciones/services/whatsapp.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import subprocess
from typing import List, Dict, Optional

from notificaciones.core.config import load_config

DEFAULT_THRESHOLD_CRITICO = 10.0
MAX_CRITICOS = 5
MAX_MSG_LEN = 1200
MUDSLIDE_BIN = "/usr/local/bin/mudslide"

# -------------------- mapeos por métrica --------------------

METRIC_LABEL = {
    "latencia": "Latencia",
    "snr_h": "SNR-H",
    "snr_v": "SNR-V",
    "rx": "RX",
}

METRIC_UNITS = {
    "latencia": "ms",
    "snr_h": "dB",
    "snr_v": "dB",
    "rx": "dBm",
}

def _metric_fields(metric: str) -> Dict[str, str]:
    """
    Nombres de campos esperados en los datos devueltos por la API por métrica.
    """
    if metric == "latencia":
        return {
            "avg": "promedio_latencia",
            "max": "max_latencia",
            "min": "min_latencia",
            "obs": "latencia_100_200",     # recuento 100–200 ms
            "crit": "latencia_mayor_200",  # recuento >200 ms
            "pct": "porcentaje_latencia_alta",
        }
    if metric == "snr_h":
        return {
            "avg": "promedio_snr_h",
            "max": "max_snr_h",
            "min": "min_snr_h",
            "obs": "count_observe",
            "crit": "count_critical",
            "valid": "count_valid",
        }
    if metric == "snr_v":
        return {
            "avg": "promedio_snr_v",
            "max": "max_snr_v",
            "min": "min_snr_v",
            "obs": "count_observe",
            "crit": "count_critical",
            "valid": "count_valid",
        }
    if metric == "rx":
        return {
            "avg": "promedio_rx",
            "max": "max_rx",
            "min": "min_rx",
            "obs": "count_observe",
            "crit": "count_critical",
            "valid": "count_valid",
        }
    return {}

# -------------------- helpers numéricos y ranking --------------------

def _fnum(x, dflt=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return dflt

def _problematic_pct(metric: str, row: Dict, mode: str) -> float:
    f = _metric_fields(metric)
    # Latencia trae porcentaje listo
    if metric == "latencia":
        return _fnum(row.get(f.get("pct"), 0.0))

    # SNR/RX: calcular desde conteos
    valid = _fnum(row.get(f.get("valid"), 0.0))
    obs = _fnum(row.get(f.get("obs"), 0.0))
    crit = _fnum(row.get(f.get("crit"), 0.0))
    if valid <= 0:
        return 0.0
    if mode == "critical_only":
        num = crit
    else:
        num = obs + crit
    return (num * 100.0) / valid

def _severity_key(metric: str, row: Dict) -> float:
    """
    Tie-break del ranking:
      - Latencia: mayor promedio = peor
      - SNR: menor promedio (dB) = peor  -> usamos -avg
      - RX: más negativo (promedio más bajo) = peor -> usamos -avg
    """
    f = _metric_fields(metric)
    avg = _fnum(row.get(f.get("avg")))
    if metric == "latencia":
        return avg
    if metric in ("snr_h", "snr_v"):
        return -avg
    if metric == "rx":
        return -avg
    return 0.0

def _top_problematic(stats_by_metric: Dict[str, List[Dict]], metrics: List[str],
                     thresholds: Dict[str, float], mode_problematic: str) -> List[Dict]:
    """
    Mezcla todas las métricas y devuelve hasta MAX_CRITICOS con mayor % problemático.
    Cada item: {'metric', 'row', 'pct'}
    """
    items: List[Dict] = []
    for m in metrics:
        for row in (stats_by_metric.get(m) or []):
            pct = _problematic_pct(m, row, mode_problematic)
            if pct >= float(thresholds.get(m, DEFAULT_THRESHOLD_CRITICO)):
                items.append({"metric": m, "row": row, "pct": pct})
    items.sort(key=lambda x: (x["pct"], _severity_key(x["metric"], x["row"])), reverse=True)
    return items[:MAX_CRITICOS]

# -------------------- render del mensaje --------------------

def _join_labels(metrics: List[str]) -> str:
    labels = [METRIC_LABEL.get(m, m) for m in metrics]
    if not labels:
        return ""
    if len(labels) == 1:
        return labels[0]
    # "A, B y C"
    return ", ".join(labels[:-1]) + " y " + labels[-1]

def _intro_text(empresa: str, items: List[Dict], metrics: List[str]) -> str:
    Empresa = (empresa or "Cliente").capitalize()
    header = f"📊 Reporte del turno – {Empresa}"

    if not items:
        labels = _join_labels(metrics)
        body = f"✅ Equipos con {labels} dentro del rango estándar Operacional."
        txt = f"{header}\n{body}"
        return txt[: MAX_MSG_LEN - 3] + "..." if len(txt) > MAX_MSG_LEN else txt

    lines = [header, "⚠️ Equipos con condiciones a observar:"]
    for it in items:
        m = it["metric"]
        row = it["row"]
        label = METRIC_LABEL.get(m, m)
        units = METRIC_UNITS.get(m, "")
        f = _metric_fields(m)

        tag = row.get("tag") or row.get("ip") or ""
        ip = row.get("ip") or ""
        mx = _fnum(row.get(f.get("max")))
        pr = _fnum(row.get(f.get("avg")))
        marca = row.get("marca") or ""
        tipo = row.get("tipo") or ""

        # • Tag (IP) — [Métrica] Máx: X unidad | Prom: Y unidad | Marca: M | Tipo: T
        lines.append(
            f"• {tag} ({ip}) — [{label}] Máx: {mx:.1f} {units} | Prom: {pr:.1f} {units} | Marca: {marca} | Tipo: {tipo}"
        )

    txt = "\n".join(lines)
    return txt[: MAX_MSG_LEN - 3] + "..." if len(txt) > MAX_MSG_LEN else txt

# -------------------- Servicio WhatsApp (multi-métrica) --------------------

class WhatsAppService:
    """
    En config YAML:
      whatsapp:
        mudslide:
          groups:
            collahuasi: ["+56977566595", "120363027104819888@g.us"]
            test: ["+56977566595"]
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _groups(self, group_key: str) -> List[str]:
        groups = self.cfg.get("whatsapp.mudslide.groups", {})
        ids = groups.get(group_key, [])
        if not ids:
            raise ValueError(f"No hay destinatarios para whatsapp.mudslide.groups.{group_key}")
        return ids

    def _send(self, mudslide_id: str, text: str, timeout: int = 60) -> bool:
        cmd = f'{MUDSLIDE_BIN} send "{mudslide_id}" "{text}"'
        try:
            res = subprocess.run(cmd, shell=True, check=True, capture_output=True, timeout=timeout, text=True)
            if res.stdout:
                print(res.stdout.strip()[:400])
            print(f"✅ WhatsApp enviado a {mudslide_id}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ mudslide error -> {mudslide_id}\n{(e.stderr or e.stdout)[:400]}")
        except subprocess.TimeoutExpired:
            print(f"❌ Timeout enviando a {mudslide_id}")
        except Exception as e:
            print(f"❌ Error enviando a {mudslide_id}: {e}")
        return False

    # FULL y NORMAL no difieren en WhatsApp (no hay tablas).
    # Implementamos ambas por compatibilidad con el CLI.

    def enviar_reporte_simple_multi(
        self,
        empresa: str,
        horas: int,  # no usado
        stats_by_metric: Dict[str, List[Dict]],
        metrics: List[str],
        thresholds: Dict[str, float],
        mode_problematic: str,
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,  # ignorado (determinista)
    ) -> Dict[str, bool]:
        items = _top_problematic(stats_by_metric, metrics, thresholds, mode_problematic)
        text = _intro_text(empresa, items, metrics)
        resultados: Dict[str, bool] = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados

    def enviar_reporte_multi(
        self,
        empresa: str,
        horas: int,  # no usado
        stats_by_metric: Dict[str, List[Dict]],
        metrics: List[str],
        thresholds: Dict[str, float],
        mode_problematic: str,
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,  # ignorado (determinista)
    ) -> Dict[str, bool]:
        # Mismo contenido que simple (WhatsApp no tiene tablas)
        items = _top_problematic(stats_by_metric, metrics, thresholds, mode_problematic)
        text = _intro_text(empresa, items, metrics)
        resultados: Dict[str, bool] = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados
