# src/notificaciones/cli.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from notificaciones.core.config import load_config, Config
from notificaciones.core.api import API
from notificaciones.services.mail import MailService
from notificaciones.services.whatsapp import WhatsAppService


# ----------------------------
# Utilidades
# ----------------------------

def _date_range(hours_back: int) -> Tuple[str, str]:
    """Devuelve (start_iso, end_iso) en UTC para las últimas `hours_back` horas."""
    end_dt = datetime.utcnow()
    start_dt = end_dt - timedelta(hours=hours_back)
    to_iso = lambda dt: dt.strftime("%Y-%m-%dT%H:%M:%S")
    return to_iso(start_dt), to_iso(end_dt)


def _parse_metric_list(arg: Optional[str]) -> List[str]:
    """
    Acepta formatos:
      - "rx,snr_h"
      - "[rx, snr_h]"
      - None -> []
    """
    if not arg:
        return []
    s = arg.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    parts = [p.strip().lower() for p in s.split(",") if p.strip()]
    # normalizar nombres esperados
    mapping = {
        "latencia": "latencia",
        "snr_h": "snr_h", "snrh": "snr_h", "snr-h": "snr_h",
        "snr_v": "snr_v", "snrv": "snr_v", "snr-v": "snr_v",
        "rx": "rx", "link_radio_rx": "rx", "link-radio-rx": "rx",
    }
    out: List[str] = []
    for p in parts:
        out.append(mapping.get(p, p))
    # quitar duplicados preservando orden
    seen = set()
    dedup = []
    for m in out:
        if m not in seen:
            seen.add(m)
            dedup.append(m)
    return dedup


def _load_thresholds(cfg: Config, metrics: List[str], override: Optional[float]) -> Dict[str, float]:
    """
    Construye dict con thresholds por métrica.
    Si override no es None, lo aplica a todas.
    Sino usa los del YAML (general.threshold_pct_*), con fallback 10.0.
    """
    if override is not None:
        val = float(override)
        return {f"threshold_pct_{m}": val for m in metrics}

    # desde YAML
    def _g(k, default=10.0):
        v = cfg.get(f"general.{k}")
        try:
            return float(v)
        except Exception:
            return float(default)

    # nombres consistentes con lo que usa mail/whatsapp
    return {
        "threshold_pct_latencia": _g("threshold_pct_latencia", 10.0),
        "threshold_pct_snr_h":    _g("threshold_pct_snr_h",    10.0),
        "threshold_pct_snr_v":    _g("threshold_pct_snr_v",    10.0),
        "threshold_pct_rx":       _g("threshold_pct_rx",       10.0),
    }


def _default_metrics(cfg: Config) -> List[str]:
    m = cfg.get("general.metrics_default")
    if isinstance(m, list) and m:
        return [str(x).lower() for x in m]
    # por defecto todas
    return ["latencia", "snr_h", "snr_v", "rx"]


# ----------------------------
# Comandos
# ----------------------------

def run_once_mail(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    hours = args.hours or int(cfg.get("general.default_hours_back", 12))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")
    metrics = _parse_metric_list(args.metrics) or _default_metrics(cfg)
    thresholds = _load_thresholds(cfg, metrics, args.threshold)

    start_date, end_date = _date_range(hours)

    # Obtener datos por métrica
    stats_by_metric: Dict[str, List[dict]] = {}
    for m in metrics:
        try:
            stats_by_metric[m] = api.get_stats_by_metric(m, start_date, end_date) or []
        except Exception as e:
            print(f"⚠️  Error obteniendo {m}: {e}")
            stats_by_metric[m] = []

    if args.dry_run:
        print("🧪 DRY-RUN mail")
        print(f"Empresa: {empresa} | Hours: {hours} | Métricas: {metrics}")
        for m in metrics:
            print(f"  - {m}: {len(stats_by_metric.get(m, []))} filas")
        return 0

    ms = MailService(args.config)
    ok = ms.enviar_reporte_multi(
        empresa=empresa,
        hours=hours,
        stats_by_metric=stats_by_metric,
        metrics=metrics,
        thresholds=thresholds,
        full=args.full,
        prompt_file=args.prompt,
    )
    return 0 if ok else 1


def run_once_whatsapp(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    hours = args.hours or int(cfg.get("general.default_hours_back", 12))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")
    metrics = _parse_metric_list(args.metrics) or _default_metrics(cfg)
    thresholds = _load_thresholds(cfg, metrics, args.threshold)
    group = args.group or "test"

    start_date, end_date = _date_range(hours)

    stats_by_metric: Dict[str, List[dict]] = {}
    for m in metrics:
        try:
            stats_by_metric[m] = api.get_stats_by_metric(m, start_date, end_date) or []
        except Exception as e:
            print(f"⚠️  Error obteniendo {m}: {e}")
            stats_by_metric[m] = []

    if args.dry_run:
        print("🧪 DRY-RUN whatsapp")
        print(f"Empresa: {empresa} | Hours: {hours} | Métricas: {metrics} | Grupo: {group}")
        return 0

    ws = WhatsAppService(args.config)
    res = ws.enviar_reporte_multi(
        empresa=empresa,
        hours=hours,
        stats_by_metric=stats_by_metric,
        metrics=metrics,
        thresholds=thresholds,
        group_key=group,
        timeout=args.timeout,
        prompt_file=args.prompt,
    )
    if not res:
        print("❌ No se envió ningún mensaje")
        return 1
    fails = [k for k, v in res.items() if not v]
    if fails:
        print(f"⚠️ Fallaron {len(fails)} destinatarios: {', '.join(fails)}")
    return 0


def run_loop(args) -> int:
    """
    Bucle simple para ejecutar cada N horas (por defecto 8).
    Recomendación prod: usar cron/systemd, esto es un MVP.
    """
    import time

    every_h = args.every_h or 8
    print(f"⏱️ Ejecutando cada {every_h} horas. Ctrl+C para salir.")
    while True:
        try:
            if args.mode == "mail":
                run_once_mail(args)
            else:
                run_once_whatsapp(args)
        except Exception as e:
            print(f"❌ Error en ejecución: {e}")
        time.sleep(every_h * 3600)


# ----------------------------
# Parser
# ----------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="smartlink-notificaciones",
        description="Envío de reportes Smartlink por correo y WhatsApp (últimas N horas).",
    )
    sub = p.add_subparsers(dest="cmd")

    # mail
    mail = sub.add_parser("mail", help="Enviar reporte por correo (una vez)")
    mail.add_argument("--empresa", help="Empresa (fallback al YAML)")
    mail.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    mail.add_argument("--metrics", help="Lista de métricas p.ej. 'rx,snr_h' o '[rx, snr_h]'.")
    mail.add_argument("--threshold", type=float, help="Umbral % general para todas las métricas (override).")
    mail.add_argument("--full", action="store_true", help="Modo completo (tablas por métrica)")
    mail.add_argument("--prompt", help="Ruta a prompt personalizado (texto)")
    mail.add_argument("--config", help="Ruta a configNotificaciones.yml")
    mail.add_argument("--dry-run", action="store_true", help="Simular sin enviar")
    mail.set_defaults(func=run_once_mail)

    # whatsapp
    wa = sub.add_parser("whatsapp", help="Enviar reporte por WhatsApp (una vez)")
    wa.add_argument("--empresa", help="Empresa (fallback al YAML)")
    wa.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    wa.add_argument("--metrics", help="Lista de métricas p.ej. 'rx,snr_h' o '[rx, snr_h]'.")
    wa.add_argument("--threshold", type=float, help="Umbral % general para todas las métricas (override).")
    wa.add_argument("--group", help="Clave del grupo en whatsapp.mudslide.groups (p.ej. collahuasi/test)")
    wa.add_argument("--timeout", type=int, default=60, help="Timeout por envío (seg)")
    wa.add_argument("--prompt", help="Ruta a prompt personalizado (texto)")
    wa.add_argument("--config", help="Ruta a configNotificaciones.yml")
    wa.add_argument("--dry-run", action="store_true", help="Simular sin enviar")
    wa.set_defaults(func=run_once_whatsapp)

    # loop
    loop = sub.add_parser("loop", help="Bucle que envía cada N horas (default 8)")
    loop.add_argument("mode", choices=["mail", "whatsapp"], help="Qué enviar en el loop")
    loop.add_argument("--every-h", type=int, default=8, help="Cada cuántas horas ejecutar")
    loop.add_argument("--empresa", help="Empresa (fallback al YAML)")
    loop.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    loop.add_argument("--metrics", help="Lista de métricas p.ej. 'rx,snr_h' o '[rx, snr_h]'.")
    loop.add_argument("--threshold", type=float, help="Umbral % general para todas las métricas (override).")
    loop.add_argument("--group", help="(solo whatsapp) clave de grupo")
    loop.add_argument("--timeout", type=int, default=60, help="(solo whatsapp) timeout por envío")
    loop.add_argument("--prompt", help="Ruta a prompt personalizado (texto)")
    loop.add_argument("--config", help="Ruta a configNotificaciones.yml")
    loop.set_defaults(func=run_loop)

    # show-config
    show = sub.add_parser("show-config", help="Mostrar configuración efectiva")
    show.add_argument("--config", help="Ruta a configNotificaciones.yml")
    show.set_defaults(func=lambda a: (print(load_config(a.config).raw), 0)[1])

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
