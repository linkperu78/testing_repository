# src/notificaciones/cli.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta
from typing import Tuple, List, Dict, Optional, Union

from notificaciones.core.config import load_config
from notificaciones.core.api import API
from notificaciones.services.mail import MailService
from notificaciones.services.whatsapp import WhatsAppService

# ---------------- utils de fecha ----------------

def _date_range(hours_back: int) -> Tuple[str, str]:
    """Devuelve (start_iso, end_iso) en UTC para las últimas `hours_back` horas."""
    end_dt = datetime.utcnow()
    start_dt = end_dt - timedelta(hours=hours_back)
    to_iso = lambda dt: dt.strftime("%Y-%m-%dT%H:%M:%S")
    return to_iso(start_dt), to_iso(end_dt)

# ---------------- parseadores ----------------

def _parse_metric_list(arg: Optional[Union[List[str], str]]) -> List[str]:
    """
    Acepta:
      - None -> usa por defecto todas las métricas
      - "latencia" o "rx" ...
      - "[rx, snr_h]" (con o sin espacios) -> lista
    Devuelve lista normalizada en minúsculas.
    """
    default_metrics = ["latencia", "snr_h", "snr_v", "rx"]
    if arg is None:
        return default_metrics
    if isinstance(arg, list):
        return [str(x).strip().lower() for x in arg if x]
    s = str(arg).strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    parts = [p.strip().lower() for p in s.split(",") if p.strip()]
    return parts or default_metrics

def _thresholds_from_args(cfg, args) -> Dict[str, float]:
    """
    Mezcla thresholds CLI con YAML.
    """
    def pick(cli_val, yaml_path, dflt):
        if cli_val is not None:
            return float(cli_val)
        v = cfg.get(yaml_path, None)
        return float(v) if v is not None else float(dflt)

    th = {
        "latencia": pick(args.th_lat, "general.threshold_pct_latencia", 10.0),
        "snr_h":   pick(args.th_snrh, "general.threshold_pct_snr_h", 10.0),
        "snr_v":   pick(args.th_snrv, "general.threshold_pct_snr_v", 10.0),
        "rx":      pick(args.th_rx,   "general.threshold_pct_rx", 10.0),
    }
    return th

def _problematic_mode_from_args(cfg, args) -> str:
    mode = args.mode_problematic or cfg.get("general.problematic_mode", "observe_plus_critical")
    mode = str(mode).strip().lower()
    if mode not in ("observe_plus_critical", "critical_only"):
        mode = "observe_plus_critical"
    return mode

# ---------------- comandos ----------------

def run_once_mail(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    horas = args.hours or int(cfg.get("general.default_hours_back", 12))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")
    metrics = _parse_metric_list(args.metric)
    thresholds = _thresholds_from_args(cfg, args)
    mode_problematic = _problematic_mode_from_args(cfg, args)

    start_date, end_date = _date_range(horas)
    # Cargar datos por métrica
    stats_by_metric: Dict[str, List[Dict]] = {}
    for m in metrics:
        if m == "latencia":
            stats_by_metric[m] = api.get_stats(start_date, end_date) or []
        elif m == "snr_h":
            stats_by_metric[m] = api.get_stats_snr_h(start_date, end_date) or []
        elif m == "snr_v":
            stats_by_metric[m] = api.get_stats_snr_v(start_date, end_date) or []
        elif m == "rx":
            stats_by_metric[m] = api.get_stats_rx(start_date, end_date) or []
        else:
            print(f"⚠️ Métrica desconocida ignorada: {m}")

    if args.dry_run:
        print("🧪 DRY-RUN mail")
        print(f"Empresa: {empresa} | Horas: {horas} | Métricas: {metrics}")
        for k, v in stats_by_metric.items():
            print(f" - {k}: {len(v)} filas")
        return 0

    ms = MailService(args.config)
    if args.full:
        ok = ms.enviar_reporte_multi(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            prompt_path=args.prompt,
        )
    else:
        ok = ms.enviar_reporte_simple_multi(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            prompt_path=args.prompt,
        )
    return 0 if ok else 1

def run_once_whatsapp(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    horas = args.hours or int(cfg.get("general.default_hours_back", 12))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")
    group = args.group or cfg.get("empresas.default.mudslide_group", "test")

    metrics = _parse_metric_list(args.metric)
    thresholds = _thresholds_from_args(cfg, args)
    mode_problematic = _problematic_mode_from_args(cfg, args)

    start_date, end_date = _date_range(horas)

    stats_by_metric: Dict[str, List[Dict]] = {}
    for m in metrics:
        if m == "latencia":
            stats_by_metric[m] = api.get_stats(start_date, end_date) or []
        elif m == "snr_h":
            stats_by_metric[m] = api.get_stats_snr_h(start_date, end_date) or []
        elif m == "snr_v":
            stats_by_metric[m] = api.get_stats_snr_v(start_date, end_date) or []
        elif m == "rx":
            stats_by_metric[m] = api.get_stats_rx(start_date, end_date) or []
        else:
            print(f"⚠️ Métrica desconocida ignorada: {m}")

    if args.dry_run:
        print("🧪 DRY-RUN whatsapp")
        print(f"Empresa: {empresa} | Horas: {horas} | Grupo: {group} | Métricas: {metrics}")
        for k, v in stats_by_metric.items():
            print(f" - {k}: {len(v)} filas")
        return 0

    ws = WhatsAppService(args.config)
    if args.full:
        res = ws.enviar_reporte_multi(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            group_key=group,
            timeout=args.timeout,
            prompt_path=args.prompt,
        )
    else:
        res = ws.enviar_reporte_simple_multi(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            group_key=group,
            timeout=args.timeout,
            prompt_path=args.prompt,
        )

    if not res:
        print("❌ No se envió ningún mensaje")
        return 1
    fails = [k for k, v in res.items() if not v]
    if fails:
        print(f"⚠️ Fallaron {len(fails)} destinatarios: {', '.join(fails)}")
    return 0

def run_loop(args) -> int:
    """
    Bucle simple para ejecutar cada N horas (por defecto 8).
    Recomendación prod: usar cron/systemd, esto es un MVP.
    """
    import time

    every_h = args.every_h or 8
    print(f"⏱️ Ejecutando cada {every_h} horas. Ctrl+C para salir.")
    while True:
        try:
            if args.mode == "mail":
                run_once_mail(args)
            else:
                run_once_whatsapp(args)
        except Exception as e:
            print(f"❌ Error en ejecución: {e}")
        time.sleep(every_h * 3600)

# ---------------- parser ----------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="smartlink-notificaciones",
        description="Envío de reportes Smartlink por correo y WhatsApp (multi-métrica).",
    )
    sub = p.add_subparsers(dest="cmd")

    # mail
    mail = sub.add_parser("mail", help="Enviar reporte por correo (una vez)")
    mail.add_argument("--empresa", help="Empresa (fallback al YAML)")
    mail.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    mail.add_argument("--config", help="Ruta a configNotificaciones.yml")
    mail.add_argument("--metric", help="Lista de métricas: [latencia, snr_h, snr_v, rx]")
    mail.add_argument("--prompt", help="Ruta a prompt personalizado para IA (opcional)")
    mail.add_argument("--full", action="store_true", help="Incluir tablas completas por métrica")
    # thresholds
    mail.add_argument("--th-lat", type=float, help="Threshold % Latencia")
    mail.add_argument("--th-snrh", type=float, help="Threshold % SNR-H")
    mail.add_argument("--th-snrv", type=float, help="Threshold % SNR-V")
    mail.add_argument("--th-rx", type=float, help="Threshold % RX")
    # modo problemático
    mail.add_argument("--mode-problematic", choices=["observe_plus_critical", "critical_only"],
                      help="Cómo calcular el % problemático")
    mail.add_argument("--dry-run", action="store_true", help="Simular sin enviar")
    mail.set_defaults(func=run_once_mail)

    # whatsapp
    wa = sub.add_parser("whatsapp", help="Enviar reporte por WhatsApp (una vez)")
    wa.add_argument("--empresa", help="Empresa (fallback al YAML)")
    wa.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    wa.add_argument("--group", help="Clave del grupo en whatsapp.mudslide.groups (p.e. collahuasi/test)")
    wa.add_argument("--timeout", type=int, default=60, help="Timeout por envío (seg)")
    wa.add_argument("--config", help="Ruta a configNotificaciones.yml")
    wa.add_argument("--metric", help="Lista de métricas: [latencia, snr_h, snr_v, rx]")
    wa.add_argument("--prompt", help="(Ignorado en WhatsApp) Ruta a prompt")
    wa.add_argument("--full", action="store_true", help="(Ignorado en WhatsApp) Compatibilidad")
    # thresholds
    wa.add_argument("--th-lat", type=float, help="Threshold % Latencia")
    wa.add_argument("--th-snrh", type=float, help="Threshold % SNR-H")
    wa.add_argument("--th-snrv", type=float, help="Threshold % SNR-V")
    wa.add_argument("--th-rx", type=float, help="Threshold % RX")
    # modo problemático
    wa.add_argument("--mode-problematic", choices=["observe_plus_critical", "critical_only"],
                    help="Cómo calcular el % problemático")
    wa.add_argument("--dry-run", action="store_true", help="Simular sin enviar")
    wa.set_defaults(func=run_once_whatsapp)

    # loop
    loop = sub.add_parser("loop", help="Bucle que envía cada N horas (default 8)")
    loop.add_argument("mode", choices=["mail", "whatsapp"], help="Qué enviar en el loop")
    loop.add_argument("--every-h", type=int, default=8, help="Cada cuántas horas ejecutar")
    loop.add_argument("--empresa", help="Empresa (fallback al YAML)")
    loop.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    loop.add_argument("--group", help="(solo whatsapp) clave de grupo")
    loop.add_argument("--timeout", type=int, default=60, help="(solo whatsapp) timeout por envío")
    loop.add_argument("--config", help="Ruta a configNotificaciones.yml")
    loop.add_argument("--metric", help="Lista de métricas: [latencia, snr_h, snr_v, rx]")
    loop.add_argument("--full", action="store_true", help="(solo mail) incluir tablas completas")
    # thresholds
    loop.add_argument("--th-lat", type=float, help="Threshold % Latencia")
    loop.add_argument("--th-snrh", type=float, help="Threshold % SNR-H")
    loop.add_argument("--th-snrv", type=float, help="Threshold % SNR-V")
    loop.add_argument("--th-rx", type=float, help="Threshold % RX")
    # modo problemático
    loop.add_argument("--mode-problematic", choices=["observe_plus_critical", "critical_only"],
                      help="Cómo calcular el % problemático")
    loop.set_defaults(func=run_loop)

    # show-config
    show = sub.add_parser("show-config", help="Mostrar configuración efectiva")
    show.add_argument("--config", help="Ruta a configNotificaciones.yml")
    show.set_defaults(func=lambda a: (print(load_config(a.config).raw), 0)[1])

    return p

def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        return 0
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())
