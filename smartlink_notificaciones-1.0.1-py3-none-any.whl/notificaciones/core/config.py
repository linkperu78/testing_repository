# src/notificaciones/core/config.py
# -*- coding: utf-8 -*-

import os
import yaml
from pathlib import Path
from typing import Any, Dict, Optional


class Config:
    def __init__(self, data: Dict[str, Any]):
        self._data = self._normalize(data)

    def _normalize(self, d: Any) -> Any:
        """Convierte todas las claves de diccionarios a minúsculas recursivamente."""
        if isinstance(d, dict):
            return {str(k).lower(): self._normalize(v) for k, v in d.items()}
        if isinstance(d, list):
            return [self._normalize(x) for x in d]
        return d

    def get(self, path: str, default=None) -> Any:
        """
        Acceso tipo 'api.base_url' -> valor
        Si alguna parte no existe, devuelve default.
        """
        cur = self._data
        parts = path.split(".")
        for idx, part in enumerate(parts):
            if not isinstance(cur, dict):
                return default
            cur = cur.get(part.lower())
            if cur is None and idx < len(parts) - 1:
                # Si en medio falta, devolvemos dict vacío para seguir
                cur = {}
        return cur if cur is not None else default

    @property
    def raw(self) -> Dict[str, Any]:
        """Devuelve el diccionario completo de configuración (normalizado)."""
        return self._data


_config: Optional[Config] = None


def load_config(path: Optional[str] = None) -> Config:
    """
    Carga la configuración desde:
    1. argumento explícito (--config),
    2. variable de entorno SMARTLINK_NOTIF_CONFIG,
    3. archivo configNotificaciones.yml en cwd,
    4. archivo configNotificaciones.yml en la raíz del proyecto.
    """
    global _config

    if _config is not None and path is None:
        return _config

    candidates = []
    if path:
        candidates.append(Path(path))
    env_path = os.getenv("SMARTLINK_NOTIF_CONFIG")
    if env_path:
        candidates.append(Path(env_path))
    candidates.append(Path.cwd() / "configNotificaciones.yml")
    candidates.append(Path(__file__).resolve().parents[3] / "configNotificaciones.yml")

    for p in candidates:
        if p and p.exists():
            with open(p, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            _config = Config(data)
            print(f"✅ Config cargada: {p}")
            return _config

    raise FileNotFoundError(
        "No se encontró configNotificaciones.yml (usa --config o SMARTLINK_NOTIF_CONFIG)."
    )
