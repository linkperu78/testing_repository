# src/notificaciones/core/api.py

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
import requests
from urllib.parse import urljoin

from .config import load_config


class API:
    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)
        self.base_url: str = self.cfg.get("api.base_url", "").rstrip("/") + "/"
        # timeouts por defecto
        self.timeout: int = int(self.cfg.get("general.timeout", 30) or 30)

    # ------------------------- utilidades internas -------------------------

    def _url(self, path: str) -> str:
        return urljoin(self.base_url, path.lstrip("/"))

    def _get(self, path: str, params: Dict[str, Any]) -> Dict[str, Any]:
        url = self._url(path)
        r = requests.get(url, params=params, timeout=self.timeout)
        r.raise_for_status()
        return r.json() if r.content else {}

    def _extract_list(self, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
        # La mayoría de endpoints devuelven {"data": [...]}.
        # Si no, intentamos lista directamente.
        if isinstance(payload, dict) and "data" in payload and isinstance(payload["data"], list):
            return payload["data"]
        if isinstance(payload, list):
            return payload
        return []

    # ---------------------------- latencia ---------------------------------

    def get_stats(self, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Estadísticas por IP para latencia (máx, prom, min, conteos, etc.)
        """
        path = self.cfg.get("api.latencia.get_latencia_stats", "/latencia/get_latencia_stats")
        params = {
            "start_date": start_date,
            "end_date": end_date,
            # parámetros típicos de ese endpoint
            "offset": 0,
            "limit": 100000,
            "aprox_date": "true",
        }
        data = self._get(path, params)
        return self._extract_list(data)

    def get_stats_summary(self, start_date: str, end_date: str) -> Dict[str, Any]:
        """
        Resumen general de latencia (por si lo sigues usando).
        """
        path = self.cfg.get("api.latencia.get_latencia_stats_summary", "/latencia/get_latencia_stats_summary")
        params = {"start_date": start_date, "end_date": end_date}
        try:
            return self._get(path, params)
        except Exception:
            return {}

    # ------------------------- métricas genéricas --------------------------

    def get_stats_by_metric(self, metric: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Obtiene estadísticas por IP para una métrica:
        - 'latencia' → usa el mismo endpoint que get_stats
        - 'snr_h'    → api.snr_h.get_stats (ej: /cambium_data/get_metric_stats_by_ip?column=snr&metric=h)
        - 'snr_v'    → api.snr_v.get_stats (ej: /cambium_data/get_metric_stats_by_ip?column=snr&metric=v)
        - 'rx'       → api.rx.get_stats    (ej: /cambium_data/get_metric_stats_by_ip?column=link_radio&metric=rx)
        """
        metric = (metric or "").lower()

        if metric == "latencia":
            return self.get_stats(start_date, end_date)

        key_map = {
            "snr_h": "api.snr_h.get_stats",
            "snr_v": "api.snr_v.get_stats",
            "rx": "api.rx.get_stats",
        }
        cfg_key = key_map.get(metric)
        if not cfg_key:
            return []

        path = self.cfg.get(cfg_key, "")
        if not path:
            return []

        # Endpoints Cambium aceptan limit_rows
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit_rows": 200000,
        }
        data = self._get(path, params)
        return self._extract_list(data)
