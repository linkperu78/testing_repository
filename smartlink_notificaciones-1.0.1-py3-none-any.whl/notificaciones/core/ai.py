# src/notificaciones/core/ai.py

import os
from dotenv import load_dotenv, find_dotenv
from openai import OpenAI


def get_openai_client():
    """
    Inicializa el cliente de OpenAI leyendo la API key desde:
      1. Variables de entorno: OPENAI_API_KEY o OPEN_API_KEY
      2. Archivo .env en el directorio actual o superior
    Devuelve None si no hay clave disponible.
    """
    # Buscar archivo .env en el cwd (directorio donde se ejecuta el comando)
    dotenv_path = find_dotenv(usecwd=True)
    if dotenv_path:
        load_dotenv(dotenv_path)
    else:
        load_dotenv()  # fallback global

    # Aceptar ambas variables
    api_key = os.getenv("OPENAI_API_KEY") or os.getenv("OPEN_API_KEY")
    if not api_key:
        print("⚠️  Falta OPENAI_API_KEY/OPEN_API_KEY en .env o entorno.")
        return None

    # Asegurar que quede disponible para el SDK
    os.environ["OPENAI_API_KEY"] = api_key

    try:
        client = OpenAI(api_key=api_key)
        return client
    except Exception as e:
        print(f"⚠️  No se pudo inicializar OpenAI: {e}")
        return None


def mensaje_chat_gpt(client: OpenAI, prompt: str, is_windows: bool = False) -> str:
    """
    Envía un prompt a la API de OpenAI y devuelve la respuesta en texto.
    Si falla, devuelve un mensaje fijo para fallback.
    """
    if client is None:
        return "⚠️  Sin Cliente OpenAI: usando mensaje generado localmente."

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": prompt},
            ],
        )
        chat_mensaje = response.choices[0].message.content

        if is_windows and chat_mensaje:
            # Normalizar saltos de línea para Windows
            chat_mensaje = chat_mensaje.replace("\n", "\\n")

        return chat_mensaje or ""
    except Exception as e:
        print(f"⚠️  Error al generar mensaje con OpenAI: {e}")
        return "⚠️  Error en generación con OpenAI: usando mensaje generado localmente."
