import os
from typing import Optional
from dotenv import load_dotenv, find_dotenv
from openai import OpenAI


def get_openai_client() -> Optional[OpenAI]:
    """
    Inicializa el cliente de OpenAI leyendo la API key desde:
      - Variables de entorno: OPENAI_API_KEY o OPEN_API_KEY
      - Archivo .env en el directorio actual (o superior)
    Devuelve None si no hay clave disponible o si falla la inicialización.
    """
    # Carga .env desde el cwd si existe; si no, intenta global
    dotenv_path = find_dotenv(usecwd=True)
    if dotenv_path:
        load_dotenv(dotenv_path)
    else:
        load_dotenv()

    # Aceptar ambas variables
    api_key = os.getenv("OPENAI_API_KEY") or os.getenv("OPEN_API_KEY")
    if not api_key:
        print("⚠️  Falta OPENAI_API_KEY/OPEN_API_KEY en .env o entorno.")
        return None

    # Asegurar variable esperada por el SDK
    os.environ["OPENAI_API_KEY"] = api_key

    try:
        return OpenAI(api_key=api_key)
    except Exception as e:
        print(f"⚠️  No se pudo inicializar OpenAI: {e}")
        return None


def mensaje_chat_gpt(
    client: Optional[OpenAI],
    prompt: str,
    *,
    model: str = "gpt-4o-mini",
    max_tokens: int = 700,
    temperature: float = 0.3,
    is_windows: bool = False,
) -> str:
    """
    Envía un prompt a la API de OpenAI y devuelve la respuesta en texto.

    Parámetros:
      - model: nombre del modelo (por defecto gpt-4o-mini)
      - max_tokens: límite de tokens de salida
      - temperature: creatividad (0 = determinista)
      - is_windows: si True, normaliza saltos de línea a \\n

    Si `client` es None o hay error, retorna un mensaje fallback.
    """
    if client is None:
        return "⚠️  Sin Cliente OpenAI: usando mensaje generado localmente."

    try:
        resp = client.chat.completions.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[
                {"role": "user", "content": prompt},
            ],
        )
        text = (resp.choices[0].message.content or "").strip()
        if is_windows:
            text = text.replace("\n", "\\n")
        return text
    except Exception as e:
        print(f"⚠️  Error al generar mensaje con OpenAI: {e}")
        return "⚠️  Error en generación con OpenAI: usando mensaje generado localmente."
