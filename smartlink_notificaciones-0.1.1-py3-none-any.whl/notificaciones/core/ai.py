# -*- coding: utf-8 -*-
# src/notificaciones/core/ai.py

import os
import sys
from typing import Optional
from dotenv import load_dotenv


try:
    from openai import OpenAI
except Exception:
    OpenAI = None  # será None si falta la lib; lo controlamos abajo


def _get_api_key() -> Optional[str]:
    """
    Busca la API key en:
      - .env del cwd (si existe)
      - variables de entorno del proceso
    Acepta OPEN_API_KEY o OPENAI_API_KEY.
    """
    # Carga .env solo una vez: si no existe, no falla
    load_dotenv(override=False)
    try:
        print("OPEN_API_KEY:", os.getenv("OPEN_API_KEY"))
    except Exception as e:
        print(f"⚠️ Error al leer OPEN_API_KEY: {e}")
        sys.exit(1)
    return os.getenv("OPEN_API_KEY") or os.getenv("OPENAI_API_KEY")


def get_openai_client():
    """
    Retorna el cliente OpenAI (o None si no hay lib o API key).
    """
    if OpenAI is None:
        print("⚠️ openai no está instalado. Ejecuta: pip install openai")
        return None

    api_key = _get_api_key()
    if not api_key:
        print("⚠️ Falta OPEN_API_KEY/OPENAI_API_KEY en .env o entorno.")
        return None

    try:
        return OpenAI(api_key=api_key)
    except Exception as e:
        print(f"⚠️ No se pudo inicializar OpenAI: {e}")
        return None


def mensaje_chat_gpt(client, mensaje: str, is_windows: bool = False, model: str = "gpt-4o-mini") -> Optional[str]:
    """
    Envía un prompt simple y devuelve el contenido de la primera respuesta.
    """
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": mensaje}],
        )
        text = resp.choices[0].message.content
        if is_windows and text:
            text = text.replace("\n", "\\n")
        return text
    except Exception as e:
        print(f"⚠️ Error en llamada a OpenAI: {e}")
        return None
