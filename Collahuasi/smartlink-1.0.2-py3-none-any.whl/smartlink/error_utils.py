import os
import sqlite3
from sqlite3 import Error

_DB_NAME = "errores.db"
#_DB_PATH = os.path.join("/home/support/errores", _DB_NAME) 
_DB_PATH = os.path.join("/usr/hcg/backend/error", _DB_NAME) 
KEYNAME_ERROR_DICT = "Error_HCG"

##  - - - - - - - - - - - - - Cada codename contiene [error_code, descripción]
# Errores SSH
SSH_LOG_ERROR       = ["ERR-036", "Fallo de acceso SSH"]
SSH_COMMAND_EXEC_ERROR = ["ERR-037", "Fallo en la ejecución del comando SSH"]

## Errores SNMP
SNMP_LOG_ERROR      = ["ERR-227", "Fallo de acceso SNMP"]

## Errores DB
LOCAL_DB_ERROR      = ["TEST-ERR-003", "No se pudo conectar a la base de datos de errores"]
DB_LOG_ERROR        = ["ERR-044", "Fallo de acceso a base de datos"]
DB_NOT_RESPONSE     = ["TES-ERR-001", "No se ha recibido respuesta de API/URL"]
DB_URL_ERROR        = ["TEST-ERR-000", "URL de la API inválida"]
TABLE_ERROR         = ["TEST-ERR-045", "Formato incompatible con la tabla"]

## Errores BCAPI
RAJANT_SESSION_FAILED   = ["TEST-ERR_RAJANT01", "No se logro establecer conexion mediante BCAPI"]
RAJANT_QUERY_INVALID    = ["TEST-ERR_RAJANT02", "Solicitud invalida para BCAPI"]

##  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

def create_table_if_not_exists():
    conn = None
    try:
        conn = sqlite3.connect(_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS errores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT(30) NOT NULL,
                ip TEXT(20) NOT NULL,
                codigo TEXT(20) NOT NULL,
                log TEXT(150) NULL
            )
        """)
        conn.commit()
    except Error as e:
        print(f"[SQLite ERROR] {e}")
    finally:
        if conn:
            conn.close()


def single_storage_error(error_info, ip, date):
    codigo = error_info[0]
    log = error_info[1] if len(error_info) > 1 else None
    conn = None
    try:
        conn = sqlite3.connect(_DB_PATH)
        cursor = conn.cursor()

        query = """
        INSERT INTO errores (fecha, ip, codigo, log)
        VALUES (?, ?, ?, ?)
        """
        cursor.execute(query, (date, ip, codigo, log))
        conn.commit()

        print(f"[SQLite] Guardado: {ip}, {date}, {codigo}, {log}")

    except Error as e:
        print(f"[SQLite ERROR] {e}")

    finally:
        if conn:
            conn.close()


def multiple_storage_errors(error_list):
    conn = None
    try:
        conn = sqlite3.connect(_DB_PATH)
        cursor = conn.cursor()

        query = """
        INSERT INTO errores (fecha, ip, codigo, log)
        VALUES (?, ?, ?, ?)
        """

        data = []
        for ip, date, error_string_message in error_list:
            error_info = error_string_message.split("|")
            codigo = error_info[0]
            log = error_info[1] if len(error_info) > 1 else None
            data.append((date, ip, codigo, log))

        cursor.executemany(query, data)
        conn.commit()

        print(f"[SQLite] Guardados {len(data)} errores")

    except Error as e:
        print(f"[SQLite ERROR] {e}")

    finally:
        if conn:
            conn.close()

#create_table_if_not_exists()