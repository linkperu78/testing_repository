from pprint import pprint, PrettyPrinter as pp
import socket

FOLDER_OUTPUT   = "/usr/smartlink/outputs"
FOLDER_HITMAN   = "/usr/smartlink/heatmap"

## Convertion from MAC Address to Readable String
def mac_to_string(mac_string):
    if isinstance(mac_string, bytes):
        return ':'.join('%02x' % b for b in mac_string)
    else:
        return ':'.join('%02x' % ord(b) for b in mac_string)


## Pretty Print Dictionaries:
def print_dictionary(dictionary_to_print : dict ):
    pprint(dictionary_to_print)


## Pretty Print Arrays:
def print_array(array_to_print : list):
    """Pretty prints an array with indentation."""
    _pp = pp(indent=4, width=80, compact=False)
    _pp.pprint(array_to_print)


## Funcion para agrupar IP's para tareas en paralelo
def group_ips(ip_list, max_group_size = 25):
    grouped_ips = [ip_list[i:i + max_group_size] for i in range(0, len(ip_list), max_group_size)]
    return grouped_ips


def get_my_server_ip() -> str:
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    return str(local_ip)

