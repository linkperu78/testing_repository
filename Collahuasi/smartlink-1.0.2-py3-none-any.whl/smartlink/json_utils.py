import json
import os

def load_json_to_dict(ruta_archivo : str) -> dict:
    filename = os.path.basename(ruta_archivo)
    try:
        with open(ruta_archivo, "r") as file:
            datos = json.load(file)
            if isinstance(datos, dict):
                return datos
            else:
                print(f"Advertencia: El contenido de {filename} no es un diccionario.")
                return dict()
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error al leer {filename}: {e}")
        return dict()