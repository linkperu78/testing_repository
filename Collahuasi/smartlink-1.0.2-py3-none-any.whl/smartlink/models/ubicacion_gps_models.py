from pydantic import BaseModel
from typing import Dict

class UbicacionGPS(BaseModel):
    __tablename__ = 'ubicacion_gps'
    ip          : str
    fecha       : str
    latitud     : float
    longitud    : float
    altitud     : float


