from pydantic import BaseModel
from typing import Dict

class EstructuraRed(BaseModel):
    __tablename__ = 'estructura_red'
    ip_fuente   : str
    ip_cliente  : str

