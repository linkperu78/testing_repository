from pydantic import BaseModel
#from typing import Dict

class Rol(BaseModel):
    __tablename__ = 'lista_rol'
    rol: str


