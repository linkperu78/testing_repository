from pydantic import BaseModel
from typing import Dict

class SnmpConf(BaseModel):
    __tablename__ = 'snmp_conf'
    comunidad       : str
    version         : int
    credenciales    : Dict


