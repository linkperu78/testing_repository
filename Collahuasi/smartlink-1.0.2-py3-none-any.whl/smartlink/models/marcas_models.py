from pydantic import BaseModel

class Marca(BaseModel):
    __tablename__ = 'lista_marcas'
    marca: str

