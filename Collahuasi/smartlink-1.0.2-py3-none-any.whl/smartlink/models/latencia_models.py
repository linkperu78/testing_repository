from pydantic import BaseModel

class Latencia(BaseModel):
    __tablename__ = 'latencia'
    ip          : str
    latencia    : float
    fecha       : str
