from pydantic import BaseModel
from typing import Dict

class MimosaData(BaseModel):
    __tablename__ = 'mimosa_data'
    ip          : str
    fecha       : str
    interface   : Dict
    network     : Dict
    