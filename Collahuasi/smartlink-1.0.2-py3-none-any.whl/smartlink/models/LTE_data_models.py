from pydantic import BaseModel
from typing import Dict, List

class LTE(BaseModel):
    __tablename__ = 'LTE_data'
    ip          : str
    fecha       : str
    sistema     : Dict
    enlaces     : List[Dict[str, str]]
    estado      : Dict
    