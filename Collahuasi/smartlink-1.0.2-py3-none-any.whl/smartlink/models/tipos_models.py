from pydantic import BaseModel
from typing import Dict

class Tipo(BaseModel):
    __tablename__ = 'lista_tipo'
    tipo: str
