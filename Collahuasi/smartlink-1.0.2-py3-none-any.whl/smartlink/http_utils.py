from smartlink.error_utils import TABLE_ERROR, DB_URL_ERROR, DB_NOT_RESPONSE
import requests
import psutil
import socket

## Configurar el IPv4 dinamicamente
def get_ipv4_address( interfaces = ("ens192", "eth0") ):
    for interface in interfaces:
        addrs = psutil.net_if_addrs().get(interface)
        if not addrs:
            continue
        for addr in addrs:
            if addr.family == socket.AF_INET:
                return addr.address
    return None
ip_address = get_ipv4_address()

DB_API_URL = f"http://{ip_address or 'localhost'}:8000/"
TIMEOUT_API_REQUEST = 5

## Funcion para realizar consultas a una URL con timeout de 5 segundos
def get_request_to_url(url: str, 
                       timeout : int = TIMEOUT_API_REQUEST, 
                       column_filter : str = None, 
                       optional_param : dict = None, 
                       _debug : bool = False) -> list:
    try:
        optional_param = optional_param or {}  # Avoid mutable default argument
        response = requests.get(url, params = optional_param, timeout=timeout)        
        response.raise_for_status()  # Lanza una excepción si el código de estado es 4xx o 5xx
        if _debug:
            print(f"URL API = {url}")

        inventario_data = response.json()
        if not isinstance(inventario_data, list):
            if _debug:
                print(f"No se obtuvo un formato list en {url} : {type(inventario_data)}")
            return []

        # Si no se especifica column_filter, devolver todos los datos
        if not column_filter:
            return inventario_data

        # Filtrar solo los valores que contienen la clave
        result_list = [record[column_filter] for record in inventario_data if column_filter in record]
        return result_list

    except requests.exceptions.ConnectTimeout as e:
        if _debug:
            print(f"✘ Timeout de conexión:\n{e}")
        error_msg = f"No hubo respuesta de la URL = {url}"
        raise RuntimeError(f"{DB_NOT_RESPONSE[0]}|{DB_NOT_RESPONSE[1]}|{error_msg}")
    
    except requests.exceptions.RequestException as e:
        if _debug:
            print(f"Error al consultar {url} \n Error = {e}")
        error_msg = f"Conexion rechazada por URL = {url}"
        raise RuntimeError(f"{DB_URL_ERROR[0]}|{DB_URL_ERROR[1]}|{error_msg}")


## Funcion para realizar consultas a una URL con timeout de 5 segundos usando filtros
def get_request_to_url_with_filters(url: str, 
                                    timeout : int = TIMEOUT_API_REQUEST, 
                                    filter_array : list = [], 
                                    _debug : bool = False) -> list:
    if len(filter_array) != 2:
        return []
    
    for _value in filter_array:
        if _value == "":
            return []

    try:
        column_filter, value_filter = filter_array
        full_url = url + f"/{column_filter}/{value_filter}"
        
        if _debug:
            print(f"URL API = {full_url}")
        
        response = requests.get(full_url, timeout=timeout)
        #print("GET URL:", response.url)
        response.raise_for_status()  # Lanza una excepción si el código de estado es 4xx o 5xx
        
        inventario_data = response.json()
        if not isinstance(inventario_data, list):
            if _debug:
                print(f"No se obtuvo un formato list en {url} : {type(inventario_data)}")
            return []

        # Filtrar solo los valores que contienen la clave
        result_list = [record for record in inventario_data]
        return result_list

    except requests.exceptions.ConnectTimeout as e:
        if _debug:
            print(f"✘ Timeout de conexión:\n{e}")
        error_msg = f"No hubo respuesta de la URL = {url}"
        raise RuntimeError(f"{DB_NOT_RESPONSE[0]}|{DB_NOT_RESPONSE[1]}|{error_msg}")
    
    except requests.exceptions.RequestException as e:
        if _debug:
            print(f"Error al consultar {url} \n Error = {e}")
        error_msg = f"Conexion rechazada por URL = {url}"
        raise RuntimeError(f"{DB_URL_ERROR[0]}|{DB_URL_ERROR[1]}|{error_msg}")


## Funcion para realizar POST request a la API
def post_request_to_url_model_array(url: str, 
                                    timeout : int = TIMEOUT_API_REQUEST, 
                                    array_model_to_post : list = [], 
                                    _debug : bool = False) -> None:
    if not array_model_to_post:
        return
    
    try:
        response = requests.post(
            url, 
            json = [obj.model_dump() for obj in array_model_to_post], 
            timeout = timeout
        )
        if _debug:
            print("POST URL:", response.url)
        status_code = response.status_code  
        response.raise_for_status()  # Automatically raises an exception for 4xx/5xx errors
        print(f"- ✔ Successfully added {len(array_model_to_post)} records to the database.")
    
    except requests.exceptions.ConnectTimeout as e:
        if _debug:
            print(f"✘ Timeout de conexión:\n{e}")
        error_msg = f"No hubo respuesta de la URL = {url}"
        raise RuntimeError(f"{DB_NOT_RESPONSE[0]}|{DB_NOT_RESPONSE[1]}|{error_msg}")
    
    except requests.exceptions.ConnectionError as e:
        if _debug:
            print(f"✘ Error de conexión:\n{e}")
        error_msg = f"Conexion rechazada, API no establecida en {url}"
        raise RuntimeError(f"{DB_URL_ERROR[0]}|{DB_URL_ERROR[1]}|{error_msg}")

    except requests.exceptions.HTTPError as e:
        if _debug:
            print(f"✘ HTTP error ({status_code}):\n{e}")
        if status_code == 500:
            name_table = url.strip("/").split("/")[-2]
            error_msg = f"Problemas de compatibilidad en la tabla de {name_table.upper()} con los datos a ingresar"
            raise RuntimeError(f"{TABLE_ERROR[0]}|{TABLE_ERROR[1]}|{error_msg}")
        elif status_code == 404:
            endpoint_value = "/" + "/".join(url.split("/")[3:])
            error_msg = f"No hay Endpoint habilitado para {endpoint_value}"
            raise RuntimeError(f"{DB_URL_ERROR[0]}|{DB_URL_ERROR[1]}|{error_msg}")
        elif status_code == 422:
            name_table = url.strip("/").split("/")[-2]
            error_msg = f"Se detecto un valor incompatible con {name_table.upper()}"
            raise RuntimeError(f"{TABLE_ERROR[0]}|{TABLE_ERROR[1]}|{error_msg}")
        else:
            print(str(e))
        return

    except requests.exceptions.RequestException as e:
        if _debug:
            print(f"✘ Error no manejado de requests:\n{e}")
        return


if __name__ == "__main__":
    print(f"IP obtenida = {ip_address} | {DB_API_URL}")