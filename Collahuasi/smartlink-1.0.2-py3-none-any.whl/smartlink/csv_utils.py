import csv
import os

# Funcion para guardar data de diccionarios en un csv
def save_dictionary_to_csv(file_name: str, data: dict):
    # Ordenar las keys: 'ip' primero (si existe), luego el resto
    fieldnames = []
    if "ip" in data.keys():
        fieldnames.append("ip")
    fieldnames.extend([key for key in data.keys() if key != "ip"])
    file_exists = os.path.isfile(file_name)

    with open(file_name, mode="a", newline="") as file:
        writer = csv.DictWriter(file, fieldnames = fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(data)


## Function for Printing the Log File 
def write_log_files(file_name : str, array_models_with_data : list = []):
    if not array_models_with_data:  # Prevent empty writes
        return
    
    # Generar un log de este script en outputs
    with open(file_name, mode='a', newline='', encoding='utf-8') as csv_file:
        fieldnames = array_models_with_data[0].model_dump().keys()
        ordered_fieldnames = ['ip', 'fecha'] + [key for key in fieldnames if key not in ['ip', 'fecha']]
        writer = csv.DictWriter(csv_file, fieldnames = ordered_fieldnames)
        writer.writerows([obj.model_dump() for obj in array_models_with_data])


## Vacia el archivo log y coloca las columnas nombres
def restart_log_file(file_name : str , model):
    # Overwrite the file initially with column names only
    with open(file_name, mode='w', newline='', encoding='utf-8') as csv_file:
        fieldnames = model.model_fields.keys()
        ordered_fieldnames = ['ip', 'fecha'] + [key for key in fieldnames if key not in ['ip', 'fecha']]
        writer = csv.DictWriter(csv_file, fieldnames=ordered_fieldnames)
        writer.writeheader()  # Write only the column names



