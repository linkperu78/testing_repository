from smartlink.error_utils import SSH_LOG_ERROR, SSH_COMMAND_EXEC_ERROR, KEYNAME_ERROR_DICT
import paramiko

class mySSHClient:
    def __init__(self, ip_target: str, user_ssh: str, password_ssh: str, debug_mode: bool = False, timeout: int = 10):
        self.ip_target      = ip_target
        self.user_ssh       = user_ssh
        self.password_ssh   = password_ssh
        self.debug_mode     = debug_mode
        self.timeout        = timeout
        self.client         = None

    """ Tratamos de crear una conexion SSH """
    def _connect(self):
        try:
            if not self.password_ssh:
                if self.debug_mode: print(f"There is no password set for {self.user_ssh}")
                _error_msg = "No hay contraseña asignada"
                raise RuntimeError(_error_msg)

            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.client.connect(self.ip_target, 
                                username    = self.user_ssh, 
                                password    = self.password_ssh, 
                                timeout     = self.timeout)
            return True
            
        except paramiko.AuthenticationException as e:
            if self.debug_mode:
                print(f"Authentication failed for {self.user_ssh}@{self.ip_target}: {e}")
            _error_msg = f"{SSH_LOG_ERROR[0]}|{SSH_LOG_ERROR[1]}|Autenticación SSH fallida: usuario o contraseña incorrectos."
            raise RuntimeError(_error_msg)
        except paramiko.SSHException as e:
            if self.debug_mode:
                print(f"SSH protocol error with {self.ip_target}: {e}")
            _error_msg = f"{SSH_LOG_ERROR[0]}|{SSH_LOG_ERROR[1]}|Error en el protocolo SSH: conexión rechazada, clave inválida u otro problema."
            raise RuntimeError(_error_msg)
        except Exception as e:
            if self.debug_mode:
                print(f"Unexpected SSH error with {self.ip_target}: {e}")
            _error_msg = f"{SSH_LOG_ERROR[0]}|{SSH_LOG_ERROR[1]}|Error inesperado al conectar por SSH: {e}"
            raise RuntimeError(_error_msg)
        

    """ Verifica si la conexión SSH sigue activa """
    def _is_client_connected(self):
        try:
            transport = self.client.get_transport()
            return transport is not None and transport.is_active()
        except Exception:
            return False


    def _msg_ssh(self, _command, _timeout):
        try:
            _, stdout, stderr = self.client.exec_command(_command, timeout=_timeout)
            stdout_output = stdout.read().decode()
            stderr_output = stderr.read().decode().strip()

            if stderr_output:
                raise RuntimeError(f"{SSH_COMMAND_EXEC_ERROR[0]}|{SSH_COMMAND_EXEC_ERROR[1]}|{stderr_output}")

            return stdout_output

        except Exception as e:
            raise RuntimeError(f"{SSH_COMMAND_EXEC_ERROR[0]}|{SSH_COMMAND_EXEC_ERROR[1]}|{e}")


    def execute_command(self, _command: str, _timeout : int = 3):
        # Verificar si la conexión está activa, si no, intentar conectarse
        if not self.client or not self._is_client_connected():
            if self.debug_mode: 
                print("SSH session is not active. Attempting to establish connection...")
            self._connect()

        return self._msg_ssh(_command, _timeout)


    # TODO Implementar un sistema persistente de varios intentos
    def execute_command_secure(self, _command: str, _timeout : int = 3, max_retries : int = 2):
        # Verificar si la conexión está activa, si no, intentar conectarse
        if not self.client or not self._is_client_connected():
            if self.debug_mode: 
                print("SSH session is not active. Attempting to establish connection...")
            self._connect()

        return self._msg_ssh(_command, _timeout)


    def close_client(self):
        if self.client:
            if self.debug_mode:
                print(f"Cerrando conexión SSH con {self.ip_target}")
            self.client.close()
            self.client = None


    def mapping_command_ssh(self, list_command_ssh : list, _timeout_per_command : int = 3, persistent : bool = False) -> dict:
        result_dict = {}
        warning_once = True
        for command in list_command_ssh:
            try:
                result = (
                    self.execute_command_secure(command, _timeout_per_command)
                    if persistent
                    else self.execute_command(command, _timeout_per_command)
                )
                result_dict[command] = result
            except Exception as e:
                if self.debug_mode:
                    if persistent and warning_once:
                        print("Fallo en persistente")
                        warning_once = False
                    elif not persistent:
                        print("Error en clase mySSHClient - función: mapping_command_ssh")

                if persistent:
                    result_dict[command] = None
                else:
                    result_dict[KEYNAME_ERROR_DICT] = str(e)
                    break

        self.close_client()
        return result_dict

