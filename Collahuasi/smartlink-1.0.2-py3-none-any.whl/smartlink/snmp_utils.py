from smartlink.error_utils import SNMP_LOG_ERROR, KEYNAME_ERROR_DICT
import subprocess

TIMEOUT_SNMP_QUERY  = 5

class mySNMPClient():
    def __init__(self, ip_target: str = None, timeout = 2, debug_mode: bool = False):
        self.ip_target      = ip_target
        self.debug_mode     = debug_mode
        self.snmp_header    = None
        self.time_out       = timeout
        self.credentials    = None

    def update_credentials(self, new_credentials: dict) -> None:
        try:
            version = int(new_credentials.get("version", 2))
            if version not in (1, 2, 3):
                version = 2
        except (ValueError, TypeError):
            version = 2

        version_str = "2c" if version == 2 else str(version)
        header = ["snmpwalk", "-v", version_str]
        get = new_credentials.get

        if version == 3:
            header += [
                "-l", get("mode", "noAuthNoPriv"),
                "-u", get("user", "no_user"),
                "-a", get("auth_mode", "MD5"),
                "-A", get("auth_pass", "no_AUTH_pass"),
                "-x", get("priv_mode", "AES"),
                "-X", get("priv_pass", "no_PRIV_pass")
            ]
        else:
            community = get("comunidad") or "public"
            header += ["-c", community]

        header += ["-O", "nq", "-t", str(max(self.time_out - 1, 1)), self.ip_target]

        if self.debug_mode:
            print(f'DEBUG: HEADER {self.ip_target} = "{" ".join(header)}"')
        self.credentials = new_credentials
        self.snmp_header = header


    def _get_snmp_data(self, oid_code, format_multiple = dict):
        command_snmp = self.snmp_header.copy() if self.snmp_header else None

        if not command_snmp:
            if self.debug_mode:
                print(f"No hay configuracion de prefijo comando snmp válida")
            raise RuntimeError("No se tiene una configuración SNMP establecida.")
        
        command_snmp.append(oid_code)

        values = {}
        try:
            result = subprocess.run(
                command_snmp, capture_output = True, text = True, check = True, timeout = self.time_out
            )
            output = result.stdout.strip()
            
            if self.debug_mode:
                print(f"Debug OID result: \"{oid_code}\"\n{output}")

            if "No Such " in output:
                if self.debug_mode:
                    print(f" -> No se encuentra el OID {oid_code} en la ip {self.ip_target}")
                return None
        
        except FileNotFoundError as e:
            if self.debug_mode:
                print(f"Commando inválido para Ubuntu: {self.snmp_header}")
            _error_msg = f"Comando inválido : '{self.snmp_header}'"
            raise RuntimeError(_error_msg)

        except subprocess.CalledProcessError as e:
            e_msg = str(e.stderr).strip()
            if self.debug_mode:
                print(f"SNMP error: {e_msg}")
            _error_msg = f"Error no contemplado : '{e_msg}'" if "host" not in e.stderr else f"IP invalida : {self.ip_target}"
            raise RuntimeError(_error_msg)
        
        except subprocess.TimeoutExpired:
            if self.debug_mode:
                print(f"SNMP request timed out en el OID '{oid_code}'")
            error_msg = f"Conexion SNMP rechazada = {self.credentials}"
            raise RuntimeError(f"{SNMP_LOG_ERROR[0]}|{SNMP_LOG_ERROR[1]}|{error_msg}")
        
        lines = output.split("\n")

        ## Formato DICT
        if format_multiple == dict:
            values = {}
            for line in lines:
                parts = line.split(" ", 1)
                if len(parts) == 2:
                    oid_str, value = parts
                    index = oid_str.split(".")[-1]
                    values[index] = value.strip().strip('"')
            if len(values) == 1:
                return next(iter(values.values()))
            return values
        
        ## Formato LIST
        elif format_multiple == list:
            temp_values = []
            for line in lines:
                parts = line.split(" ", 1)
                if len(parts) == 2:
                    oid_str, value = parts
                    index = int(oid_str.split(".")[-1])
                    temp_values.append((index, value.strip().strip('"')))

            if len(temp_values) == 1:
                return temp_values[0][1]  # Devuelve el valor limpio

            return [v for _, v in sorted(temp_values)]

        ## Formato ORIGINAL
        else:
            if len(lines) == 1:
                return lines[0].split(" ", 1)[1].strip().strip('"')
            else:
                return output  # Devuelve el bloque crudo si hay varias líneas


    def mapping_OID_dict(self, dict_snmp : dict = {}, _format = dict) -> dict:
        ## Si no hay valores en el diccionario
        if not dict_snmp:
            if self.debug_mode:
                print("No hay valores a mapear, regresando matriz vacía")    
            return {}

        return_dict = {}
        sucess_read = 0
        for name_oid, code_oid in dict_snmp.items():
            try:
                current_value_oid = self._get_snmp_data(code_oid, format_multiple=_format)
                if current_value_oid:
                    sucess_read += 1
                return_dict[name_oid] = current_value_oid
            except Exception as e:
                sucess_read += 1
                return_dict[KEYNAME_ERROR_DICT] = str(e)
                if self.debug_mode:
                    print(f"Error al obtener OID '{name_oid}': {e}")
                break

        if sucess_read:
            return return_dict
        
        return {}


    def get_single_OID(self, oid_code : str, _format = dict):
        try:
            current_value_oid = self._get_snmp_data(oid_code, format_multiple=_format)
            return  current_value_oid
        except Exception as e:
            return e
            

    def merged_keys_with_data_list(self, snmp_dict, keys_to_merge, index_key) -> dict:
        return {
            **{
                idx: dict(zip(keys_to_merge, row))
                for idx, row in zip(snmp_dict[index_key], zip(*(snmp_dict[key] for key in keys_to_merge)))
            },
            **(
                {"sysDescr": f"{snmp_dict['sysDescr']}"} if "sysDescr" in snmp_dict else {}
            ),
            **(
                {"sysUpTime": snmp_dict["sysUpTime"]} if "sysUpTime" in snmp_dict else {}
            )
        }


if __name__ == "__main__":
    ## Test para pruebas
    test_class = mySNMPClient("192.168.2.65", timeout = 10, debug_mode = False)
    my_snmp_dict = {
        "version" : 2,
        "comunidad" : "public"
    }
    test_class.update_credentials(my_snmp_dict)
    request_dict = {
        "private"   : "1.3.6.1.4.1.34861.1",
        "new"       : "1.3.6.1.4.1.34861.2",
        "test"      : "1.3.6.1.4.1.34861.22",
        "public"    : "1.3.6.1.2.1.4.34.1.10.2.16.254.128.0.0.0.0.0.0.134.141.132.255.254.254.157",
    }
    import time

    current_time = time.time()
    a = test_class.mapping_OID_dict(request_dict)
    elapse_time = round(time.time() - current_time, 2)
    print(f" --->  Tiempo transcurrido = {elapse_time}\n")
    if a:
        for _a, _b in a.items():
            print(f"\n{_a} : {_b}")
    else:
        print(f"No hay valores")