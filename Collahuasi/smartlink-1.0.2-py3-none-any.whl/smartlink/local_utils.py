import subprocess

def ping_host(host, total_time_max :int = 5 ,_debug : bool = False) -> float:
    try:
        ping_timeout = (total_time_max * 10) // 3
        ping_timeout = str(ping_timeout/10)
        
        # Ejecutar el comando `ping` del sistema
        result = subprocess.run(
            ['ping', '-c', '3', '-W', ping_timeout, host],  # -c %d: #d intentos, -W %f: timeout en segundos
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        if result.returncode == 0:
            # Parsear el tiempo promedio de RTT del resultado
            for line in result.stdout.splitlines():
                if "avg" in line:  # Buscar la línea con estadística (summary)
                    return float(line.split('=')[1].split('/')[1])  # Extraer el RTT promedio

        return -1 # Fallo en el ping

    except Exception as e:
        if _debug:
            print(f"Error running ping for {host}: {e}")
        return -1


def print_index_models_from_array(model_list: list, num_rows: int = 3):
    if not model_list:
        print("Empty list.")
        return

    # Obtener campos desde la clase del primer elemento
    field_names = list(model_list[0].model_fields.keys())

    # Imprimir cabecera
    print(" - ".join(field_names))

    # Imprimir filas
    for item in model_list[:num_rows]:
        values = [str(getattr(item, field)) for field in field_names]
        print(" - ".join(values))
