import json
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import pandas as pd

from eventos.core.config import get_config_manager
from eventos.core.api_client import get_api_client, calcular_recurrencia, round_to_nearest_quarter_hour
from eventos.utils.time_utils import get_current_iso_string, get_default_date_range


class EventosService:
    """Servicio para deteccion y procesamiento de eventos de equipos."""
    
    def __init__(self):
        """Inicializa el servicio de eventos."""
        self.config_manager = get_config_manager()
        self.api_client = get_api_client()
    
    def obtener_umbrales_urgencia(self) -> Dict[str, Any]:
        """
        Obtiene los umbrales de urgencia desde la configuracion.
        
        Returns:
            dict: Umbrales de urgencia configurados
        """
        config = self.config_manager.get_config()
        umbrales = config.get("umbrales_urgencia", {})
        
        # Umbrales por defecto si no estan configurados
        umbrales_default = {
            "latencia": {
                "alerta": 100,
                "alarma": 200,
                "recurrencia_alerta": 3,
                "recurrencia_alarma": 2
            },
            "interferencia": {
                "snr_h": {
                    "alerta": 20,
                    "alarma": 15,
                    "recurrencia_alerta": 2,
                    "recurrencia_alarma": 2
                },
                "snr_v": {
                    "alerta": 20,
                    "alarma": 15,
                    "recurrencia_alerta": 2,
                    "recurrencia_alarma": 2
                }
            },
            "temperatura": {
                "alerta": 70,
                "alarma": 85,
                "recurrencia_alerta": 2,
                "recurrencia_alarma": 1
            }
        }
        
        # Combinar configuracion con defaults
        for categoria, valores in umbrales_default.items():
            if categoria not in umbrales:
                umbrales[categoria] = valores
            else:
                # Agregar valores faltantes
                if isinstance(valores, dict):
                    for subcategoria, subvalores in valores.items():
                        if subcategoria not in umbrales[categoria]:
                            umbrales[categoria][subcategoria] = subvalores
                        elif isinstance(subvalores, dict):
                            for clave, valor in subvalores.items():
                                if clave not in umbrales[categoria][subcategoria]:
                                    umbrales[categoria][subcategoria][clave] = valor
        
        return umbrales
    
    def clasificar_latencia(self, latencia: float, umbrales: Dict[str, Any]) -> Tuple[str, bool]:
        """
        Clasifica una latencia segun los umbrales configurados.
        
        Args:
            latencia: Valor de latencia en ms
            umbrales: Umbrales de urgencia
            
        Returns:
            tuple: (estado, requiere_urgencia_por_valor)
        """
        umbrales_latencia = umbrales.get("latencia", {})
        alarma_threshold = umbrales_latencia.get("alarma", 200)
        alerta_threshold = umbrales_latencia.get("alerta", 100)
        
        if latencia >= alarma_threshold:
            return "Alarma", True
        elif latencia >= alerta_threshold:
            return "Alerta", False
        else:
            return "Normal", False
    
    def clasificar_snr(
        self, 
        snr_value: float, 
        snr_type: str, 
        umbrales: Dict[str, Any]
    ) -> Tuple[str, bool]:
        """
        Clasifica un valor SNR segun los umbrales configurados.
        
        Args:
            snr_value: Valor SNR
            snr_type: Tipo de SNR (snr_h o snr_v)
            umbrales: Umbrales de urgencia
            
        Returns:
            tuple: (estado, requiere_urgencia_por_valor)
        """
        umbrales_interferencia = umbrales.get("interferencia", {})
        umbrales_snr = umbrales_interferencia.get(snr_type, {})
        
        alarma_threshold = umbrales_snr.get("alarma", 15)
        alerta_threshold = umbrales_snr.get("alerta", 20)
        
        if snr_value <= alarma_threshold:
            return "Alarma", True
        elif snr_value <= alerta_threshold:
            return "Alerta", False
        else:
            return "Normal", False
    
    def es_evento_urgente(
        self, 
        estado: str, 
        recurrencia: int, 
        tipo_evento: str, 
        subtipo: Optional[str] = None,
        umbrales: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Determina si un evento es urgente basado en estado, recurrencia y configuracion.
        
        Args:
            estado: Estado del evento (Alerta/Alarma)
            recurrencia: Numero de recurrencias
            tipo_evento: Tipo de evento (latencia, interferencia, temperatura)
            subtipo: Subtipo para interferencias (snr_h, snr_v)
            umbrales: Umbrales de urgencia (se obtienen si no se proporcionan)
            
        Returns:
            bool: True si el evento es urgente
        """
        if umbrales is None:
            umbrales = self.obtener_umbrales_urgencia()
        
        # Obtener umbrales especificos
        if tipo_evento == "interferencia" and subtipo:
            config_seccion = umbrales.get("interferencia", {}).get(subtipo, {})
        else:
            config_seccion = umbrales.get(tipo_evento, {})
        
        if estado.lower() == "alarma":
            umbral_recurrencia = config_seccion.get("recurrencia_alarma", 2)
        elif estado.lower() == "alerta":
            umbral_recurrencia = config_seccion.get("recurrencia_alerta", 3)
        else:
            return False
        
        return recurrencia >= umbral_recurrencia
    
    def procesar_datos_latencia(
        self,
        start_date: str,
        end_date: str,
        limit: int = 1000,
        offset: int = 0,
        intervalo_recurrencia: int = 15
    ) -> List[Dict[str, Any]]:
        """
        Procesa datos de latencia y genera eventos.
        
        Args:
            start_date: Fecha de inicio
            end_date: Fecha de fin
            limit: Limite de registros
            offset: Offset para paginacion
            intervalo_recurrencia: Intervalo en minutos para calcular recurrencia
            
        Returns:
            list: Lista de eventos de latencia generados
        """
        print("🔍 Procesando datos de latencia...")
        
        # Obtener datos de latencia deficiente
        data_latency = self.api_client.get_poor_latency(start_date, end_date, limit, offset)
        
        if not data_latency:
            print("No se encontraron datos de latencia")
            return []
        
        print(f"Encontrados {len(data_latency)} registros de latencia")
        
        # Obtener umbrales
        umbrales = self.obtener_umbrales_urgencia()
        
        # Procesar cada registro
        eventos = []
        for registro in data_latency:
            latencia = registro.get("latencia", 0)
            ip = registro.get("ip")
            fecha_original = registro.get("fecha")
            
            # Redondear fecha a cuartos de hora
            fecha_evento = round_to_nearest_quarter_hour(
                fecha_original, 
                return_as_string=True, 
                iso_format_string=True
            )
            
            # Clasificar latencia
            estado, _ = self.clasificar_latencia(latencia, umbrales)
            
            if estado == "Normal":
                continue  # No procesar latencias normales
            
            # Calcular recurrencia
            recurrencia = calcular_recurrencia(
                api_client=self.api_client,
                ip=ip,
                fecha_evento=fecha_evento,
                tipo_evento="Senhal Deficiente",
                intervalo_recurrencia=intervalo_recurrencia
            )
            
            # Determinar si es urgente
            urgente = self.es_evento_urgente(estado, recurrencia, "latencia", umbrales=umbrales)
            
            # Crear evento
            evento = {
                "ip": ip,
                "fecha": fecha_evento,
                "nodo": "ap",
                "estado": estado,
                "problema": "Senhal deficiente",
                "detalle": {
                    "latencia": latencia
                },
                "recurrencia": recurrencia,
                "urgente": urgente
            }
            
            eventos.append(evento)
        
        print(f"✅ Generados {len(eventos)} eventos de latencia")
        return eventos
    
    def procesar_datos_cambium(
        self,
        start_date: str,
        end_date: str,
        limit: int = 1000,
        offset: int = 0,
        intervalo_recurrencia: int = 15
    ) -> List[Dict[str, Any]]:
        """
        Procesa datos de Cambium y genera eventos de interferencia.
        
        Args:
            start_date: Fecha de inicio
            end_date: Fecha de fin
            limit: Limite de registros
            offset: Offset para paginacion
            intervalo_recurrencia: Intervalo en minutos para calcular recurrencia
            
        Returns:
            list: Lista de eventos de interferencia generados
        """
        print("🔍 Procesando datos de Cambium...")
        
        # Obtener datos de Cambium
        data_cambium = self.api_client.get_cambium_data(start_date, end_date, limit, offset)
        
        if data_cambium is None or data_cambium.empty:
            print("No se encontraron datos de Cambium")
            return []
        
        print(f"Encontrados {len(data_cambium)} registros de Cambium")
        
        # Extraer valores de snr_h y snr_v desde la columna snr
        data_cambium['snr'] = data_cambium['snr'].apply(
            lambda x: json.loads(x) if isinstance(x, str) else x
        )
        
        # Separar datos por tipo de SNR
        data_snr_h = data_cambium[
            data_cambium['snr'].apply(lambda x: isinstance(x, dict) and 'snr_h' in x)
        ].copy()
        data_snr_h['snr_h'] = data_snr_h['snr'].apply(lambda x: x.get('snr_h'))
        
        data_snr_v = data_cambium[
            data_cambium['snr'].apply(lambda x: isinstance(x, dict) and 'snr_v' in x)
        ].copy()
        data_snr_v['snr_v'] = data_snr_v['snr'].apply(lambda x: x.get('snr_v'))
        
        # Obtener umbrales
        umbrales = self.obtener_umbrales_urgencia()
        
        eventos = []
        
        # Procesar SNR H
        eventos.extend(self._procesar_snr_data(
            data_snr_h, 'snr_h', umbrales, intervalo_recurrencia
        ))
        
        # Procesar SNR V
        eventos.extend(self._procesar_snr_data(
            data_snr_v, 'snr_v', umbrales, intervalo_recurrencia
        ))
        
        print(f"✅ Generados {len(eventos)} eventos de interferencia")
        return eventos
    
    def _procesar_snr_data(
        self,
        data: pd.DataFrame,
        snr_type: str,
        umbrales: Dict[str, Any],
        intervalo_recurrencia: int
    ) -> List[Dict[str, Any]]:
        """
        Procesa datos de un tipo especifico de SNR.
        
        Args:
            data: DataFrame con datos de SNR
            snr_type: Tipo de SNR (snr_h o snr_v)
            umbrales: Umbrales de urgencia
            intervalo_recurrencia: Intervalo para recurrencia
            
        Returns:
            list: Lista de eventos generados
        """
        if data.empty:
            return []
        
        eventos = []
        
        for _, registro in data.iterrows():
            snr_value = registro.get(snr_type)
            ip = registro.get("ip")
            fecha_original = registro.get("fecha")
            
            if snr_value is None:
                continue
            
            # Redondear fecha a cuartos de hora
            fecha_evento = round_to_nearest_quarter_hour(
                fecha_original,
                return_as_string=True,
                iso_format_string=True
            )
            
            # Clasificar SNR
            estado, _ = self.clasificar_snr(snr_value, snr_type, umbrales)
            
            if estado == "Normal":
                continue  # No procesar valores normales
            
            # Calcular recurrencia
            recurrencia = calcular_recurrencia(
                api_client=self.api_client,
                ip=ip,
                fecha_evento=fecha_evento,
                tipo_evento="Interferencia",
                intervalo_recurrencia=intervalo_recurrencia,
                tipo_interferencia=snr_type
            )
            
            # Determinar si es urgente
            urgente = self.es_evento_urgente(
                estado, recurrencia, "interferencia", snr_type, umbrales
            )
            
            # Crear evento
            evento = {
                "ip": ip,
                "fecha": fecha_evento,
                "nodo": "ap",
                "estado": estado,
                "problema": "Interferencia",
                "recurrencia": recurrencia,
                "urgente": urgente,
                "detalle": {
                    snr_type: snr_value,
                    "tipo_interferencia": snr_type
                }
            }
            
            eventos.append(evento)
        
        return eventos
    
    def detectar_eventos(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 1000,
        offset: int = 0,
        intervalo_recurrencia: int = 15,
        time_sleep: int = 0,
        insertar_eventos: bool = False
    ) -> Dict[str, Any]:
        """
        Ejecuta la deteccion completa de eventos.
        
        Args:
            start_date: Fecha de inicio (None para usar default)
            end_date: Fecha de fin (None para usar default)
            limit: Limite de registros
            offset: Offset para paginacion
            intervalo_recurrencia: Intervalo en minutos para recurrencia
            time_sleep: Tiempo de espera antes de ejecutar
            insertar_eventos: Si True, inserta eventos en BD (default: False)
            
        Returns:
            dict: Resultado de la deteccion con estadisticas
        """
        print("🚀 Iniciando deteccion de eventos...")
        
        # Usar fechas por defecto si no se proporcionan
        if start_date is None or end_date is None:
            start_date_default, end_date_default = get_default_date_range()
            start_date = start_date or start_date_default
            end_date = end_date or end_date_default
        
        print(f"📅 Periodo: {start_date} a {end_date}")
        print(f"⚙️ Limite: {limit}, Offset: {offset}, Recurrencia: {intervalo_recurrencia}min")
        
        if time_sleep > 0:
            print(f"⏱️ Esperando {time_sleep} segundos...")
            time.sleep(time_sleep)
        
        # Mostrar umbrales configurados
        umbrales = self.obtener_umbrales_urgencia()
        print("📊 Umbrales de urgencia configurados:")
        for tipo, config in umbrales.items():
            print(f"  - {tipo}: {config}")
        
        # Procesar latencia
        eventos_latencia = self.procesar_datos_latencia(
            start_date, end_date, limit, offset, intervalo_recurrencia
        )
        
        # Procesar interferencias
        eventos_interferencia = self.procesar_datos_cambium(
            start_date, end_date, limit, offset, intervalo_recurrencia
        )
        
        # Combinar todos los eventos
        todos_eventos = eventos_latencia + eventos_interferencia
        
        # Mostrar eventos generados como en el codigo original
        print(f"\n📋 Eventos generados: {len(todos_eventos)}")
        if todos_eventos:
            import pprint
            pp = pprint.PrettyPrinter(indent=4)
            
            print("📄 Contenido de los eventos:")
            pp.pprint(todos_eventos)
        
        # Insertar eventos en la base de datos solo si se especifica
        resultado_insercion = None
        if todos_eventos:
            if insertar_eventos:
                print(f"\n💾 Insertando {len(todos_eventos)} eventos en la base de datos...")
                api_config = self.config_manager.get_api_config()
                endpoint = api_config["eventos"]["add_list"]
                url_completa = f"{self.api_client.base_url.rstrip('/')}{endpoint}"
                print(f"📡 URL: {url_completa}")
                
                resultado_insercion = self.api_client.add_eventos_list(todos_eventos)
                
                if resultado_insercion is not None:
                    print("✅ Eventos insertados exitosamente")
                else:
                    print("❌ Error al insertar eventos")
            else:
                print(f"\nℹ️ Eventos detectados pero NO insertados")
                print("💡 Usa --insert para insertar en la base de datos")
        else:
            print("ℹ️ No hay eventos para insertar")
        
        # Generar estadisticas
        estadisticas = self._generar_estadisticas(eventos_latencia, eventos_interferencia)
        
        resultado = {
            "eventos_latencia": len(eventos_latencia),
            "eventos_interferencia": len(eventos_interferencia),
            "total_eventos": len(todos_eventos),
            "eventos_urgentes": estadisticas["urgentes"],
            "insercion_solicitada": insertar_eventos,
            "insercion_exitosa": resultado_insercion is not None if insertar_eventos else None,
            "estadisticas": estadisticas,
            "periodo": {
                "start_date": start_date,
                "end_date": end_date
            },
            "parametros": {
                "limit": limit,
                "offset": offset,
                "intervalo_recurrencia": intervalo_recurrencia,
                "insertar_eventos": insertar_eventos
            }
        }
        
        print("✅ Deteccion de eventos completada")
        print(f"📊 Resumen: {resultado['total_eventos']} eventos ({resultado['eventos_urgentes']} urgentes)")
        
        return resultado
    
    def _generar_estadisticas(
        self, 
        eventos_latencia: List[Dict], 
        eventos_interferencia: List[Dict]
    ) -> Dict[str, Any]:
        """
        Genera estadisticas de los eventos procesados.
        
        Args:
            eventos_latencia: Lista de eventos de latencia
            eventos_interferencia: Lista de eventos de interferencia
            
        Returns:
            dict: Estadisticas detalladas
        """
        todos_eventos = eventos_latencia + eventos_interferencia
        
        urgentes = sum(1 for evento in todos_eventos if evento.get("urgente", False))
        alarmas = sum(1 for evento in todos_eventos if evento.get("estado") == "Alarma")
        alertas = sum(1 for evento in todos_eventos if evento.get("estado") == "Alerta")
        
        # IPs unicas afectadas
        ips_unicas = set(evento.get("ip") for evento in todos_eventos if evento.get("ip"))
        
        return {
            "total": len(todos_eventos),
            "urgentes": urgentes,
            "alarmas": alarmas,
            "alertas": alertas,
            "latencia": len(eventos_latencia),
            "interferencia": len(eventos_interferencia),
            "ips_afectadas": len(ips_unicas),
            "porcentaje_urgentes": (urgentes / len(todos_eventos) * 100) if todos_eventos else 0
        }


# Instancia global del servicio
_eventos_service: Optional[EventosService] = None


def get_eventos_service() -> EventosService:
    """
    Retorna la instancia global del servicio de eventos.
    
    Returns:
        EventosService: Instancia del servicio
    """
    global _eventos_service
    
    if _eventos_service is None:
        _eventos_service = EventosService()
    
    return _eventos_service