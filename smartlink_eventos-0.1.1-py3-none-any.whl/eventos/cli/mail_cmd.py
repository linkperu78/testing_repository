#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comando smartlink-mail para envio de alertas por correo electronico.
Equivalente al script enviar_eventos_mail.py original.
"""

import argparse
import sys
from typing import Optional

from eventos.services.mail import get_mail_service
from eventos.core.config import get_config_manager
from eventos.utils.time_utils import get_current_iso_string


def crear_parser() -> argparse.ArgumentParser:
    """
    Crea el parser de argumentos para el comando de correo.
    
    Returns:
        ArgumentParser: Parser configurado
    """
    parser = argparse.ArgumentParser(
        description='Envio de alertas y alarmas por correo electronico',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  smartlink-mail send --empresa collahuasi                              # Envio basico
  smartlink-mail send --empresa collahuasi --hours-ago 8               # Ultimas 8 horas
  smartlink-mail send --empresa test --asunto "Alertas Urgentes"       # Asunto personalizado
  smartlink-mail send --config /path/to/config.yml --empresa test      # Config personalizada
  smartlink-mail validate-config                                       # Validar configuracion
  smartlink-mail show-config                                           # Mostrar config email
  smartlink-mail test --destinatario test@ejemplo.com                  # Correo de prueba
        """
    )
    
    # Subcomandos
    subparsers = parser.add_subparsers(dest='comando', help='Comandos disponibles')
    
    # Comando send (principal)
    send_parser = subparsers.add_parser(
        'send', 
        help='Enviar alertas por correo electronico'
    )
    
    send_parser.add_argument(
        '--empresa', 
        type=str, 
        required=True,
        help='Nombre de la empresa para las alertas (requerido)'
    )
    
    send_parser.add_argument(
        '--hours-ago', 
        type=int, 
        default=1,
        help='Numero de horas atras para buscar alertas. Default: 1'
    )
    
    send_parser.add_argument(
        '--minutes-ago', 
        type=int, 
        default=5,
        help='Numero de minutos atras para buscar alertas. Default: 5'
    )
    
    send_parser.add_argument(
        '--asunto', 
        type=str, 
        help='Asunto personalizado para el correo'
    )
    
    send_parser.add_argument(
        '--no-save-tables',
        action='store_true',
        help='No guardar tablas HTML en archivos'
    )
    
    send_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    send_parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Mostrar informacion detallada'
    )
    
    send_parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Simular envio sin enviar correo real'
    )
    
    # Comando validate-config
    validate_parser = subparsers.add_parser(
        'validate-config', 
        help='Validar configuracion de correo'
    )
    
    validate_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    # Comando show-config
    config_parser = subparsers.add_parser(
        'show-config', 
        help='Mostrar configuracion de correo'
    )
    
    config_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    config_parser.add_argument(
        '--show-password',
        action='store_true',
        help='Mostrar contraseha SMTP (usar con precaucion)'
    )
    
    # Comando test
    test_parser = subparsers.add_parser(
        'test', 
        help='Enviar correo de prueba'
    )
    
    test_parser.add_argument(
        '--destinatario', 
        type=str, 
        required=True,
        help='Email del destinatario de prueba'
    )
    
    test_parser.add_argument(
        '--asunto', 
        type=str, 
        default='Correo de prueba - Smartlink',
        help='Asunto del correo de prueba'
    )
    
    test_parser.add_argument(
        '--mensaje', 
        type=str, 
        default='Este es un correo de prueba enviado desde smartlink-mail',
        help='Mensaje del correo de prueba'
    )
    
    test_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    # Comando show-stats
    stats_parser = subparsers.add_parser(
        'show-stats', 
        help='Mostrar estadisticas de configuracion'
    )
    
    stats_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    return parser


def comando_send(args) -> int:
    """
    Ejecuta el comando de envio de alertas por correo.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida (0 = exito, 1 = error)
    """
    try:
        # Inicializar config manager si se especifica archivo personalizado
        if args.config:
            get_config_manager(args.config)
        
        # Obtener servicio de correo
        mail_service = get_mail_service()
        
        if args.verbose:
            print("📧 Parametros de envio email:")
            print(f"  - Empresa: {args.empresa}")
            print(f"  - Horas atras: {args.hours_ago}")
            print(f"  - Minutos atras: {args.minutes_ago}")
            print(f"  - Asunto personalizado: {args.asunto or 'No'}")
            print(f"  - Guardar tablas: {not args.no_save_tables}")
            print(f"  - Dry run: {args.dry_run}")
            if args.config:
                print(f"  - Config personalizado: {args.config}")
            print()
        
        # Validar configuracion antes de continuar
        if not mail_service.validar_configuracion_email():
            print("❌ Configuracion de email invalida. Usa 'smartlink-mail validate-config' para mas detalles")
            return 1
        
        if args.dry_run:
            print("🧪 MODO DRY RUN - No se enviara correo real")
            
            # Obtener alertas para mostrar lo que se enviaria
            senhal_deficientes, interferencias = mail_service.obtener_alertas_urgentes(
                args.hours_ago, args.minutes_ago
            )
            
            print(f"📊 Alertas encontradas:")
            print(f"  - Senhal deficiente: {len(senhal_deficientes)}")
            print(f"  - Interferencias: {len(interferencias)}")
            
            if senhal_deficientes or interferencias:
                print("✅ Se generarian tablas HTML y mensaje de correo")
                
                # Generar tablas para mostrar estructura
                html_tablas = mail_service.generar_tablas_html(
                    senhal_deficientes, interferencias, guardar_archivos=False
                )
                
                # Mostrar estadisticas de las tablas
                tabla_senhales_len = len(html_tablas["tabla_senhales"])
                tabla_interferencias_len = len(html_tablas["tabla_interferencias"])
                print(f"📋 Tabla senhales: {tabla_senhales_len} caracteres")
                print(f"📋 Tabla interferencias: {tabla_interferencias_len} caracteres")
                
                # Mostrar configuracion de destinatarios
                email_config = mail_service.obtener_configuracion_email()
                print(f"📤 Se enviaria a {len(email_config['destinatarios'])} destinatarios principales")
                print(f"📤 Con copia a {len(email_config.get('con_copia', []))} destinatarios")
                
            else:
                print("ℹ️ No hay alertas para enviar")
            
            return 0
        
        # Ejecutar envio real
        print(f"📧 Enviando alertas por email para {args.empresa}...")
        
        exito = mail_service.enviar_alertas_por_email(
            empresa=args.empresa,
            hours_ago=args.hours_ago,
            minutes_ago=args.minutes_ago,
            guardar_tablas=not args.no_save_tables,
            asunto_personalizado=args.asunto
        )
        
        # Mostrar resultado
        if exito:
            print("\n" + "="*60)
            print("📊 RESUMEN DE ENVIO EMAIL")
            print("="*60)
            print(f"🏢 Empresa: {args.empresa}")
            print(f"📅 Periodo: Ultimas {args.hours_ago}h {args.minutes_ago}min")
            print(f"✅ Estado: Enviado exitosamente")
            
            if args.asunto:
                print(f"📝 Asunto: {args.asunto}")
            
            if not args.no_save_tables:
                print(f"💾 Tablas HTML guardadas en archivos")
            
            # Mostrar estadisticas si verbose
            if args.verbose:
                stats = mail_service.obtener_estadisticas_configuracion()
                print(f"\n📊 Estadisticas de configuracion:")
                print(f"  - Remitente: {stats['remitente']}")
                print(f"  - Destinatarios principales: {stats['total_destinatarios']}")
                print(f"  - Destinatarios en copia: {stats['total_con_copia']}")
                print(f"  - Servidor SMTP: {stats['smtp_server']}:{stats['smtp_puerto']}")
            
            print("="*60)
            return 0
        else:
            print("❌ Fallo el envio del correo")
            return 1
        
    except Exception as e:
        print(f"❌ Error en envio de email: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


def comando_validate_config(args) -> int:
    """
    Valida la configuracion de correo.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager
        if args.config:
            get_config_manager(args.config)
        
        mail_service = get_mail_service()
        
        print("🔍 VALIDACION DE CONFIGURACION EMAIL")
        print("="*50)
        
        # Validar configuracion
        es_valida = mail_service.validar_configuracion_email()
        
        # Obtener estadisticas detalladas
        stats = mail_service.obtener_estadisticas_configuracion()
        
        if 'error' in stats:
            print(f"❌ Error obteniendo configuracion: {stats['error']}")
            return 1
        
        print(f"📧 Remitente: {stats['remitente']}")
        print(f"🌐 Servidor SMTP: {stats['smtp_server']}:{stats['smtp_puerto']}")
        print(f"👥 Destinatarios principales: {stats['total_destinatarios']}")
        print(f"📋 Destinatarios en copia: {stats['total_con_copia']}")
        print(f"✅ Configuracion valida: {'Si' if es_valida else 'No'}")
        
        if es_valida:
            print("\n🎉 Configuracion de email es correcta y lista para usar")
            return 0
        else:
            print("\n❌ Configuracion de email tiene problemas")
            print("💡 Revisa el archivo configEventos.yml seccion 'email'")
            return 1
        
    except Exception as e:
        print(f"❌ Error validando configuracion: {e}")
        return 1


def comando_show_config(args) -> int:
    """
    Muestra la configuracion de correo.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager
        config_manager = get_config_manager(args.config)
        email_config = config_manager.get_email_config()
        
        print("📧 CONFIGURACION DE EMAIL")
        print("="*40)
        
        # Mostrar configuracion (ocultar contraseha por defecto)
        for key, value in email_config.items():
            if key == 'smtp_password' and not args.show_password:
                print(f"{key}: {'*' * len(str(value)) if value else 'No configurada'}")
            elif isinstance(value, list):
                print(f"{key}: {len(value)} elementos")
                for i, item in enumerate(value, 1):
                    print(f"  {i}. {item}")
            else:
                print(f"{key}: {value}")
        
        print("="*40)
        
        if not args.show_password and email_config.get('smtp_password'):
            print("💡 Usa --show-password para mostrar la contraseha SMTP")
        
        return 0
        
    except Exception as e:
        print(f"❌ Error mostrando configuracion: {e}")
        return 1


def comando_test(args) -> int:
    """
    Envia un correo de prueba.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager si se especifica
        if args.config:
            get_config_manager(args.config)
        
        # Obtener servicio y configuracion
        mail_service = get_mail_service()
        email_config = mail_service.obtener_configuracion_email()
        
        print(f"🧪 Enviando correo de prueba a: {args.destinatario}")
        print(f"📝 Asunto: {args.asunto}")
        
        # Crear mensaje HTML simple
        fecha_actual = get_current_iso_string()
        html_mensaje = f"""
        <html>
            <body>
                <h2>Correo de Prueba - Smartlink</h2>
                <p>{args.mensaje}</p>
                <p><strong>Fecha de prueba:</strong> {fecha_actual}</p>
                <p><strong>Remitente:</strong> {email_config['remitente']}</p>
                <hr>
                <p><em>Este es un correo automatizado de prueba.</em></p>
            </body>
        </html>
        """
        
        # Enviar correo
        exito = mail_service.enviar_correo_html(
            remitente=email_config["remitente"],
            clave=email_config["smtp_password"],
            destinatarios=[args.destinatario],
            con_copia=[],
            asunto=args.asunto,
            html=html_mensaje
        )
        
        if exito:
            print(f"✅ Correo de prueba enviado exitosamente")
            return 0
        else:
            print(f"❌ Fallo el envio del correo de prueba")
            return 1
        
    except Exception as e:
        print(f"❌ Error en correo de prueba: {e}")
        return 1


def comando_show_stats(args) -> int:
    """
    Muestra estadisticas de configuracion.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager
        if args.config:
            get_config_manager(args.config)
        
        mail_service = get_mail_service()
        stats = mail_service.obtener_estadisticas_configuracion()
        
        print("📊 ESTADISTICAS EMAIL")
        print("="*30)
        
        if 'error' in stats:
            print(f"❌ Error: {stats['error']}")
            return 1
        
        print(f"📧 Remitente configurado: {'Si' if stats['remitente'] != 'No configurado' else 'No'}")
        print(f"👥 Total destinatarios: {stats['total_destinatarios'] + stats['total_con_copia']}")
        print(f"  - Principales: {stats['total_destinatarios']}")
        print(f"  - En copia: {stats['total_con_copia']}")
        print(f"🌐 Servidor: {stats['smtp_server']}:{stats['smtp_puerto']}")
        print(f"✅ Configuracion valida: {'Si' if stats['configuracion_valida'] else 'No'}")
        
        print("="*30)
        
        return 0
        
    except Exception as e:
        print(f"❌ Error mostrando estadisticas: {e}")
        return 1


def main():
    """Funcion principal del comando smartlink-mail."""
    parser = crear_parser()
    args = parser.parse_args()
    
    # Si no se especifica comando, mostrar ayuda
    if not args.comando:
        parser.print_help()
        return 0
    
    # Ejecutar comando correspondiente
    if args.comando == 'send':
        return comando_send(args)
    elif args.comando == 'validate-config':
        return comando_validate_config(args)
    elif args.comando == 'show-config':
        return comando_show_config(args)
    elif args.comando == 'test':
        return comando_test(args)
    elif args.comando == 'show-stats':
        return comando_show_stats(args)
    else:
        print(f"❌ Comando desconocido: {args.comando}")
        return 1


if __name__ == "__main__":
    sys.exit(main())