import os
from typing import Optional
from openai import OpenAI
from dotenv import load_dotenv


class ChatGPTClient:
    """Cliente para interacciones con ChatGPT/OpenAI."""
    
    def __init__(self, api_key: Optional[str] = None, dotenv_path: Optional[str] = None):
        """
        Inicializa el cliente de ChatGPT.
        
        Args:
            api_key: API key de OpenAI. Si no se proporciona, se lee del .env
            dotenv_path: Ruta especifica al archivo .env. Si es None, usa ubicacion estandar
        """
        # Cargar variables de entorno
        if dotenv_path:
            load_dotenv(dotenv_path)
        else:
            # Buscar .env en ubicaciones estandar
            self._load_env_from_standard_locations()
        
        # Obtener API key
        if api_key:
            self.api_key = api_key
        else:
            self.api_key = os.getenv("OPEN_API_KEY")
            if not self.api_key:
                raise ValueError(
                    "API key de OpenAI no encontrada. "
                    "Asegurate de que OPEN_API_KEY este definida en tu archivo .env "
                    "o pasala directamente al constructor."
                )
        
        # Inicializar cliente de OpenAI
        self.client = OpenAI(api_key=self.api_key)
        print(f"✅ Cliente ChatGPT inicializado con API key: {self.api_key[:8]}...")
    
    def _load_env_from_standard_locations(self) -> None:
        """
        Carga el archivo .env desde ubicaciones estandar.
        Busca en:
        1. Directorio actual
        2. /usr/smartlink/eventos/.env (ubicacion legacy)
        3. Directorio del proyecto
        """
        env_locations = [
            # Directorio actual
            ".env",
            # Ubicacion legacy
            "/usr/smartlink/eventos/.env",
            # Directorio del proyecto (eventos/)
            os.path.join(os.path.dirname(__file__), "..", "..", "..", ".env")
        ]
        
        for env_path in env_locations:
            if os.path.exists(env_path):
                load_dotenv(env_path)
                print(f"✅ Archivo .env cargado desde: {env_path}")
                return
        
        print("⚠️ No se encontro archivo .env en ubicaciones estandar")
    
    def mensaje_chat_gpt(
        self, 
        mensaje: str, 
        model: str = "gpt-4o-mini", 
        is_windows: bool = False
    ) -> str:
        """
        Envia un mensaje a ChatGPT y retorna la respuesta.
        
        Args:
            mensaje: Mensaje/prompt para enviar a ChatGPT
            model: Modelo de OpenAI a usar
            is_windows: Si True, sanitiza saltos de linea para Windows
            
        Returns:
            Respuesta de ChatGPT como string
        """
        try:
            response = self.client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "user", "content": mensaje},
                ]
            )
            
            chat_mensaje = response.choices[0].message.content
            
            # Sanitizar para Windows si es necesario
            if is_windows:
                chat_mensaje = chat_mensaje.replace("\n", "\\n")
            
            return chat_mensaje
            
        except Exception as e:
            print(f"❌ Error al comunicarse con ChatGPT: {e}")
            raise
    
    def generar_mensaje_whatsapp(
        self, 
        alertas: list, 
        tipo_alerta: str, 
        empresa: str, 
        num_messages: int = 10
    ) -> Optional[str]:
        """
        Genera un mensaje para WhatsApp basado en las alertas.
        
        Args:
            alertas: Lista de alertas
            tipo_alerta: Tipo de alerta ("senhal deficiente" o "interferencias")
            empresa: Nombre de la empresa
            num_messages: Numero maximo de mensajes
            
        Returns:
            Mensaje generado para WhatsApp o None si no hay alertas
        """
        print(f"alertas recibidas:\n{alertas}")
        print(f"Generando mensaje de alerta para {tipo_alerta}. Cantidad de alertas: {len(alertas)}")
        
        if not alertas:
            return None  # No generamos mensaje si no hay alertas
        
        if tipo_alerta == "senhal deficiente":
            valor = "latencia"
        else:
            valor = "interferencia"
            
        mensaje_prompt = f"""
        Eres un asistente que generara un informe breve para WhatsApp sobre {tipo_alerta}. Estas alertas las detecta un producto de software de HC-GROUP (Asi tal cual, todas las letras en mayusculas y con el guion) llamado "Smartlink" el cual es un software para monitoreo de equipos de telecomunicaciones en faenas mineras. En cuestion haras el resumen del turno, de las ultimas 8 horas.
        
        Recuerda ser cordial y presentarte brevemente (SIN SALUDAR PORQUE EL SALUDO YA SE HACE ANTES DE QUE TE LLEGUE ESTA INFO A TI), en modo de introduccion. En la introduccion menciona que el mensaje proviene de Smartlink de HC-Group para ayudar a {empresa} (solo menciona esto pero en tus palabras no agregues nada mas que sea redundante), y tambien menciona el para que es este mensaje. Se breve. Comienza con algo asi de "Este es un mensaje de "
        
        Aqui esta la lista de eventos:
        {alertas}

        Genera un mensaje de alerta que resuma los eventos mas urgentes, destacando los de mayor prioridad.
        Usa emojis 🔴 para Alarmas y 🟡 para Alertas. Limita el mensaje a {num_messages} eventos.
        El formato debe ser claro y conciso, como:
        - [Fecha] 🔴 Equipo X - Marca - promedio del valor de {valor} - 5 veces
        - [Fecha] 🟡 Equipo Y - Marca - promedio del valor de {valor} - 2 veces

        DETALLES IMPORTANTES A CONSIDERAR:
        - El valor de recurrencia se refiere a que un equipo se ha repetido un valor importante a considerar en un rango de fechas de 15 minutos. Por ejemplo si un equipo tuvo latencia alta a las 17:00:00 y luego a las 17:15:00, entonces tendra dos valores pero uno tendra recurrencia 2. Solo muestra el valor de mayor recurrencia y el promedio de su valor, NO REPITAS EQUIPOS.
        - No obstante a veces puede ser que un equipo presento valores importantes criticos en horas distintas. En ese caso si hay que agregarlos. TEN SIEMPRE EN CUENTA EL VALOR DE RECURRENCIA!.
        - Ordenalos por fecha del mas antiguo al mas nuevo.
        
        Recomienda que tomen medidas o que esten atentos a estos equipos.
        Aclara que es un mensaje automatizado y que no debe responderse.
        SOLO ESCRIBE EL MENSAJE, NADA MAS.
        """

        return self.mensaje_chat_gpt(mensaje_prompt)
    
    def generar_mensaje_correo(
        self, 
        html_tablas: dict, 
        empresa: str
    ) -> str:
        """
        Genera un mensaje HTML para correo electronico.
        
        Args:
            html_tablas: Diccionario con tablas HTML generadas
            empresa: Nombre de la empresa
            
        Returns:
            Mensaje HTML para el correo
        """
        mensaje_prompt = f""" 
        Eres un asistente que generara un informe breve para enviar por email sobre alertas y alarmas relacionados a latencias altas y a interferencias. Estas alertas las detecta un producto de software de HC-GROUP (Asi tal cual, todas las letras en mayusculas y con el guion) llamado "Smartlink" el cual es un software para monitoreo de equipos de telecomunicaciones en faenas mineras. En cuestion haras el resumen del turno, de las ultimas 8 horas.
        
        Recuerda ser cordial y presentarte brevemente, y saluda al equipo de {empresa}, en modo de introduccion. En la introduccion menciona que el mensaje proviene de Smartlink de HC-Group para ayudar a {empresa} (solo menciona esto pero en tus palabras no agregues nada mas que sea redundante), y tambien menciona el para que es este mensaje. Se breve. Comienza con algo asi de "Este es un mensaje de ".
        
        Los valores estan en estas tablas html:
        
        {html_tablas["tabla_senhales"]}
        
        {html_tablas["tabla_interferencias"]}

        (A veces la tabla puede ser que no se haya generado, en ese caso simplemente pon el mismo mensaje que coloca mi funcion para crear la tabla)
        
        Las tablas deben incluirse con su titulo. Si por algun motivo hay valores repetidos en las columnas ip y fecha (fechas exactas con hora incluida), elimina un valor y solo deja el que tenga la recurrencia mas alta.
        
        Responde con un mensaje listo para enviar por correo electronico. ESCRIBELO EN HTML ESTO ES IMPORTANTISIMO.
        PERO NO AGREGUES ```html NI NADA SIMILAR AL MENSAJE
        """
        
        return self.mensaje_chat_gpt(mensaje_prompt)


# Instancia global del cliente ChatGPT
_chatgpt_client: Optional[ChatGPTClient] = None


def get_chatgpt_client(
    api_key: Optional[str] = None, 
    dotenv_path: Optional[str] = None
) -> ChatGPTClient:
    """
    Retorna la instancia global del cliente ChatGPT.
    
    Args:
        api_key: API key de OpenAI
        dotenv_path: Ruta al archivo .env
        
    Returns:
        ChatGPTClient: Instancia del cliente ChatGPT
    """
    global _chatgpt_client
    
    if _chatgpt_client is None or api_key is not None or dotenv_path is not None:
        _chatgpt_client = ChatGPTClient(api_key, dotenv_path)
    
    return _chatgpt_client


def mensaje_chat_gpt(
    mensaje: str, 
    model: str = "gpt-4o-mini", 
    is_windows: bool = False,
    client: Optional[ChatGPTClient] = None
) -> str:
    """
    Funcion de conveniencia para enviar mensajes a ChatGPT.
    Compatible con el codigo legacy.
    
    Args:
        mensaje: Mensaje para ChatGPT
        model: Modelo a usar
        is_windows: Si sanitizar para Windows
        client: Cliente especifico (opcional)
        
    Returns:
        Respuesta de ChatGPT
    """
    if client is None:
        client = get_chatgpt_client()
    
    return client.mensaje_chat_gpt(mensaje, model, is_windows)