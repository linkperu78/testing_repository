from pydantic import BaseModel
from typing import Dict, Optional, List

class Task(BaseModel):
    description: str
    device: str
    status: int
    assigned_to: int
    alert: str
    code: str
    error_code: str
    created_at: str
    finished_at: Optional[str] = None
    updated_at: Optional[str] = None
    comment: str
    detalle: Dict

class TaskUpdate(BaseModel):
    description: str
    device: str
    status: int
    assigned_to: int
    alert: str
    created_at: str
    finished_at: Optional[str] = None
    updated_at: Optional[str] = None
    comment: str
    detalle: Dict

class DeleteTasksRequest(BaseModel):
    codes: List[str]  # Lista de códigos de tareas a eliminar