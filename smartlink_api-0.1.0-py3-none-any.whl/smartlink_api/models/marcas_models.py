from pydantic import BaseModel
from typing import Dict

class Marca(BaseModel):
    marca: str

