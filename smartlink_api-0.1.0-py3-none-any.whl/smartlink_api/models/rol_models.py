from pydantic import BaseModel
from typing import Dict

class Rol(BaseModel):
    rol: str


