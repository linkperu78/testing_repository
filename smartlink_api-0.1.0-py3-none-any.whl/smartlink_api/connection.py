import mariadb
import time
import os
import sys
import yaml
from contextlib import asynccontextmanager

script_dir = os.path.dirname(os.path.realpath(__file__))
config_path = os.path.join(script_dir, "configAPI.yml")

with open(config_path, "r") as ymlfile:
    DB_CONFIGS = yaml.safe_load(ymlfile)["databases"]

# Diccionario global de pools
POOLS = {}

def create_connection_pool(db_key: str, config: dict):
    retries = 5
    while retries > 0:
        try:
            pool = mariadb.ConnectionPool(
                pool_name=config["pool_name"],
                pool_size=config["pool_size"],
                user=config["user"],
                password=config["password"],
                host=config["host"],
                port=config["port"],
                database=config["database"],
                pool_reset_connection=config["pool_reset_connection"]
            )
            POOLS[db_key] = pool
            return
        except mariadb.Error as e:
            retries -= 1
            print(f"[{db_key}] Error al conectar: {e}. Reintentando en 5 segundos...")
            time.sleep(5)
    print(f"No se pudo conectar a la base de datos '{db_key}'. Saliendo.")
    sys.exit(1)

# Inicializar todos los pools
for db_key, config in DB_CONFIGS.items():
    create_connection_pool(db_key, config)

@asynccontextmanager
async def get_db_connection(db_key: str = "smartlink"):
    """Obtiene una conexion del pool indicado."""
    conn = None
    try:
        pool = POOLS[db_key]
        conn = pool.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        yield conn
    except mariadb.Error as e:
        print(f"[{db_key}] Error al obtener conexion: {e}")
        raise e
    finally:
        if conn:
            conn.close()
