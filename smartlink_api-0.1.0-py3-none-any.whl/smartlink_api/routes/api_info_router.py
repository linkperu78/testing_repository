import os
import platform
import multiprocessing
import fastapi
import uvicorn
from fastapi import APIRouter

router = APIRouter()

@router.get("/info_api", summary="Información de entorno del servidor")
def get_api_info():
    return {
        "python_version": platform.python_version(),
        "fastapi_version": fastapi.__version__,
        "uvicorn_version": uvicorn.__version__,
        "cpu_count": multiprocessing.cpu_count(),
        "worker_count": int(os.environ.get("WORKERS", "default not set")),
        "hostname": platform.node(),
        "pid": os.getpid(),
        "env": {
            "WORKERS": os.environ.get("WORKERS"),
            "HOSTNAME": os.environ.get("HOSTNAME")
        }
    }
