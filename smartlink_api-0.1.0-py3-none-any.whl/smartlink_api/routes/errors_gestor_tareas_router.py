from fastapi import APIRouter, HTTPException
from smartlink_api.connection import get_db_connection
from smartlink_api.routes.__utils__ import insert_data, fetch_data, delete_data
from smartlink_api.models.errors_gestor_tareas_models import Errors

router = APIRouter()

@router.post("/add")
async def add_error(error: Errors):
    async with get_db_connection("gestor_tareas") as conn:
        return insert_data(conn, "errors", error)

@router.get("/get")
async def get_errors():
    async with get_db_connection("gestor_tareas") as conn:
        return fetch_data(conn, "errors")

@router.delete("/delete/{column}/{value}")
async def delete_error(column: str, value: str):
    async with get_db_connection("gestor_tareas") as conn:
        return delete_data(conn, "errors", column, value)
