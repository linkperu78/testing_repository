from fastapi import APIRouter, Request, HTTPException, Depends
from datetime import datetime, timedelta
from smartlink_api.connection import get_db_connection
from typing import Optional, List
from mariadb import IntegrityError
import json

from smartlink_api.routes.__utils__ import insert_data, insert_bulk_data, fetch_data
from smartlink_api.models.tasks_gestor_tareas_models import Task, TaskUpdate, DeleteTasksRequest

router = APIRouter()



@router.post("/add")
async def add_task(task: Task):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        return insert_data(conn=conn, table="tasks", model=task)
    

@router.post("/add_list")
async def add_task_list(list_model: List[Task]):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        return insert_bulk_data(conn=conn, table="tasks", data=list_model, columns=list(Task.model_fields.keys()))


@router.get("/get")
async def get_tasks():
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        return fetch_data(conn=conn, table="tasks")
    

@router.get("/get/{column}/{filter_value}")
async def get_task_by_code(column: str, filter_value: str):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        try:
            if column not in Task.model_fields:
                raise HTTPException(status_code=400, detail="Invalid column name")

            field_type = Task.model_fields[column].annotation  

            if field_type == int:
                try:
                    filter_value_int = int(filter_value)
                    query = f"SELECT * FROM tasks WHERE {column} = ?"
                    query_params = (filter_value_int,)
                except ValueError:
                    raise HTTPException(status_code=400, detail="For integer columns, provide an integer value")
            else:
                query = f"SELECT * FROM tasks WHERE {column} LIKE ?"
                query_params = (f"%{filter_value}%",)

            cursor = conn.cursor()
            cursor.execute(query, query_params)
            column_names = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()

            return [dict(zip(column_names, row)) for row in rows]

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
        

@router.put("/update/{task_code}")
async def update_task(task_code: str, task: TaskUpdate):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        try:
            cursor = conn.cursor()

            # Obtener code y error_code actuales desde la BD
            cursor.execute("SELECT code, error_code FROM tasks WHERE code = ?", (task_code,))
            row = cursor.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Tarea no encontrada")

            current_code, current_error_code = row

            # Serializar 'detalle' como JSON string
            detalle_json = json.dumps(task.detalle)

            # Preparar query UPDATE
            query = """
                UPDATE tasks
                SET description = ?, device = ?, status = ?, assigned_to = ?, alert = ?,
                    code = ?, error_code = ?, created_at = ?, finished_at = ?, updated_at = ?,
                    comment = ?, detalle = ?
                WHERE code = ?
            """

            # Ejecutar UPDATE usando code/error_code originales
            cursor.execute(query, (
                task.description,
                task.device,
                task.status,
                task.assigned_to,
                task.alert,
                current_code,         
                current_error_code,   
                task.created_at,
                task.finished_at,
                task.updated_at,
                task.comment,
                detalle_json,
                task_code
            ))

            conn.commit()
            return {"message": "Task updated successfully"}

        except IntegrityError as e:
            raise HTTPException(status_code=400, detail=f"Integrity error: {str(e)}")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

        
@router.delete("/delete/{task_code}")
async def delete_task(task_code: str):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tasks WHERE code = ?", (task_code,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Task not found")
            return {"message": "Task deleted successfully"}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error: {str(e)}")


@router.delete("/delete_list")
async def delete_task_list(request: DeleteTasksRequest):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        try:
            if not request.codes:
                raise HTTPException(status_code=400, detail="La lista de códigos está vacía.")

            placeholders = ", ".join(["?"] * len(request.codes))
            query = f"DELETE FROM tasks WHERE code IN ({placeholders})"

            cursor = conn.cursor()
            cursor.execute(query, request.codes)
            conn.commit()

            return {
                "message": f"{cursor.rowcount} tareas eliminadas exitosamente",
                "codigos_eliminados": request.codes
            }

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error al eliminar tareas: {str(e)}")


@router.get("/get/max_code")
async def get_max_task_code():
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        try:
            cursor = conn.cursor()
            query = """
                SELECT code 
                FROM tasks 
                WHERE code REGEXP '^T-[0-9]+$'
                ORDER BY CAST(SUBSTRING(code, 3) AS UNSIGNED) DESC 
                LIMIT 1
            """
            cursor.execute(query)
            row = cursor.fetchone()
            if not row:
                return {"max_code": None}

            code = row[0] 
            numeric_part = int(code[2:])  # Convierte a entero ignorando ceros
            formatted_code = f"T-{numeric_part:03d}"  # Siempre 3 dígitos

            return {"max_code": formatted_code}

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error: {str(e)}")



@router.get("/get_ip/{ip}/{error_code}")
async def get_tasks_by_ip_and_error(ip: str, error_code: str):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        try:
            cursor = conn.cursor()
            query = """
                SELECT description, device, status, assigned_to, alert, code, error_code, created_at, finished_at, updated_at, comment, detalle
                FROM tasks 
                WHERE error_code = ? AND detalle IS NOT NULL
                ORDER BY created_at DESC
            """
            cursor.execute(query, (error_code,))
            rows = cursor.fetchall()
            if not rows:
                raise HTTPException(status_code=404, detail=f"No se encontró tarea para IP: {ip} con error: {error_code}")

            results = []
            for row in rows:
                try:
                    detalle = json.loads(row[11])  # Asumiendo que 'detalle' es el último campo
                    if detalle.get("ip") == ip:
                        results.append({
                            "description": row[0],
                            "device": row[1],
                            "status": row[2],
                            "assigned_to": row[3],
                            "alert": row[4],
                            "code": row[5],
                            "error_code": row[6],
                            "created_at": row[7],
                            "finished_at": row[8],
                            "updated_at": row[9],
                            "comment": row[10],
                            "detalle": detalle
                        })
                except Exception:
                    continue
            return results

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
        
