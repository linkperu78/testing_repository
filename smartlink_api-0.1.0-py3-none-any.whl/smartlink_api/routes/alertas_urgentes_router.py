import json
import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from smartlink_api.connection import get_db_connection
from datetime import datetime, timedelta
from typing import List, Dict

router = APIRouter()
active_connections: List[WebSocket] = []
alertas_enviadas: Dict[str, datetime] = {}  # 📌 Registro de alertas enviadas con timestamp

def calcular_segundos_hasta_siguiente_minuto():
    """Calcula cuántos segundos faltan para el inicio del próximo minuto."""
    now = datetime.now()
    segundos_actuales = now.second
    segundos_restantes = 60 - segundos_actuales  # Lo que falta para llegar a 00 segundos
    return max(segundos_restantes, 1)  # Evitar tiempos negativos o 0 segundos

@router.websocket("/ws/alertas")
async def websocket_endpoint(websocket: WebSocket):
    """Maneja conexiones WebSocket y sincroniza alertas cada minuto, evitando repeticiones en 15 min."""
    await websocket.accept()
    active_connections.append(websocket)
    
    print(f"✅ Cliente conectado. Total: {len(active_connections)} clientes activos.")

    try:
        while True:
            tiempo_espera = calcular_segundos_hasta_siguiente_minuto()
            print(f"⏳ Cliente espera {tiempo_espera:.2f} segundos hasta el próximo envío de alertas.")
            await asyncio.sleep(tiempo_espera)

            async with get_db_connection() as conn:
                cursor = conn.cursor(dictionary=True)  # Devuelve diccionarios en vez de tuplas
                ultima_fecha = (datetime.now() - timedelta(minutes=15)).strftime("%Y-%m-%d %H:%M:%S")

                # 📌 Consulta SQL corregida con JOIN a inventario
                cursor.execute("""
                    SELECT e.ip, e.fecha, e.estado, e.problema, e.recurrencia, e.detalle, e.urgente, 
                           i.tag, i.marca, i.tipo
                    FROM eventos e
                    LEFT JOIN inventario i ON e.ip = i.ip
                    WHERE e.urgente = 1 AND e.fecha > %s
                """, (ultima_fecha,))

                nuevas_alertas = cursor.fetchall()
                cursor.close()

            alertas_a_enviar = []

            for i in nuevas_alertas:
                # Convertir `detalle` a JSON si es un string
                try:
                    detalle = json.loads(i["detalle"]) if isinstance(i["detalle"], str) else i["detalle"]
                except json.JSONDecodeError:
                    detalle = {}  # En caso de error, usar un diccionario vacío para evitar fallos

                # Identificador único de la alerta (ejemplo: "RouterX_2025-03-13 15:00:00")
                alerta_id = f"{i['tag']}_{i['fecha']}"

                # Verificar si la alerta ya se envió en los últimos 15 minutos
                if alerta_id in alertas_enviadas:
                    tiempo_ultimo_envio = alertas_enviadas[alerta_id]
                    if (datetime.now() - tiempo_ultimo_envio).total_seconds() < 900:
                        continue  # 📌 Si la alerta ya se envió hace menos de 15 min, se omite

                # Construir mensaje según el estado
                if i["problema"] == "Señal Deficiente":
                    if i["estado"] == "Alarma":
                        mensaje = f"[🔴 {str(i['fecha'])}] Equipo {i['tag']} ({i['marca']} - {i['tipo']}) presenta {i['problema']}. Última latencia: {detalle.get('latencia', 'N/A')}. Ocurrió {i['recurrencia']} veces en poco tiempo."
                    elif i["estado"] == "Alerta":
                        mensaje = f"[🟡 {str(i['fecha'])}] Equipo {i['tag']} ({i['marca']} - {i['tipo']}) presenta {i['problema']}. Última latencia: {detalle.get('latencia', 'N/A')}. Ocurrió {i['recurrencia']} veces en poco tiempo."

                    alertas_a_enviar.append((alerta_id, mensaje))  # Guardar para enviar después

                elif i["problema"] == "Interferencia":
                    print("TODO")  # Aquí puedes agregar lógica específica para "Interferencia"

            # Enviar alertas nuevas a todos los clientes
            for alerta_id, mensaje in alertas_a_enviar:
                print(f"📢 Enviando alerta: {mensaje}")
                await websocket.send_text(mensaje)
                alertas_enviadas[alerta_id] = datetime.now()  # 📌 Registrar que se envió

            if not alertas_a_enviar:
                await websocket.send_text("🔕 No hay alertas nuevas en este periodo.")

    except WebSocketDisconnect:
        active_connections.remove(websocket)
        print(f"❌ Cliente desconectado. Total: {len(active_connections)} clientes activos.")

