from fastapi import APIRouter, Query, HTTPException, Depends
from datetime import datetime, timedelta
from smartlink_api.connection import get_db_connection

router = APIRouter()

@router.delete("/limpiar", summary="Limpiar registros antiguos en todas las tablas que tengan columna 'fecha'")
async def limpiar_base_completa(
    dias: int = Query(14, description="Eliminar registros con más de X dias (por defecto: 14)"),
    dry_run: bool = Query(False, description="Si es True, no elimina nada, solo muestra lo que eliminaria")
):
    """
    Recorre todas las tablas de la base de datos y elimina (o simula eliminar) registros con columna 'fecha'
    que sean anteriores a la fecha calculada según los dias indicados.
    """
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        try:
            cursor = conn.cursor()
            cutoff = datetime.now() - timedelta(days=dias)
            cursor.execute("SHOW TABLES")
            tablas = [fila[0] for fila in cursor.fetchall()]

            resultado = {}

            for tabla in tablas:
                try:
                    # Verifica si la tabla tiene una columna 'fecha'
                    cursor.execute(f"SHOW COLUMNS FROM {tabla} LIKE 'fecha'")
                    if not cursor.fetchone():
                        resultado[tabla] = "No tiene columna 'fecha', se omitio"
                        continue

                    if dry_run:
                        cursor.execute(f"SELECT COUNT(*) FROM {tabla} WHERE fecha < %s", (cutoff,))
                        count = cursor.fetchone()[0]
                        resultado[tabla] = f"Se eliminarian {count} registros anteriores a {cutoff.strftime('%Y-%m-%d %H:%M:%S')}"
                    else:
                        cursor.execute(f"DELETE FROM {tabla} WHERE fecha < %s", (cutoff,))
                        conn.commit()
                        count = cursor.rowcount
                        resultado[tabla] = f"Se eliminaron {count} registros anteriores a {cutoff.strftime('%Y-%m-%d %H:%M:%S')}"
                except Exception as inner_e:
                    resultado[tabla] = f"Error al procesar: {str(inner_e)}"

            return resultado

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error durante el mantenimiento: {str(e)}")
