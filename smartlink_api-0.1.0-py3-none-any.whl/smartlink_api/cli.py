import argparse
import subprocess
import sys

def main():
    parser = argparse.ArgumentParser(
        prog="smartlink-api",
        description="Inicia la API Smartlink (Gunicorn por defecto, Uvicorn con --test)."
    )
    parser.add_argument("--host", default="0.0.0.0", help="Host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Puerto (default: 8000)")
    parser.add_argument("--workers", type=int, default=4, help="Workers Gunicorn (default: 4)")
    parser.add_argument("--test", action="store_true", help="Usar Uvicorn (dev/test) en vez de Gunicorn")

    a = parser.parse_args()

    if a.test:
        # Usa el mismo intérprete (del venv) para uvicorn
        cmd = [
            sys.executable, "-m", "uvicorn",
            "smartlink_api.app:app",
            "--host", a.host,
            "--port", str(a.port),
            "--reload",
        ]
    else:
        # Usa el mismo intérprete (del venv) para gunicorn
        cmd = [
            sys.executable, "-m", "gunicorn",
            "-k", "uvicorn.workers.UvicornWorker",
            "smartlink_api.app:app",
            "--bind", f"{a.host}:{a.port}",
            "--workers", str(a.workers),
        ]

    print("Ejecutando:", " ".join(cmd))
    subprocess.run(cmd)
