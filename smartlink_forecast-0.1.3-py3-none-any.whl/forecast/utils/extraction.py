import requests
import pandas as pd
import json
from urllib.parse import urljoin
from typing import Optional, Union, List, Dict, Any


def api_request(url: str, method: str = "GET", dataframe: bool = False, 
                headers: Optional[Dict[str, str]] = None, 
                data: Optional[Union[List, Dict, str]] = None) -> Optional[Union[pd.DataFrame, List, Dict]]:
    """
    Realiza una peticion HTTP a una API
    
    Args:
        url: URL de la API
        method: Metodo HTTP (GET, POST)
        dataframe: Si True, convierte la respuesta a DataFrame
        headers: Headers HTTP adicionales
        data: Datos para enviar (POST)
        
    Returns:
        DataFrame, lista, diccionario o None segun parametros
    """
    try:
        # Si data es una lista, convertir a JSON
        if isinstance(data, list):
            data = json.dumps(data)
            if headers is None:
                headers = {}
            headers["Content-Type"] = "application/json"
        
        # Realizar peticion
        if method.upper() == "GET":
            response = requests.get(url, headers=headers)
        elif method.upper() == "POST":
            response = requests.post(url, headers=headers, data=data)
        else:
            print(f"Metodo no soportado: {method}")
            return None

        # Procesar respuesta
        if response.status_code == 200:
            response_data = response.json()
            return pd.DataFrame(response_data) if dataframe else response_data
        else:
            print(f"Error en API: {response.status_code} - {response.text}")
            return None
            
    except requests.RequestException as e:
        print(f"Error de conexion: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"Error decodificando JSON: {e}")
        return None
    except Exception as e:
        print(f"Error inesperado: {e}")
        return None


def get_inventory_data(config: Dict[str, Any], marca: str) -> List[str]:
    """
    Obtiene la lista de IPs del inventario segun la marca
    
    Args:
        config: Configuracion cargada del YAML
        marca: 'Cambium' o 'Mimosa'
        
    Returns:
        Lista de IPs de equipos
    """
    base_url = config.get('db_api_url', '')
    
    if marca == 'Cambium':
        # Para Cambium, solo inventario PMP
        inventory_url = urljoin(base_url, config.get('inventario_pmp_url', ''))
        inventory_data = api_request(inventory_url, dataframe=True)
        
        if inventory_data is not None and not inventory_data.empty:
            subscribers = inventory_data[
                inventory_data["tipo"].str.contains("PMP", na=False, case=False)
            ]["ip"].unique()
            return subscribers.tolist()
    
    elif marca == 'Mimosa':
        # Para Mimosa, inventario PMP-AP y PMP-SM
        inventory_ap_url = urljoin(base_url, config.get('inventario_pmp_ap_url', ''))
        inventory_sm_url = urljoin(base_url, config.get('inventario_pmp_sm_url', ''))
        
        # Obtener ambos inventarios
        inventory_ap = api_request(inventory_ap_url, dataframe=True)
        inventory_sm = api_request(inventory_sm_url, dataframe=True)
        
        subscribers = []
        
        # Procesar inventario AP
        if inventory_ap is not None and not inventory_ap.empty:
            ap_ips = inventory_ap[
                inventory_ap["tipo"].str.contains("PMP-AP", na=False, case=False)
            ]["ip"].unique()
            subscribers.extend(ap_ips.tolist())
        
        # Procesar inventario SM
        if inventory_sm is not None and not inventory_sm.empty:
            sm_ips = inventory_sm[
                inventory_sm["tipo"].str.contains("PMP-SM", na=False, case=False)
            ]["ip"].unique()
            subscribers.extend(sm_ips.tolist())
        
        return subscribers
    
    print(f"Marca no reconocida: {marca}")
    return []


def get_equipment_data(config: Dict[str, Any], marca: str, ip: str, 
                      start_date: str, end_date: str, 
                      limit: int = 20000, offset: int = 0) -> Optional[List[Dict]]:
    """
    Obtiene datos de un equipo especifico en un rango de fechas
    
    Args:
        config: Configuracion cargada del YAML
        marca: 'Cambium' o 'Mimosa'
        ip: IP del equipo
        start_date: Fecha inicio (formato ISO)
        end_date: Fecha fin (formato ISO)
        limit: Limite de registros
        offset: Offset de registros
        
    Returns:
        Lista de registros de datos del equipo
    """
    base_url = config.get('db_api_url', '')
    
    if marca == 'Cambium':
        data_url_base = urljoin(base_url, config.get('cambium_data_ip_url_base', ''))
    elif marca == 'Mimosa':
        data_url_base = urljoin(base_url, config.get('mimosa_data_ip_url_base', ''))
    else:
        print(f"Marca no reconocida: {marca}")
        return None
    
    # Construir URL completa
    url = urljoin(data_url_base, f"{ip}?start_date={start_date}&end_date={end_date}&limit={limit}&offset={offset}")
    
    print(f"Obteniendo datos de {ip}: {url}")
    
    # Realizar peticion
    results = api_request(url, dataframe=False)
    
    if results:
        print(f"Obtenidos {len(results)} registros para IP {ip}")
        return results
    else:
        print(f"No se obtuvieron datos para IP {ip}")
        return []


def get_all_equipment_data(config: Dict[str, Any], marca: str, 
                          start_date: str, end_date: str,
                          limit: int = 20000, offset: int = 0) -> List[Dict]:
    """
    Obtiene datos de todos los equipos de una marca en un rango de fechas
    
    Args:
        config: Configuracion cargada del YAML
        marca: 'Cambium' o 'Mimosa'
        start_date: Fecha inicio (formato ISO)
        end_date: Fecha fin (formato ISO)
        limit: Limite de registros por equipo
        offset: Offset de registros
        
    Returns:
        Lista consolidada de todos los registros
    """
    # Obtener lista de IPs
    subscribers = get_inventory_data(config, marca)
    
    if not subscribers:
        print(f"No se encontraron equipos para marca {marca}")
        return []
    
    print(f"Obteniendo datos de {len(subscribers)} equipos {marca}")
    
    # Consolidar datos de todos los equipos
    all_data = []
    for ip in subscribers:
        equipment_data = get_equipment_data(config, marca, ip, start_date, end_date, limit, offset)
        if equipment_data:
            all_data.extend(equipment_data)
    
    print(f"Total de registros obtenidos: {len(all_data)}")
    return all_data


def post_predictions(config: Dict[str, Any], predictions: List[Dict]) -> bool:
    """
    Envia predicciones a la API para almacenar en base de datos
    
    Args:
        config: Configuracion cargada del YAML
        predictions: Lista de predicciones a enviar
        
    Returns:
        True si se enviaron correctamente, False en caso contrario
    """
    if not predictions:
        print("No hay predicciones para enviar")
        return False
    
    base_url = config.get('db_api_url', '')
    predictions_url = urljoin(base_url, config.get('predicciones_list_add', ''))
    
    print(f"Enviando {len(predictions)} predicciones a: {predictions_url}")
    
    # Enviar predicciones
    response = api_request(predictions_url, method="POST", data=predictions)
    
    if response is not None:
        print("Predicciones enviadas correctamente")
        return True
    else:
        print("Error enviando predicciones")
        return False


# Para uso como modulo independiente
if __name__ == "__main__":
    import argparse
    from ..config import load_config
    
    parser = argparse.ArgumentParser(description="Probar funciones de extraccion de datos")
    parser.add_argument('--marca', choices=['Cambium', 'Mimosa'], required=True, help='Marca de equipos')
    parser.add_argument('--inventory', action='store_true', help='Obtener inventario')
    parser.add_argument('--ip', help='IP especifica para obtener datos')
    parser.add_argument('--start_date', help='Fecha inicio (ISO)')
    parser.add_argument('--end_date', help='Fecha fin (ISO)')
    
    args = parser.parse_args()
    
    try:
        config = load_config()
        
        if args.inventory:
            print(f"Obteniendo inventario {args.marca}...")
            ips = get_inventory_data(config, args.marca)
            print(f"IPs encontradas: {len(ips)}")
            for ip in ips[:5]:  # Mostrar solo las primeras 5
                print(f"  - {ip}")
            if len(ips) > 5:
                print(f"  ... y {len(ips) - 5} mas")
        
        if args.ip and args.start_date and args.end_date:
            print(f"Obteniendo datos de {args.ip}...")
            data = get_equipment_data(config, args.marca, args.ip, args.start_date, args.end_date)
            print(f"Registros obtenidos: {len(data) if data else 0}")
    
    except Exception as e:
        print(f"Error: {e}")
        exit(1)