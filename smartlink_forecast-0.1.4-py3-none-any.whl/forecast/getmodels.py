import sys
import os
import pandas as pd
import warnings
import argparse
from datetime import datetime, timedelta
from pathlib import Path
from neuralprophet import NeuralProphet
import pickle

# Imports de nuestros modulos
from forecast.config import load_config
from forecast.utils.extraction import get_all_equipment_data
from forecast.utils.transformation import prepare_dataframe_for_training, prepare_timeseries_data, agregar_ruido_si_igual
from forecast.utils.helpers import (
    parse_datetime, parse_iso_string, apply_timezone, forecast_setting,
    create_model_directories, get_model_path, print_status, validate_date_range
)

warnings.filterwarnings("ignore")


def create_model(df_group, ip, forecast_name, marca, model_params, base_path=None):
    """
    Crea y entrena un modelo NeuralProphet para una IP especifica
    
    Args:
        df_group: DataFrame agrupado por IP
        ip: IP del equipo
        forecast_name: Nombre del forecast (snr_v, snr_h, rx, per)
        marca: Marca del equipo (Cambium, Mimosa)
        model_params: Parametros del modelo NeuralProphet
        base_path: Ruta base para guardar modelos
    """
    print_status(f"Creando modelo para IP: {ip} - Tipo: {forecast_name} - Marca: {marca}")
    
    try:
        # Obtener datos de la IP
        df_ip = df_group.get_group(ip)
        
        # Preparar datos de serie temporal
        df_processed = prepare_timeseries_data(
            df_ip, 
            model_params['n_forecasts'], 
            model_params['n_lags']
        )
        
        # Crear modelo NeuralProphet
        model = NeuralProphet(
            n_forecasts=model_params['n_forecasts'],
            growth=model_params['growth'],
            yearly_seasonality=model_params['yearly_seasonality'],
            weekly_seasonality=model_params['weekly_seasonality'],
            daily_seasonality=model_params['daily_seasonality'],
            n_lags=model_params['n_lags'],
            learning_rate=model_params['learning_rate'],
            normalize=model_params['normalize'],
            epochs=model_params['epochs'],
            drop_missing=model_params.get('drop_missing', True)
        )
        
        # Entrenar modelo
        print_status(f"Entrenando modelo para {ip}...")
        metrics = model.fit(df_processed, freq='1H')
        
        # Guardar modelo
        model_path = get_model_path(ip, forecast_name, marca, base_path)
        
        # Crear directorio si no existe
        Path(model_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Eliminar modelo anterior si existe
        if os.path.exists(model_path):
            os.remove(model_path)
        
        # Guardar nuevo modelo
        with open(model_path, "wb") as f:
            pickle.dump(model, f)
        
        print_status(f"Modelo guardado: {model_path}", 'success')
        
    except Exception as e:
        print_status(f"Error creando modelo para IP {ip}: {e}", 'error')


def train_models_for_marca(marca, forecast_types, start_date, end_date, zone, limit, offset, base_path=None):
    """
    Entrena modelos para una marca especifica
    
    Args:
        marca: Marca de equipos ('Cambium' o 'Mimosa')
        forecast_types: Lista de tipos de forecast
        start_date: Fecha inicio en formato ISO
        end_date: Fecha fin en formato ISO
        zone: Zona horaria (opcional)
        limit: Limite de registros por consulta
        offset: Offset de registros
        base_path: Ruta base para modelos
    """
    print_status(f"Iniciando entrenamiento para marca: {marca}")
    
    # Cargar configuracion
    config = load_config()
    
    # Aplicar zona horaria si se especifica
    if zone:
        try:
            start_date = apply_timezone(start_date, zone)
            end_date = apply_timezone(end_date, zone)
            print_status(f"Zona horaria {zone} aplicada")
        except Exception as e:
            print_status(f"Error aplicando zona horaria: {e}", 'error')
            return
    
    # Crear directorios de modelos
    create_model_directories(base_path, marca)
    
    # Procesar cada tipo de forecast
    for forecast_type in forecast_types:
        print_status(f"Procesando forecast: {forecast_type}")
        
        try:
            # Obtener configuracion del forecast
            forecast_name, _ = forecast_setting(forecast_type.upper())
            model_params = config[forecast_name]['neuralprophet_parameters']
            
            # Agregar valores por defecto
            defaults = {
                'num_hidden_layers': 1,
                'd_hidden': 64,
                'optimizer': 'AdamW',
                'ar_reg': 0.0,
                'drop_missing': True
            }
            for key, default_value in defaults.items():
                if key not in model_params:
                    model_params[key] = default_value
            
            print_status(f"Parametros del modelo: epochs={model_params['epochs']}, lr={model_params['learning_rate']}")
            
            # Obtener datos de todos los equipos
            print_status(f"Obteniendo datos para {marca}...")
            raw_data = get_all_equipment_data(config, marca, start_date, end_date, limit, offset)
            
            if not raw_data:
                print_status(f"No se obtuvieron datos para {marca} - {forecast_type}", 'warning')
                continue
            
            # Preparar DataFrame para entrenamiento
            inventory_type = None
            if marca == 'Mimosa':
                # Para Mimosa, necesitamos determinar el tipo de inventario
                # Por simplicidad, procesaremos todos juntos
                inventory_type = 'PMP-AP'  # Se podria mejorar para detectar automaticamente
            
            df = prepare_dataframe_for_training(raw_data, forecast_name, marca, inventory_type)
            
            if df.empty:
                print_status(f"No hay datos validos para procesar - {marca} - {forecast_type}", 'warning')
                continue
            
            # Guardar datos para revision
            if base_path:
                data_file = Path(base_path) / marca.lower() / f"training_data_{forecast_name}.csv"
            else:
                data_file = Path(__file__).parent / "models" / marca.lower() / f"training_data_{forecast_name}.csv"
            
            data_file.parent.mkdir(parents=True, exist_ok=True)
            df.to_csv(data_file, index=False)
            print_status(f"Datos guardados en: {data_file}")
            
            # Agrupar por IP y entrenar modelos
            df_grouped = df.groupby('ip')
            ips = list(df_grouped.groups.keys())
            
            print_status(f"Entrenando modelos para {len(ips)} IPs")
            
            for i, ip in enumerate(ips, 1):
                print_status(f"Procesando IP {i}/{len(ips)}: {ip}")
                create_model(df_grouped, ip, forecast_name, marca, model_params, base_path)
            
            print_status(f"Entrenamiento completado para {forecast_type}", 'success')
            
        except Exception as e:
            print_status(f"Error procesando forecast {forecast_type}: {e}", 'error')
            continue


def main(args=None):
    """
    Funcion principal para entrenamiento de modelos
    
    Args:
        args: Argumentos parseados (opcional, para uso desde CLI)
    """
    if args is None:
        # Crear parser solo si no se pasan argumentos
        now = datetime.now()
        one_day_ago = now - timedelta(days=1)
        
        parser = argparse.ArgumentParser(description="Entrenar modelos NeuralProphet")
        parser.add_argument('--marca', choices=['Cambium', 'Mimosa'], required=True,
                           help='Marca de equipos')
        parser.add_argument('--start_date', 
                           default=one_day_ago.strftime("%Y-%m-%d %H:%M:%S"),
                           help='Fecha inicio (YYYY-MM-DD HH:MM:SS)')
        parser.add_argument('--end_date',
                           default=now.strftime("%Y-%m-%d %H:%M:%S"), 
                           help='Fecha fin (YYYY-MM-DD HH:MM:SS)')
        parser.add_argument('--forecast_type', default='snr_v,snr_h,rx',
                           help='Tipos de forecast separados por coma')
        parser.add_argument('--zone', help='Zona horaria (opcional)')
        parser.add_argument('--limit', type=int, default=20000,
                           help='Limite de registros por consulta')
        parser.add_argument('--offset', type=int, default=0,
                           help='Offset de registros')
        parser.add_argument('--model_path', help='Ruta base para modelos (opcional)')
        
        args = parser.parse_args()
    
    # Procesar argumentos
    marca = args.marca
    forecast_types = [ft.strip() for ft in args.forecast_type.split(',')]
    start_date = parse_iso_string(args.start_date)
    end_date = parse_iso_string(args.end_date)
    zone = getattr(args, 'zone', None)
    limit = getattr(args, 'limit', 20000)
    offset = getattr(args, 'offset', 0)
    model_path = getattr(args, 'model_path', None)
    
    # Validaciones
    if not validate_date_range(args.start_date, args.end_date):
        print_status("Error: La fecha de inicio debe ser anterior a la fecha de fin", 'error')
        sys.exit(1)
    
    valid_forecast_types = ['snr_v', 'snr_h', 'rx', 'per', 'airrx']
    for ft in forecast_types:
        if ft not in valid_forecast_types:
            print_status(f"Error: Tipo de forecast invalido: {ft}", 'error')
            print_status(f"Tipos validos: {', '.join(valid_forecast_types)}", 'info')
            sys.exit(1)
    
    # Mostrar informacion
    print_status("=== ENTRENAMIENTO DE MODELOS ===")
    print_status(f"Marca: {marca}")
    print_status(f"Periodo: {start_date} -> {end_date}")
    print_status(f"Tipos: {', '.join(forecast_types)}")
    print_status(f"Limite: {limit}, Offset: {offset}")
    if zone:
        print_status(f"Zona horaria: {zone}")
    
    # Ejecutar entrenamiento
    try:
        train_models_for_marca(marca, forecast_types, start_date, end_date, zone, limit, offset, model_path)
        print_status("=== ENTRENAMIENTO COMPLETADO ===", 'success')
    except Exception as e:
        print_status(f"Error en entrenamiento: {e}", 'error')
        sys.exit(1)


if __name__ == "__main__":
    main()