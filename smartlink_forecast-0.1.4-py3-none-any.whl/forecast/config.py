import yaml
from pathlib import Path


def load_config(config_path=None):
    """
    Carga configuracion desde configForecast.yml
    
    Args:
        config_path: Ruta al archivo YAML. Si es None, busca configForecast.yml
        
    Returns:
        dict: Configuracion del YAML
    """
    if config_path is None:
        # Buscar configForecast.yml en la raiz del proyecto
        current_dir = Path(__file__).parent.parent.parent  
        config_path = current_dir / "configForecast.yml"
        
        # Si no existe, buscar en directorio actual
        if not config_path.exists():
            config_path = Path("configForecast.yml")
    
    with open(config_path, 'r', encoding='utf-8') as file:
        return yaml.safe_load(file)


# Para uso como modulo independiente
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Leer configuracion")
    parser.add_argument('--show', action='store_true', help='Mostrar configuracion')
    parser.add_argument('--config', help='Ruta al archivo YAML')
    
    args = parser.parse_args()
    
    if args.show:
        config = load_config(args.config)
        print("Configuracion:")
        print(yaml.dump(config, default_flow_style=False, allow_unicode=True))
    else:
        print("Uso: python3 -m forecast.config --show")