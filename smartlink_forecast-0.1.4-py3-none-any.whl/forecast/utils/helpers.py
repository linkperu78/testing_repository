import os
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any
import pytz


def parse_datetime(date_str: str) -> datetime:
    """
    Parsea una fecha con o sin 'T'
    
    Args:
        date_str: Fecha en formato string
        
    Returns:
        Objeto datetime parseado
        
    Raises:
        ValueError: Si el formato no es valido
    """
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    raise ValueError(f"Formato de fecha invalido: {date_str}")


def parse_iso_string(date_str: str) -> str:
    """
    Convierte cualquier fecha al formato ISO con 'T'
    
    Args:
        date_str: Fecha en formato string
        
    Returns:
        Fecha en formato ISO con 'T'
    """
    return parse_datetime(date_str).strftime("%Y-%m-%dT%H:%M:%S")


def apply_timezone(date_str: str, zone: str) -> str:
    """
    Aplica zona horaria a una fecha
    
    Args:
        date_str: Fecha en formato ISO
        zone: Zona horaria (ej: America/Santiago, UTC)
        
    Returns:
        Fecha con zona horaria aplicada
        
    Raises:
        pytz.UnknownTimeZoneError: Si la zona no es valida
    """
    try:
        timezone = pytz.timezone(zone)
        dt = parse_datetime(date_str)
        dt_with_tz = dt.astimezone(timezone)
        return dt_with_tz.strftime("%Y-%m-%dT%H:%M:%S")
    except pytz.UnknownTimeZoneError:
        raise pytz.UnknownTimeZoneError(f"Zona horaria desconocida: {zone}")


def forecast_setting(forecast_type: str, base_path: Optional[str] = None) -> Tuple[str, str]:
    """
    Configura nombre y carpeta del modelo segun el tipo de forecast
    
    Args:
        forecast_type: Tipo de forecast ('V', 'H', 'RX', 'AirRx', 'PER', 'snr_v', 'snr_h', etc.)
        base_path: Ruta base para los modelos. Si es None, usa ruta por defecto
        
    Returns:
        Tupla (forecast_name, model_folder)
    """
    # Normalizar el tipo de forecast para aceptar diferentes formatos
    type_mapping = {
        'snr_v': 'V', 'SNR_V': 'V', 'V': 'V',
        'snr_h': 'H', 'SNR_H': 'H', 'H': 'H', 
        'rx': 'RX', 'RX': 'RX',
        'per': 'PER', 'PER': 'PER',
        'airrx': 'AirRx', 'AIRRX': 'AirRx', 'AirRx': 'AirRx'
    }
    
    normalized_type = type_mapping.get(forecast_type, forecast_type)
    
    if base_path is None:
        # Usar ruta relativa al modulo actual
        script_folder = Path(__file__).parent.parent / "models"
    else:
        script_folder = Path(base_path)
    
    if normalized_type == 'V':
        forecast_name = "snr_v"
        model_folder = script_folder / "snr_v"
    elif normalized_type == 'H':
        forecast_name = "snr_h"
        model_folder = script_folder / "snr_h"
    elif normalized_type == 'RX':
        forecast_name = "rx"
        model_folder = script_folder / "rx"
    elif normalized_type == 'AirRx':
        forecast_name = "airrx"
        model_folder = script_folder / "airrx"
    elif normalized_type == 'PER':
        forecast_name = "per"
        model_folder = script_folder / "per"
    else:
        raise ValueError(f"Tipo de forecast no valido: {forecast_type} (normalizado: {normalized_type})")
    
    return forecast_name, str(model_folder)


def get_prediction_column(forecast_name: str) -> str:
    """
    Obtiene el nombre de la columna de prediccion segun el forecast
    
    Args:
        forecast_name: Nombre del forecast
        
    Returns:
        Nombre de la columna
    """
    column_mapping = {
        'snr_v': 'snr_v',
        'snr_h': 'snr_h', 
        'rx': 'rx',
        'per': 'per',
        'airrx': 'airrx'
    }
    
    if forecast_name not in column_mapping:
        raise ValueError(f"Forecast name no valido: {forecast_name}")
    
    return column_mapping[forecast_name]


def validate_forecast_types(forecast_types: List[str]) -> bool:
    """
    Valida que todos los tipos de forecast sean validos
    
    Args:
        forecast_types: Lista de tipos de forecast
        
    Returns:
        True si todos son validos, False en caso contrario
    """
    valid_types = ['snr_v', 'snr_h', 'rx', 'per', 'airrx']
    return all(ft in valid_types for ft in forecast_types)


def get_valid_forecast_types() -> List[str]:
    """
    Retorna la lista de tipos de forecast validos
    
    Returns:
        Lista de tipos validos
    """
    return ['snr_v', 'snr_h', 'rx', 'per', 'airrx']


def create_model_directories(base_path: Optional[str] = None, marca: Optional[str] = None):
    """
    Crea las carpetas necesarias para almacenar modelos
    
    Args:
        base_path: Ruta base. Si es None, usa ruta por defecto
        marca: Marca especifica ('Cambium', 'Mimosa'). Si es None, crea para ambas
    """
    if base_path is None:
        base_path = Path(__file__).parent.parent / "models"
    else:
        base_path = Path(base_path)
    
    forecast_types = ['snr_v', 'snr_h', 'rx', 'per', 'airrx']
    marcas = [marca] if marca else ['cambium', 'mimosa']
    
    for marca_folder in marcas:
        marca_path = base_path / marca_folder
        marca_path.mkdir(parents=True, exist_ok=True)
        
        for forecast_type in forecast_types:
            forecast_path = marca_path / forecast_type
            forecast_path.mkdir(parents=True, exist_ok=True)
            print(f"Carpeta creada: {forecast_path}")


def get_model_path(ip: str, forecast_name: str, marca: str, base_path: Optional[str] = None) -> str:
    """
    Construye la ruta completa del archivo del modelo
    
    Args:
        ip: IP del equipo
        forecast_name: Nombre del forecast
        marca: Marca del equipo
        base_path: Ruta base de modelos
        
    Returns:
        Ruta completa al archivo .pkl del modelo
    """
    if base_path is None:
        base_path = Path(__file__).parent.parent / "models"
    else:
        base_path = Path(base_path)
    
    marca_folder = marca.lower()
    model_folder = base_path / marca_folder / forecast_name
    model_file = model_folder / f"{ip}_{forecast_name}.pkl"
    
    return str(model_file)


def format_prediction_result(ip: str, forecast_name: str, prediction_value: float, 
                           prediction_date: str, execution_date: Optional[datetime] = None) -> Dict[str, Any]:
    """
    Formatea un resultado de prediccion para enviar a la API
    
    Args:
        ip: IP del equipo
        forecast_name: Tipo de forecast
        prediction_value: Valor predicho
        prediction_date: Fecha de la prediccion
        execution_date: Fecha de ejecucion. Si es None, usa datetime.now()
        
    Returns:
        Diccionario formateado para la API
    """
    if execution_date is None:
        execution_date = datetime.now()
    
    tipo_mapping = {
        'snr_v': 'Predict SNR V',
        'snr_h': 'Predict SNR H', 
        'rx': 'Predict RX',
        'per': 'Predict PER',
        'airrx': 'Predict AirRx'
    }
    
    tipo_prediccion = tipo_mapping.get(forecast_name, f'Predict {forecast_name}')
    
    result = {
        'ip': ip,
        'fecha': str(execution_date),
        'fecha_prediccion': prediction_date,
        'tipo_prediccion': tipo_prediccion,
        'value': round(prediction_value, 2),
        'detalles': {
            'mensaje': f"{tipo_prediccion} - {prediction_date} - {ip}: {prediction_value}"
        }
    }
    
    return result


def print_status(message: str, level: str = 'info'):
    """
    Imprime mensajes de estado con formato
    
    Args:
        message: Mensaje a imprimir
        level: Nivel del mensaje ('info', 'warning', 'error', 'success')
    """
    icons = {
        'info': 'ℹ️',
        'warning': '⚠️', 
        'error': '❌',
        'success': '✅'
    }
    
    icon = icons.get(level, 'ℹ️')
    timestamp = datetime.now().strftime('%H:%M:%S')
    print(f"[{timestamp}] {icon} {message}")


def validate_date_range(start_date: str, end_date: str) -> bool:
    """
    Valida que el rango de fechas sea correcto
    
    Args:
        start_date: Fecha de inicio
        end_date: Fecha de fin
        
    Returns:
        True si el rango es valido
    """
    try:
        start_dt = parse_datetime(start_date)
        end_dt = parse_datetime(end_date)
        return start_dt < end_dt
    except ValueError:
        return False


# Para uso como modulo independiente
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Probar funciones comunes")
    parser.add_argument('--test', choices=['datetime', 'forecast', 'validate', 'dirs'], 
                       help='Tipo de test a ejecutar')
    parser.add_argument('--date', help='Fecha para test datetime')
    parser.add_argument('--zone', help='Zona horaria para test')
    parser.add_argument('--forecast_type', help='Tipo de forecast para test')
    
    args = parser.parse_args()
    
    if args.test == 'datetime':
        if args.date:
            print(f"Test parse_datetime:")
            print(f"  Input: {args.date}")
            try:
                parsed = parse_datetime(args.date)
                print(f"  Parsed: {parsed}")
                iso = parse_iso_string(args.date)
                print(f"  ISO: {iso}")
                
                if args.zone:
                    with_tz = apply_timezone(args.date, args.zone)
                    print(f"  Con zona {args.zone}: {with_tz}")
            except Exception as e:
                print(f"  Error: {e}")
        else:
            print("Uso: --test datetime --date '2025-01-01 12:00:00' [--zone UTC]")
    
    elif args.test == 'forecast':
        if args.forecast_type:
            print(f"Test forecast_setting:")
            try:
                name, folder = forecast_setting(args.forecast_type)
                print(f"  Tipo: {args.forecast_type}")
                print(f"  Nombre: {name}")
                print(f"  Carpeta: {folder}")
                column = get_prediction_column(name)
                print(f"  Columna: {column}")
            except Exception as e:
                print(f"  Error: {e}")
        else:
            print("Uso: --test forecast --forecast_type V")
    
    elif args.test == 'validate':
        print("Test validaciones:")
        test_types = ['snr_v', 'snr_h', 'rx', 'invalid']
        print(f"  Tipos test: {test_types}")
        print(f"  Validos: {validate_forecast_types(test_types)}")
        print(f"  Tipos validos: {get_valid_forecast_types()}")
        
        print(f"  Rango fechas valido: {validate_date_range('2025-01-01 00:00:00', '2025-01-02 00:00:00')}")
        print(f"  Rango fechas invalido: {validate_date_range('2025-01-02 00:00:00', '2025-01-01 00:00:00')}")
    
    elif args.test == 'dirs':
        print("Test crear directorios:")
        print("Creando estructura de carpetas...")
        create_model_directories()
        print("Estructura creada en models/")
    
    else:
        print("Uso: python3 -m forecast.utils.helpers --test datetime|forecast|validate|dirs")