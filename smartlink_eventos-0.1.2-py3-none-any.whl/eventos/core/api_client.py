import json
import requests
import pandas as pd
from datetime import timedelta
from typing import Optional, Union, Dict, Any, List
from urllib.parse import urljoin

from .config import get_config_manager


class APIClient:
    """Cliente para hacer requests a la API de smartlink."""
    
    def __init__(self, base_url: Optional[str] = None):
        """
        Inicializa el cliente de API.
        
        Args:
            base_url: URL base de la API. Si no se proporciona, usa la del config.
        """
        if base_url:
            self.base_url = base_url
        else:
            config_manager = get_config_manager()
            self.base_url = config_manager.get_db_api_url()
    
    def api_request(
        self, 
        url: str, 
        method: str = "GET", 
        dataframe: bool = False, 
        headers: Optional[Dict[str, str]] = None, 
        data: Optional[Union[List, Dict, str]] = None
    ) -> Optional[Union[pd.DataFrame, List[Dict], Dict]]:
        """
        Hace una solicitud a la API.
        
        Args:
            url: URL completa o endpoint relativo
            method: Metodo HTTP (GET, POST, etc.)
            dataframe: Si True, retorna pandas DataFrame
            headers: Headers HTTP adicionales
            data: Datos para enviar en el request
            
        Returns:
            Respuesta de la API como DataFrame, lista o dict segun parametros
        """
        try:
            # Si la URL no es completa, construirla con base_url
            if not url.startswith(('http://', 'https://')):
                url = urljoin(self.base_url, url)
            
            # Si 'data' es una lista, convertirla a JSON
            if isinstance(data, list):
                data = json.dumps(data)
                if headers is None:
                    headers = {}
                headers["Content-Type"] = "application/json"
            
            # Hacer el request segun el metodo
            if method.upper() == "GET":
                response = requests.get(url, headers=headers)
            elif method.upper() == "POST":
                response = requests.post(url, headers=headers, data=data)
            else:
                print(f"Metodo no soportado: {method}")
                return None

            if response.status_code == 200:
                response_data = response.json()
                return pd.DataFrame(response_data) if dataframe else response_data
            else:
                print(f"Error al obtener datos: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            print(f"Request falló: {e}")
            return None
    
    def get_poor_latency(
        self, 
        start_date: str, 
        end_date: str, 
        limit: int = 1000, 
        offset: int = 0
    ) -> Optional[List[Dict]]:
        """
        Obtiene datos de latencia deficiente.
        
        Args:
            start_date: Fecha de inicio en formato ISO
            end_date: Fecha de fin en formato ISO
            limit: Limite de registros
            offset: Offset para paginacion
            
        Returns:
            Lista de datos de latencia o None si hay error
        """
        config_manager = get_config_manager()
        api_config = config_manager.get_api_config()
        
        endpoint = api_config["latencia"]["get_poor_latency"]
        url = f'{endpoint}?start_date={start_date}&end_date={end_date}&limit={limit}&offset={offset}'
        
    def add_eventos_list(self, eventos: List[Dict]) -> Optional[Dict]:
        """
        Anhade una lista de eventos a la base de datos.
        
        Args:
            eventos: Lista de eventos a insertar
            
        Returns:
            Respuesta de la API o None si hay error
        """
        config_manager = get_config_manager()
        api_config = config_manager.get_api_config()
        
        endpoint = api_config["eventos"]["add_list"]
        
        return self.api_request(endpoint, method="POST", data=eventos)
    
    def get_cambium_data(
        self, 
        start_date: str, 
        end_date: str, 
        limit: int = 1000, 
        offset: int = 0
    ) -> Optional[pd.DataFrame]:
        """
        Obtiene datos de Cambium.
        
        Args:
            start_date: Fecha de inicio en formato ISO
            end_date: Fecha de fin en formato ISO
            limit: Limite de registros
            offset: Offset para paginacion
            
        Returns:
            DataFrame con datos de Cambium o None si hay error
        """
        config_manager = get_config_manager()
        api_config = config_manager.get_api_config()
        
        endpoint = api_config["cambium_data"]["get"]
        url = f'{endpoint}?start_date={start_date}&end_date={end_date}&limit={limit}&offset={offset}'
        
        return self.api_request(url, dataframe=True)
    
    def get_eventos_previos(
        self, 
        ip: str, 
        start_date: str, 
        end_date: str, 
        limit: int = 1000, 
        offset: int = 0
    ) -> Optional[pd.DataFrame]:
        """
        Consulta eventos anteriores para una IP especifica.
        
        Args:
            ip: Direccion IP del equipo
            start_date: Fecha de inicio en formato ISO
            end_date: Fecha de fin en formato ISO
            limit: Limite de registros
            offset: Offset para paginacion
            
        Returns:
            DataFrame con eventos previos o None si no hay datos
        """
        config_manager = get_config_manager()
        api_config = config_manager.get_api_config()
        
        endpoint = api_config["eventos"]["get_ip"]
        url = f"{endpoint}/{ip}?start_date={start_date}&end_date={end_date}&limit={limit}&offset={offset}"
        
        data = self.api_request(url, dataframe=True)
        if data is None or data.empty:
            return None
        
        return data
    
    def get_eventos_urgentes(self, fecha: str) -> Optional[List[Dict]]:
        """
        Obtiene eventos urgentes desde una fecha especifica.
        
        Args:
            fecha: Fecha en formato ISO desde la cual buscar eventos urgentes
            
        Returns:
            Lista de eventos urgentes o None si hay error
        """
        config_manager = get_config_manager()
        api_config = config_manager.get_api_config()
        
        endpoint = api_config["eventos"]["urgentes"]
        url = f"{endpoint}?fecha={fecha}"
        
        return self.api_request(url, dataframe=False)
    
    def get_latencia_stats(
        self, 
        start_date: str, 
        end_date: str, 
        limit: int = 1000, 
        offset: int = 0,
        aprox_date: bool = True
    ) -> Optional[List[Dict]]:
        """
        Obtiene estadisticas detalladas de latencia por equipo.
        
        Args:
            start_date: Fecha de inicio en formato ISO
            end_date: Fecha de fin en formato ISO
            limit: Limite de registros
            offset: Offset para paginacion
            aprox_date: Si usar fechas aproximadas
            
        Returns:
            Lista de estadisticas por equipo o None si hay error
        """
        config_manager = get_config_manager()
        api_config = config_manager.get_api_config()
        
        endpoint = api_config["latencia"].get("get_latencia_stats", "/latencia/get_latencia_stats")
        url = f'{endpoint}?start_date={start_date}&end_date={end_date}&limit={limit}&offset={offset}&aprox_date={str(aprox_date).lower()}'
        
        return self.api_request(url, dataframe=False)
    
    def get_latencia_stats_summary(
        self, 
        start_date: str, 
        end_date: str
    ) -> Optional[Dict]:
        """
        Obtiene resumen global de estadisticas de latencia.
        
        Args:
            start_date: Fecha de inicio en formato ISO
            end_date: Fecha de fin en formato ISO
            
        Returns:
            Diccionario con estadisticas globales o None si hay error
        """
        config_manager = get_config_manager()
        api_config = config_manager.get_api_config()
        
        endpoint = api_config["latencia"].get("get_latencia_stats_summary", "/latencia/get_latencia_stats_summary")
        url = f'{endpoint}?start_date={start_date}&end_date={end_date}'
        
        return self.api_request(url, dataframe=False)


def round_to_nearest_quarter_hour(
    dt: Union[str, pd.Timestamp], 
    return_as_string: bool = False, 
    iso_format_string: bool = False
) -> Union[pd.Timestamp, str]:
    """
    Redondea la fecha a los 15 minutos mas cercanos.
    
    Args:
        dt: Fecha como string o timestamp
        return_as_string: Si True, retorna como string
        iso_format_string: Si True, usa formato ISO
        
    Returns:
        Fecha redondeada como timestamp o string
    """
    # Si dt es un string, lo convertimos a datetime usando pandas
    if isinstance(dt, str):
        dt = pd.to_datetime(dt)
    
    # Redondea los minutos a los 15 minutos mas cercanos
    minute = dt.minute
    rounded_minute = 15 * round(minute / 15)
    
    # Si el redondeo llega a 60 minutos, ajusta la hora y los minutos
    if rounded_minute == 60:
        dt += pd.Timedelta(hours=1)
        rounded_minute = 0
    
    # Reemplaza minutos, segundos y microsegundos
    dt = dt.replace(minute=rounded_minute, second=0, microsecond=0)
    
    # Si se requiere el resultado como string, lo formateamos
    if return_as_string:
        if iso_format_string:
            return dt.strftime('%Y-%m-%dT%H:%M:%S')
        else:
            return dt.strftime('%Y-%m-%d %H:%M:%S')
    
    # Si no, retornamos el objeto datetime
    return dt


def calcular_recurrencia(
    api_client: APIClient,
    ip: str, 
    fecha_evento: str, 
    tipo_evento: str, 
    intervalo_recurrencia: int, 
    limit: int = 1000, 
    offset: int = 0, 
    tipo_interferencia: Optional[str] = None
) -> int:
    """
    Calcula la recurrencia de eventos para una IP especifica.
    
    Args:
        api_client: Cliente de API para hacer requests
        ip: Direccion IP del equipo
        fecha_evento: Fecha del evento en formato ISO
        tipo_evento: Tipo de evento (ej. "Senhal Deficiente", "Interferencia")
        intervalo_recurrencia: Intervalo en minutos para buscar eventos previos
        limit: Limite de registros
        offset: Offset para paginacion
        tipo_interferencia: Tipo especifico de interferencia (snr_h, snr_v)
        
    Returns:
        Numero de recurrencias del evento
    """
    fecha_evento_dt = pd.to_datetime(fecha_evento)
    start_date = (fecha_evento_dt - timedelta(minutes=intervalo_recurrencia, seconds=5)).isoformat()
    end_date = fecha_evento_dt.strftime('%Y-%m-%dT%H:%M:%S')
    
    # Consultar eventos previos en la API
    eventos_previos = api_client.get_eventos_previos(
        ip=ip,
        start_date=start_date,
        end_date=end_date
    )
    
    if eventos_previos is None or len(eventos_previos) == 0:
        return 1
    
    # Si el tipo de evento es "Interferencia", filtrar segun el tipo de interferencia
    if tipo_evento == "Interferencia" and tipo_interferencia:
        eventos_previos["detalle"] = eventos_previos["detalle"].apply(
            lambda x: json.loads(x) if isinstance(x, str) else x
        )
        eventos_previos = eventos_previos[
            eventos_previos['detalle'].apply(
                lambda d: d.get('tipo_interferencia') == tipo_interferencia
            )
        ]
    
    # Obtener la recurrencia maxima de los eventos previos
    max_recurrencia = eventos_previos["recurrencia"].max() if "recurrencia" in eventos_previos.columns else 0
    recurrencia = max(max_recurrencia, len(eventos_previos)) + 1

    return int(recurrencia)


# Instancia global del cliente API
_api_client: Optional[APIClient] = None


def get_api_client(base_url: Optional[str] = None) -> APIClient:
    """
    Retorna la instancia global del cliente API.
    
    Args:
        base_url: URL base de la API
        
    Returns:
        APIClient: Instancia del cliente API
    """
    global _api_client
    
    if _api_client is None or base_url is not None:
        _api_client = APIClient(base_url)
    
    return _api_client