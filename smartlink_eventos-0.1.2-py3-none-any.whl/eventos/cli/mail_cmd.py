#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comando smartlink-mail para envio de estadisticas por correo electronico.
"""

import argparse
import sys

from ..services.mail import get_mail_service
from ..core.config import get_config_manager


def crear_parser() -> argparse.ArgumentParser:
    """Crea el parser de argumentos para el comando de correo."""
    parser = argparse.ArgumentParser(
        description='Envio de estadisticas por correo electronico',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  smartlink-mail send --empresa collahuasi                    # Envio basico (12h)
  smartlink-mail send --empresa collahuasi --hours-ago 24     # Ultimas 24 horas
  smartlink-mail send --empresa test --asunto "Urgente"       # Asunto personalizado
  smartlink-mail validate-config                             # Validar config
  smartlink-mail test --destinatario test@ejemplo.com        # Correo de prueba
        """
    )
    
    subparsers = parser.add_subparsers(dest='comando', help='Comandos disponibles')
    
    # Comando send
    send = subparsers.add_parser('send', help='Enviar estadisticas por email')
    send.add_argument('--empresa', required=True, help='Empresa (requerido)')
    send.add_argument('--hours-ago', type=int, default=12, help='Horas atras. Default: 12')
    send.add_argument('--asunto', help='Asunto personalizado')
    send.add_argument('--no-save-tables', action='store_true', help='No guardar tablas HTML')
    send.add_argument('--config', help='Archivo de configuracion personalizado')
    send.add_argument('--verbose', '-v', action='store_true', help='Info detallada')
    send.add_argument('--dry-run', action='store_true', help='Simular sin enviar')
    
    # Comando validate-config
    validate = subparsers.add_parser('validate-config', help='Validar configuracion')
    validate.add_argument('--config', help='Archivo de configuracion personalizado')
    
    # Comando test
    test = subparsers.add_parser('test', help='Enviar correo de prueba')
    test.add_argument('--destinatario', required=True, help='Email del destinatario')
    test.add_argument('--asunto', default='Correo de prueba - Smartlink', help='Asunto')
    test.add_argument('--config', help='Archivo de configuracion personalizado')
    
    # Comando show-config
    show = subparsers.add_parser('show-config', help='Mostrar configuracion')
    show.add_argument('--config', help='Archivo de configuracion personalizado')
    show.add_argument('--show-password', action='store_true', help='Mostrar password SMTP')
    
    return parser


def comando_send(args) -> int:
    """Ejecuta el envio de estadisticas por email."""
    try:
        if args.config:
            get_config_manager(args.config)
        
        mail_service = get_mail_service()
        
        if args.verbose:
            print(f"📧 Enviando estadisticas para {args.empresa} ({args.hours_ago}h)")
        
        # Validar configuracion
        if not mail_service.validar_configuracion_email():
            print("❌ Configuracion de email invalida")
            return 1
        
        # Dry run
        if args.dry_run:
            stats_equipos, stats_global = mail_service.obtener_estadisticas_latencia(args.hours_ago)
            print(f"🧪 DRY RUN - Estadisticas: {len(stats_equipos)} equipos")
            if stats_global:
                print(f"📊 {stats_global.get('total_mediciones', 0)} mediciones globales")
            return 0
        
        # Envio real
        exito = mail_service.enviar_estadisticas_por_email(
            empresa=args.empresa,
            hours_ago=args.hours_ago,
            guardar_tabla=not args.no_save_tables,
            asunto_personalizado=args.asunto
        )
        
        if exito:
            print(f"✅ Estadisticas enviadas exitosamente para {args.empresa}")
            return 0
        else:
            print("❌ Fallo el envio")
            return 1
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def comando_validate(args) -> int:
    """Valida la configuracion de email."""
    try:
        if args.config:
            get_config_manager(args.config)
        
        mail_service = get_mail_service()
        es_valida = mail_service.validar_configuracion_email()
        
        if es_valida:
            print("✅ Configuracion de email valida")
            return 0
        else:
            print("❌ Configuracion de email invalida")
            return 1
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def comando_test(args) -> int:
    """Envia un correo de prueba."""
    try:
        if args.config:
            get_config_manager(args.config)
        
        mail_service = get_mail_service()
        email_config = mail_service.obtener_configuracion_email()
        
        html_mensaje = f"""
        <html><body>
            <h2>Correo de Prueba - Smartlink</h2>
            <p>Este es un mensaje de prueba enviado desde smartlink-mail</p>
            <p><strong>Remitente:</strong> {email_config['remitente']}</p>
        </body></html>
        """
        
        exito = mail_service.enviar_correo_html(
            remitente=email_config["remitente"],
            clave=email_config["smtp_password"],
            destinatarios=[args.destinatario],
            con_copia=[],
            asunto=args.asunto,
            html=html_mensaje
        )
        
        if exito:
            print(f"✅ Correo de prueba enviado a {args.destinatario}")
            return 0
        else:
            print("❌ Fallo el envio de prueba")
            return 1
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def comando_show_config(args) -> int:
    """Muestra la configuracion de email."""
    try:
        config_manager = get_config_manager(args.config)
        email_config = config_manager.get_email_config()
        
        print("📧 CONFIGURACION EMAIL")
        print("=" * 30)
        
        for key, value in email_config.items():
            if key == 'smtp_password' and not args.show_password:
                print(f"{key}: {'*' * 10}")
            elif isinstance(value, list):
                print(f"{key}: {len(value)} elementos")
            else:
                print(f"{key}: {value}")
                
        return 0
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def main():
    """Funcion principal del comando smartlink-mail."""
    parser = crear_parser()
    args = parser.parse_args()
    
    if not args.comando:
        parser.print_help()
        return 0
    
    if args.comando == 'send':
        return comando_send(args)
    elif args.comando == 'validate-config':
        return comando_validate(args)
    elif args.comando == 'test':
        return comando_test(args)
    elif args.comando == 'show-config':
        return comando_show_config(args)
    else:
        print(f"❌ Comando desconocido: {args.comando}")
        return 1


if __name__ == "__main__":
    sys.exit(main())