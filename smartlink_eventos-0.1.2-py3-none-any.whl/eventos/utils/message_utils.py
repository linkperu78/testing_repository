from typing import List, Dict, Any, Optional


def generar_destinatario(mudslice_id: str) -> str:
    """
    Mapea un ID de mudslice a un nombre de destinatario.
    
    Args:
        mudslice_id: ID del destinatario en mudslice
        
    Returns:
        str: Nombre del destinatario
    """
    destinatarios_map = {
        "+56977566595": "Cristobal",
        "120363027104819888@g.us": "Collahuasi",
        "+56971083001": "Ricardo", 
        "+56982280571": "Hector Veliz",
        "+56976426949": "Daniel",
        "+56939496396": "equipo del turno de automatizacion de la mina"
    }
    
    return destinatarios_map.get(mudslice_id, "Collahuasi")


def formatear_introduccion(saludo: str, destinatario: str) -> str:
    """
    Formatea la introduccion del mensaje segun el destinatario.
    
    Args:
        saludo: Saludo inicial (Buenos dias, Buenas tardes, etc.)
        destinatario: Nombre del destinatario
        
    Returns:
        str: Introduccion formateada
    """
    if destinatario == "Collahuasi":
        return f"{saludo} estimado equipo de {destinatario}"
    elif destinatario == "equipo del turno de automatizacion de la mina":
        return f"{saludo} estimado {destinatario}"
    else:
        return f"{saludo} estimado {destinatario}"


def clasificar_alertas(alertas: List[Dict[str, Any]]) -> tuple[List[Dict], List[Dict]]:
    """
    Clasifica las alertas en senhal deficiente e interferencias.
    
    Args:
        alertas: Lista de alertas desde la API
        
    Returns:
        tuple: (senhal_deficientes, interferencias)
    """
    senhal_deficientes = []
    interferencias = []
    
    for alerta in alertas:
        problema = alerta.get("problema", "").lower()
        
        if "senhal deficiente" == problema:
            data = {
                "ip": alerta.get("ip"),
                "fecha": alerta.get("fecha"),
                "estado": alerta.get("estado"),
                "problema": alerta.get("problema"),
                "recurrencia": alerta.get("recurrencia"),
                "tag": alerta.get("tag"),
                "marca": alerta.get("marca"),
                "tipo": alerta.get("tipo"),
                "emoji": alerta.get("emoji"),
                "latencia": alerta.get("detalle", {}).get("latencia", "No disponible")
            }
            senhal_deficientes.append(data)
            
        elif "interferencia" == problema:
            data = {
                "ip": alerta.get("ip"),
                "fecha": alerta.get("fecha"),
                "estado": alerta.get("estado"),
                "problema": alerta.get("problema"),
                "recurrencia": alerta.get("recurrencia"),
                "tag": alerta.get("tag"),
                "marca": alerta.get("marca"),
                "tipo": alerta.get("tipo"),
                "emoji": alerta.get("emoji"),
                "detalle": alerta.get("detalle", {})
            }
            interferencias.append(data)
    
    return senhal_deficientes, interferencias


def crear_tabla_html(alertas: List[Dict], tipo_alerta: str) -> str:
    """
    Crea una tabla HTML con columnas adaptadas al tipo de alerta.
    
    Args:
        alertas: Lista de alertas
        tipo_alerta: Tipo de alerta para el titulo
        
    Returns:
        str: Tabla HTML generada
    """
    print(f"Creando tabla para {len(alertas)} alertas de tipo {tipo_alerta}")
    
    tipo_alerta_titulo = f"{tipo_alerta.capitalize()}"

    if not alertas:
        return f"<h2>{tipo_alerta_titulo}</h2><p>No hay alertas para mostrar.</p>"

    # Columnas base
    columnas = ["fecha", "estado", "ip", "tag", "marca", "tipo", "recurrencia"]

    # Agregar columnas especificas segun tipo
    if tipo_alerta.lower() == "senhal deficiente":
        columnas += ["latencia"]
    elif "interferencia" in tipo_alerta.lower():
        columnas += ["snr_h", "snr_v"]
    elif "temperatura" in tipo_alerta.lower():
        columnas += ["temperatura"]

    # Encabezado
    html = f"<h2 style='color:#2E86C1;'>Alertas de {tipo_alerta_titulo}</h2>"
    html += "<table border='1' cellpadding='6' cellspacing='0' style='border-collapse: collapse; font-size: 13px; font-family: Arial;'>"
    html += "<thead style='background-color:#f2f2f2;'><tr>"
    for col in columnas:
        nombre_col = "nombre" if col == "tag" else col
        html += f"<th>{nombre_col.capitalize()}</th>"
    html += "</tr></thead><tbody>"

    # Filas
    for alerta in alertas:
        html += "<tr>"
        for col in columnas:
            if col == "latencia":
                valor_sin_redondear = alerta.get("latencia", "")
                if valor_sin_redondear != "":
                    valor = str(round(alerta.get("latencia"), 2))
                else:
                    valor = ""
            else:
                valor = alerta.get(col)
                if valor is None and isinstance(alerta.get("detalle"), dict):
                    valor = alerta["detalle"].get(col)
            html += f"<td>{valor if valor is not None else ''}</td>"
        html += "</tr>"

    html += "</tbody></table><br>"
    return html


def guardar_html_archivo(html: str, nombre_archivo: str = "alertas.html") -> None:
    """
    Guarda contenido HTML en un archivo.
    
    Args:
        html: Contenido HTML
        nombre_archivo: Nombre del archivo a crear
    """
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        f.write(f"""
        <html>
            <head><meta charset="utf-8"></head>
            <body>
                {html}
            </body>
        </html>
        """)
    print(f"✅ Archivo guardado como {nombre_archivo}")


def validar_email_destinatarios(destinatarios: List[str]) -> bool:
    """
    Valida que la lista de destinatarios de email sea correcta.
    
    Args:
        destinatarios: Lista de emails
        
    Returns:
        bool: True si todos los emails son validos
    """
    if not destinatarios:
        return False
    
    import re
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    for email in destinatarios:
        if not re.match(email_pattern, email):
            print(f"❌ Email invalido: {email}")
            return False
    
    return True


def validar_mudslice_ids(mudslice_ids: List[str]) -> bool:
    """
    Valida que la lista de IDs de mudslice sea correcta.
    
    Args:
        mudslice_ids: Lista de IDs de mudslice
        
    Returns:
        bool: True si todos los IDs son validos
    """
    if not mudslice_ids:
        print("❌ Lista de mudslice_ids vacia")
        return False
    
    for mudslice_id in mudslice_ids:
        if not isinstance(mudslice_id, str) or len(mudslice_id.strip()) == 0:
            print(f"❌ Mudslice ID invalido: {mudslice_id}")
            return False
    
    return True


def sanitizar_mensaje_windows(mensaje: str) -> str:
    """
    Sanitiza un mensaje para uso en Windows.
    
    Args:
        mensaje: Mensaje original
        
    Returns:
        str: Mensaje sanitizado
    """
    return mensaje.replace("\n", "\\n")


def truncar_mensaje(mensaje: str, max_length: int = 4000) -> str:
    """
    Trunca un mensaje si excede la longitud maxima.
    
    Args:
        mensaje: Mensaje original
        max_length: Longitud maxima permitida
        
    Returns:
        str: Mensaje truncado si es necesario
    """
    if len(mensaje) <= max_length:
        return mensaje
    
    truncated = mensaje[:max_length - 3] + "..."
    print(f"⚠️ Mensaje truncado de {len(mensaje)} a {len(truncated)} caracteres")
    return truncated


def contar_palabras_clave(mensaje: str, palabras_clave: List[str]) -> Dict[str, int]:
    """
    Cuenta las ocurrencias de palabras clave en un mensaje.
    
    Args:
        mensaje: Mensaje a analizar
        palabras_clave: Lista de palabras a buscar
        
    Returns:
        dict: Conteo de cada palabra clave
    """
    mensaje_lower = mensaje.lower()
    conteos = {}
    
    for palabra in palabras_clave:
        conteos[palabra] = mensaje_lower.count(palabra.lower())
    
    return conteos


def es_mensaje_urgente(alertas: List[Dict], umbral_alarmas: int = 1) -> bool:
    """
    Determina si un conjunto de alertas requiere atencion urgente.
    
    Args:
        alertas: Lista de alertas
        umbral_alarmas: Numero minimo de alarmas para considerar urgente
        
    Returns:
        bool: True si es urgente
    """
    if not alertas:
        return False
    
    alarmas_count = sum(1 for alerta in alertas if alerta.get("estado", "").lower() == "alarma")
    
    return alarmas_count >= umbral_alarmas


def formatear_lista_destinatarios(destinatarios: List[str]) -> str:
    """
    Formatea una lista de destinatarios para mostrar.
    
    Args:
        destinatarios: Lista de destinatarios
        
    Returns:
        str: String formateado con los destinatarios
    """
    if not destinatarios:
        return "Ninguno"
    
    if len(destinatarios) == 1:
        return destinatarios[0]
    elif len(destinatarios) == 2:
        return f"{destinatarios[0]} y {destinatarios[1]}"
    else:
        return f"{', '.join(destinatarios[:-1])} y {destinatarios[-1]}"