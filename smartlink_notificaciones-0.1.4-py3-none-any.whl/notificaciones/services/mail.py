# src/notificaciones/services/mail.py
# -*- coding: utf-8 -*-

import os
import smtplib
import re
from typing import List, Dict, Optional, Tuple
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from notificaciones.core.config import load_config
from notificaciones.core.ai import get_openai_client, mensaje_chat_gpt


# Umbrales y límites
THRESHOLD_CRITICO_SIMPLE = 10.0   # % para considerar “problemático” (modo simple)
MAX_CRITICOS = 5                  # máximo equipos listados


# ============== Utilidades ==============

def _cap(s: Optional[str], default: str = "Cliente") -> str:
    return (s or default).capitalize()


def _fnum(x, dflt=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return dflt


def _sanitize_gpt_html(s: Optional[str]) -> str:
    """Quita fences y normaliza headings; bloquea tablas indebidas."""
    if not s:
        return ""
    # quitar fences
    s = s.replace("```html", "").replace("```HTML", "").replace("```", "").strip()

    # normalizar espacios
    s = re.sub(r"\s+\n", "\n", s)
    s = re.sub(r"\n\s+", "\n", s)

    # no permitir h1; h2 -> h3
    s = re.sub(r"</?h1\b[^>]*>", "", s, flags=re.IGNORECASE)
    s = re.sub(r"<h2\b[^>]*>", "<h3>", s, flags=re.IGNORECASE)
    s = re.sub(r"</h2>", "</h3>", s, flags=re.IGNORECASE)

    # eliminar cualquier tabla que meta GPT
    s = re.sub(r"<table\b.*?</table>", "", s, flags=re.IGNORECASE | re.DOTALL)

    # eliminar duplicados de "Resumen global" si aparecieran
    s = re.sub(
        r"<h3[^>]*>\s*Resumen\s+global\s*</h3>.*?(?=(<h3\b|$))",
        "",
        s,
        flags=re.IGNORECASE | re.DOTALL,
    )
    return s.strip()


def _smtp_params(cfg) -> Tuple[str, int, str, str, List[str], List[str]]:
    server = cfg.get("email.smtp_server", "smtp.gmail.com")
    port = int(cfg.get("email.smtp_port", cfg.get("email.smtp_puerto", 587)))
    user = cfg.get("email.remitente")
    pwd = cfg.get("email.smtp_password")
    to = cfg.get("email.destinatarios", []) or []
    cc = cfg.get("email.cc", cfg.get("email.con_copia", [])) or []
    return server, port, user, pwd, to, cc


def _subject_from_cfg(cfg, empresa: str) -> str:
    tpl = cfg.get("mensajes.email_subject", "Reporte del turno - {Empresa}")
    Empresa = _cap(empresa)
    return tpl.format(empresa=empresa, Empresa=Empresa)


def _send_html(cfg, subject: str, html: str) -> bool:
    server, port, user, pwd, to, cc = _smtp_params(cfg)
    if not (user and pwd and to):
        print("❌ Config de correo incompleta (remitente/clave/destinatarios).")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)

    msg.attach(MIMEText(html, "html", "utf-8"))

    try:
        with smtplib.SMTP(server, port, timeout=60) as s:
            s.starttls()
            s.login(user, pwd)
            s.sendmail(user, to + cc, msg.as_string())
        print(f"✅ Correo enviado a: {len(to)} destinatarios (+{len(cc)} CC)")
        return True
    except Exception as e:
        print(f"❌ Error enviando correo: {e}")
        return False


# ============== Helpers de contenido (FULL) ==============

def _build_email_html_table(Empresa: str, horas: int, stats_equipos: List[Dict], stats_global: Dict) -> str:
    """
    Tabla (modo FULL). Mantiene % Alta, Recurrencia >100ms, etc.
    """
    equipos = stats_equipos or []

    # encabezado resumen global
    resumen = stats_global or {}
    def fmt_gl(key, val):
        if val is None:
            return ""
        try:
            if key in {"promedio_general", "max_global", "min_global"}:
                return f"{float(val):.1f}"
            if key == "porcentaje_latencia_alta":
                fval = float(val)
                return "~0%" if (0 <= fval < 0.00001) else f"{fval:.2f}%"
        except Exception:
            return val
        return val

    resumen_html = (
        "<h3>Resumen general</h3>"
        "<ul style='margin-top:4px;'>"
    )
    for key, label in [
        ("total_ips", "IPs"),
        ("total_mediciones", "Mediciones"),
        ("total_mediciones_validas", "Válidas (>0)"),
        ("desconexiones", "Desconexiones"),
        ("promedio_general", "Promedio (ms)"),
        ("max_global", "Máximo (ms)"),
        ("min_global", "Mínimo (ms)"),
        ("mediciones_altas", ">100 ms"),
        ("porcentaje_latencia_alta", "% alta (sobre válidas)"),
    ]:
        v = resumen.get(key)
        if v is not None:
            resumen_html += f"<li><strong>{label}:</strong> {fmt_gl(key, v)}</li>"
    resumen_html += "</ul>"

    # tabla por equipo
    def fmt_cell(v, key):
        if v is None:
            return ""
        try:
            if key in {"promedio_latencia", "max_latencia", "min_latencia"}:
                return f"{float(v):.1f}"
            if key == "porcentaje_latencia_alta":
                fval = float(v)
                if 0 <= fval < 0.00001:
                    return "~0%"
                else:
                    return f"{fval:.2f}%"
        except Exception:
            return v
        return v

    headers = [
        ("tag", "Tag"),
        ("ip", "IP"),
        ("promedio_latencia", "Promedio (ms)"),
        ("max_latencia", "Máximo (ms)"),
        ("min_latencia", "Mínimo (ms)"),
        ("latencia_100_200", "100–200 ms"),
        ("latencia_mayor_200", ">200 ms"),
        ("porcentaje_latencia_alta", "% Alta"),
        ("desconexiones", "Desconexiones"),
        ("marca", "Marca"),
        ("tipo", "Tipo"),
    ]

    rows = ""
    for e in equipos:
        tds = "".join(
            f"<td style='padding:6px 8px;border-bottom:1px solid #eee'>{fmt_cell(e.get(k), k)}</td>"
            for k, _ in headers
        )
        rows += f"<tr>{tds}</tr>"

    table_html = (
        "<h3>Estadísticas por equipo</h3>"
        "<table style='width:100%;border-collapse:collapse;font-size:13px'>"
        "<thead><tr>" +
        "".join(f"<th style='text-align:left;padding:8px;border-bottom:2px solid #ddd'>{h}</th>" for _, h in headers) +
        "</tr></thead>"
        "<tbody>" + rows + "</tbody></table>"
    )

    return resumen_html + table_html


def _email_intro_with_gpt(
    Empresa: str,
    stats_equipos: List[Dict],
    stats_global: Dict,
    prompt_path: Optional[str] = None,
) -> str:
    """
    Intro analítica (FULL). Usa IA; permite prompt externo.
    """
    client = get_openai_client()
    if not client:
        return ""

    equipos = stats_equipos or []
    def fnum(x):
        try: 
            return float(x or 0)
        except: 
            return 0.0

    THRESH = 2.0  # para el modo full mantenemos umbral suave p/analítica
    criticos = [e for e in equipos if fnum(e.get("porcentaje_latencia_alta")) >= THRESH]
    top_pct = sorted(criticos, key=lambda e: fnum(e.get("porcentaje_latencia_alta")), reverse=True)[:5]
    top_200 = sorted(equipos, key=lambda e: fnum(e.get("latencia_mayor_200")), reverse=True)[:5]

    datos = {
        "empresa": Empresa,
        "global": stats_global or {},
        "umbral_pct_alta": THRESH,
        "top_porcentaje": top_pct,
        "top_mayor_200ms": top_200,
    }

    if prompt_path and os.path.isfile(prompt_path):
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt = f.read()
        # Opcional: soportar placeholders comunes
        prompt = prompt.format(empresa=Empresa, datos=datos)
    else:
        prompt = (
            "Eres un asistente que redacta un reporte técnico breve en HTML para correo. "
            "Este reporte es generado por Smartlink, un software de HC-GROUP para monitoreo de equipos de telecomunicaciones "
            "en faenas mineras. El reporte corresponde al último turno. "
            "El destinatario es un supervisor de operaciones; usa un tono claro y profesional chileno. "
            "Reglas IMPORTANTES:\n"
            f" - Considera IPs 'críticas' solo si su % de latencia alta ≥ {datos['umbral_pct_alta']}%.\n"
            " - NO repitas el 'Resumen global' ni intentes crear tablas (ya las añade el sistema).\n"
            " - Si hay críticas, lista 3–5 IPs relevantes y comenta patrones por marca/tipo si existen.\n"
            " - Si no hay críticas, indica que el rendimiento general es bueno con eventos puntuales.\n"
            " - No incluyas título principal; si usas subtítulos, que sean <h3>.\n"
            " - Devuelve solo HTML (sin ``` ni <table>).\n\n"
            f"DATOS:\n{datos}\n"
        )

    html = mensaje_chat_gpt(client, prompt, is_windows=False)
    return _sanitize_gpt_html(html)


# ============== Selección de críticos (SIMPLE) ==============

def _equipos_problema_simple(stats_equipos: List[Dict]) -> List[Dict]:
    """
    Modo simple: filtra equipos con % alta >= 10% y ordena por máximo y promedio.
    *OJO*: no mostramos el %, solo ms.
    """
    candidatos = [
        e for e in (stats_equipos or [])
        if _fnum(e.get("porcentaje_latencia_alta")) >= THRESHOLD_CRITICO_SIMPLE
    ]
    candidatos.sort(
        key=lambda e: (_fnum(e.get("max_latencia")), _fnum(e.get("promedio_latencia"))),
        reverse=True,
    )
    return candidatos[:MAX_CRITICOS]


# ============== Servicio de correo ==============

class MailService:
    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    # --------- MODO SIMPLE (por defecto) ---------
    def enviar_reporte_simple(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        prompt_path: Optional[str] = None,
    ) -> bool:
        """
        Modo simple:
        - sin % de latencia alta
        - sin tabla
        - sin 'Resumen general'
        - lista hasta 5 equipos problemáticos (>=10%) con Máx/Prom en ms + Marca/Tipo
        """
        Empresa = _cap(empresa)

        # IA (prompt externo si viene)
        intro_html = ""
        client = get_openai_client()
        criticos = _equipos_problema_simple(stats_equipos)

        if client:
            datos = {
                "empresa": Empresa,
                "horas": horas,
                "criticos": criticos,
                "umbral_pct": THRESHOLD_CRITICO_SIMPLE,
            }
            if prompt_path and os.path.isfile(prompt_path):
                with open(prompt_path, "r", encoding="utf-8") as f:
                    prompt = f.read()
                prompt = prompt.format(empresa=Empresa, datos=datos, criticos=criticos, umbral_pct=THRESHOLD_CRITICO_SIMPLE)
            else:
                prompt = (
                    "Eres un asistente que redacta un reporte técnico breve en HTML para correo (Chile, español). "
                    "Este reporte es generado por Smartlink, un software de HC-GROUP para monitoreo de equipos de telecomunicaciones "
                    "en faenas mineras. El reporte corresponde al último turno. "
                    "Objetivo: mensaje simple que cualquiera pueda entender.\n"
                    "Formato: un párrafo breve y una lista (máximo 5) con equipos problemáticos (definidos por umbral 10%). "
                    "Cada ítem debe mostrar Tag/IP, Máximo (ms), Promedio (ms) y Marca/Tipo. "
                    "No uses porcentajes, no incluyas resumen global, evita jerga innecesaria. "
                    "Usa <p> y <ul><li>; no uses <table> ni bloques de código.\n\n"
                    f"DATOS:\n{datos}\n"
                    "Devuelve solo HTML."
                )
            intro_html = _sanitize_gpt_html(mensaje_chat_gpt(client, prompt, is_windows=False) or "")

        # Fallback determinista si la IA falla o está ausente
        if not intro_html:
            lines = []
            if criticos:
                lines.append("<p>Se identificaron equipos con latencia elevada durante el turno:</p><ul>")
                for e in criticos:
                    tag = e.get("tag") or e.get("ip") or ""
                    ip = e.get("ip") or ""
                    mx = _fnum(e.get("max_latencia"))
                    pr = _fnum(e.get("promedio_latencia"))
                    marca = e.get("marca") or ""
                    tipo = e.get("tipo") or ""
                    lines.append(
                        f"<li><strong>{tag}</strong> ({ip}) – Máximo: {mx:.1f} ms · Promedio: {pr:.1f} ms · {marca} {tipo}</li>"
                    )
                lines.append("</ul>")
            else:
                lines.append("<p>Sin equipos problemáticos en el turno. Rendimiento general adecuado.</p>")
            intro_html = "\n".join(lines)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"<h2>Reporte del turno - {Empresa}</h2>"
            f"{intro_html}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )
        subject = _subject_from_cfg(self.cfg, Empresa)
        return _send_html(self.cfg, subject, html)

    # --------- MODO FULL (con tabla/porcentajes/resumen) ---------
    def enviar_reporte(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        stats_global: Dict,
        prompt_path: Optional[str] = None,
    ) -> bool:
        """
        Modo full (mantiene el comportamiento previo):
        - Intro con IA (sin título principal, sin repetir resumen)
        - Tabla por equipo (incluye % Alta) + Resumen general
        """
        Empresa = _cap(empresa)

        intro_html = _email_intro_with_gpt(Empresa, stats_equipos, stats_global, prompt_path) or ""
        tabla_html = _build_email_html_table(Empresa, horas, stats_equipos, stats_global)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"<h2>Reporte del turno - {Empresa}</h2>"
            f"{intro_html}"
            f"{tabla_html}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )

        subject = _subject_from_cfg(self.cfg, Empresa)
        return _send_html(self.cfg, subject, html)
