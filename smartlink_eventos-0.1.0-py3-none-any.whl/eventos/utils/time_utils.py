import pytz
from datetime import datetime, timedelta
from typing import Union, Optional


def saludo_inicial_hora(hora: int) -> str:
    """
    Genera un saludo apropiado segun la hora del dia.
    
    Args:
        hora: Hora en formato 24h (0-23)
        
    Returns:
        str: Saludo apropiado
    """
    if 8 <= hora < 12:
        return "Buenos dias"
    elif 12 <= hora <= 20:
        return "Buenas tardes"
    else:
        return "Buenas noches"


def get_current_hour() -> int:
    """
    Obtiene la hora actual.
    
    Returns:
        int: Hora actual en formato 24h
    """
    return datetime.now().hour


def get_saludo_actual() -> str:
    """
    Obtiene el saludo apropiado para la hora actual.
    
    Returns:
        str: Saludo apropiado para la hora actual
    """
    return saludo_inicial_hora(get_current_hour())


def get_datetime_hours_ago(hours: int = 1, minutes: int = 0) -> datetime:
    """
    Obtiene una fecha/hora X horas y minutos atras.
    
    Args:
        hours: Numero de horas atras
        minutes: Numero de minutos atras
        
    Returns:
        datetime: Fecha/hora calculada
    """
    return datetime.now() - timedelta(hours=hours, minutes=minutes)


def get_iso_string_hours_ago(hours: int = 1, minutes: int = 0) -> str:
    """
    Obtiene una fecha en formato ISO X horas y minutos atras.
    
    Args:
        hours: Numero de horas atras
        minutes: Numero de minutos atras
        
    Returns:
        str: Fecha en formato ISO
    """
    dt = get_datetime_hours_ago(hours, minutes)
    return dt.strftime('%Y-%m-%dT%H:%M:%S')


def get_current_iso_string() -> str:
    """
    Obtiene la fecha/hora actual en formato ISO.
    
    Returns:
        str: Fecha actual en formato ISO
    """
    return datetime.now().strftime('%Y-%m-%dT%H:%M:%S')


def get_default_date_range() -> tuple[str, str]:
    """
    Obtiene un rango de fechas por defecto para consultas.
    Por defecto: desde 4 minutos atras hasta 2 minutos en el futuro.
    
    Returns:
        tuple: (start_date, end_date) en formato ISO
    """
    start_date = get_iso_string_hours_ago(hours=0, minutes=4)
    end_date = (datetime.now() + timedelta(minutes=2)).strftime('%Y-%m-%dT%H:%M:%S')
    return start_date, end_date


def convert_to_timezone(
    dt: Union[datetime, str], 
    target_timezone: str = "America/Santiago",
    source_timezone: Optional[str] = None
) -> datetime:
    """
    Convierte una fecha a una zona horaria especifica.
    
    Args:
        dt: Fecha como datetime o string ISO
        target_timezone: Zona horaria destino
        source_timezone: Zona horaria origen (None para UTC)
        
    Returns:
        datetime: Fecha convertida a la zona horaria destino
    """
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))
    
    # Si no tiene timezone info, asumir que es UTC
    if dt.tzinfo is None:
        if source_timezone:
            source_tz = pytz.timezone(source_timezone)
            dt = source_tz.localize(dt)
        else:
            dt = pytz.UTC.localize(dt)
    
    # Convertir a timezone destino
    target_tz = pytz.timezone(target_timezone)
    return dt.astimezone(target_tz)


def format_datetime_for_display(
    dt: Union[datetime, str],
    format_string: str = "%Y-%m-%d %H:%M:%S",
    timezone: str = "America/Santiago"
) -> str:
    """
    Formatea una fecha para mostrar al usuario.
    
    Args:
        dt: Fecha como datetime o string ISO
        format_string: Formato de salida
        timezone: Zona horaria para mostrar
        
    Returns:
        str: Fecha formateada
    """
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))
    
    # Convertir a timezone local
    local_dt = convert_to_timezone(dt, timezone)
    
    return local_dt.strftime(format_string)


def is_within_business_hours(
    dt: Optional[datetime] = None,
    start_hour: int = 8,
    end_hour: int = 18,
    timezone: str = "America/Santiago"
) -> bool:
    """
    Verifica si una fecha esta dentro del horario laboral.
    
    Args:
        dt: Fecha a verificar (None para fecha actual)
        start_hour: Hora de inicio del horario laboral
        end_hour: Hora de fin del horario laboral
        timezone: Zona horaria
        
    Returns:
        bool: True si esta en horario laboral
    """
    if dt is None:
        dt = datetime.now()
    
    local_dt = convert_to_timezone(dt, timezone)
    hour = local_dt.hour
    
    return start_hour <= hour < end_hour


def get_next_business_hour(
    current_dt: Optional[datetime] = None,
    start_hour: int = 8,
    timezone: str = "America/Santiago"
) -> datetime:
    """
    Obtiene la proxima hora laboral.
    
    Args:
        current_dt: Fecha actual (None para usar datetime.now())
        start_hour: Hora de inicio del horario laboral
        timezone: Zona horaria
        
    Returns:
        datetime: Proxima hora laboral
    """
    if current_dt is None:
        current_dt = datetime.now()
    
    local_dt = convert_to_timezone(current_dt, timezone)
    
    # Si ya es horario laboral, retornar la misma fecha
    if is_within_business_hours(local_dt, start_hour=start_hour, timezone=timezone):
        return local_dt
    
    # Si es antes del horario laboral, retornar hoy a la hora de inicio
    if local_dt.hour < start_hour:
        return local_dt.replace(hour=start_hour, minute=0, second=0, microsecond=0)
    
    # Si es despues del horario laboral, retornar manhana a la hora de inicio
    next_day = local_dt + timedelta(days=1)
    return next_day.replace(hour=start_hour, minute=0, second=0, microsecond=0)


def calculate_time_difference(
    start_dt: Union[datetime, str],
    end_dt: Union[datetime, str]
) -> dict:
    """
    Calcula la diferencia entre dos fechas.
    
    Args:
        start_dt: Fecha de inicio
        end_dt: Fecha de fin
        
    Returns:
        dict: Diferencia en dias, horas, minutos y segundos
    """
    if isinstance(start_dt, str):
        start_dt = datetime.fromisoformat(start_dt.replace('Z', '+00:00'))
    if isinstance(end_dt, str):
        end_dt = datetime.fromisoformat(end_dt.replace('Z', '+00:00'))
    
    diff = end_dt - start_dt
    
    days = diff.days
    hours, remainder = divmod(diff.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    return {
        "days": days,
        "hours": hours,
        "minutes": minutes,
        "seconds": seconds,
        "total_seconds": diff.total_seconds()
    }


def get_time_range_for_alerts(hours_back: int = 8) -> tuple[str, str]:
    """
    Obtiene un rango de tiempo para buscar alertas.
    
    Args:
        hours_back: Numero de horas hacia atras
        
    Returns:
        tuple: (start_date, end_date) en formato ISO
    """
    end_date = get_current_iso_string()
    start_date = get_iso_string_hours_ago(hours=hours_back)
    
    return start_date, end_date


def sleep_until_next_execution(
    target_hour: int,
    target_minute: int = 0,
    timezone: str = "America/Santiago"
) -> int:
    """
    Calcula cuantos segundos esperar hasta la proxima ejecucion programada.
    
    Args:
        target_hour: Hora objetivo
        target_minute: Minuto objetivo
        timezone: Zona horaria
        
    Returns:
        int: Segundos hasta la proxima ejecucion
    """
    now = datetime.now()
    local_now = convert_to_timezone(now, timezone)
    
    # Calcular la proxima ejecucion
    next_execution = local_now.replace(
        hour=target_hour, 
        minute=target_minute, 
        second=0, 
        microsecond=0
    )
    
    # Si ya paso la hora de hoy, programar para manhana
    if next_execution <= local_now:
        next_execution += timedelta(days=1)
    
    # Calcular segundos hasta la ejecucion
    diff = next_execution - local_now
    return int(diff.total_seconds())