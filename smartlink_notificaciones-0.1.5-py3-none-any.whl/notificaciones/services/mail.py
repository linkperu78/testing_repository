# src/notificaciones/services/mail.py
# -*- coding: utf-8 -*-

import os
import smtplib
import re
from typing import List, Dict, Optional, Tuple
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from notificaciones.core.config import load_config
from notificaciones.core.ai import get_openai_client, mensaje_chat_gpt


# ================== Parámetros globales ==================

DEFAULT_THRESHOLD_CRITICO = 10.0  # % de latencia alta para considerar “crítico”
MAX_CRITICOS = 5                  # máximo equipos listados


# ================== Utilidades ==================

def _cap(s: Optional[str], default: str = "Cliente") -> str:
    return (s or default).capitalize()


def _fnum(x, dflt=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return dflt


def _sanitize_gpt_html(s: Optional[str]) -> str:
    """Quita fences y normaliza headings; bloquea tablas indebidas."""
    if not s:
        return ""
    s = s.replace("```html", "").replace("```HTML", "").replace("```", "").strip()
    s = re.sub(r"\s+\n", "\n", s)
    s = re.sub(r"\n\s+", "\n", s)
    s = re.sub(r"</?h1\b[^>]*>", "", s, flags=re.IGNORECASE)
    s = re.sub(r"<h2\b[^>]*>", "<h3>", s, flags=re.IGNORECASE)
    s = re.sub(r"</h2>", "</h3>", s, flags=re.IGNORECASE)
    s = re.sub(r"<table\b.*?</table>", "", s, flags=re.IGNORECASE | re.DOTALL)
    s = re.sub(
        r"<h3[^>]*>\s*Resumen\s+global\s*</h3>.*?(?=(<h3\b|$))",
        "",
        s,
        flags=re.IGNORECASE | re.DOTALL,
    )
    return s.strip()


def _smtp_params(cfg) -> Tuple[str, int, str, str, List[str], List[str]]:
    server = cfg.get("email.smtp_server", "smtp.gmail.com")
    port = int(cfg.get("email.smtp_port", cfg.get("email.smtp_puerto", 587)))
    user = cfg.get("email.remitente")
    pwd = cfg.get("email.smtp_password")
    to = cfg.get("email.destinatarios", []) or []
    cc = cfg.get("email.cc", cfg.get("email.con_copia", [])) or []
    return server, port, user, pwd, to, cc


def _subject_from_cfg(cfg, empresa: str) -> str:
    tpl = cfg.get("mensajes.email_subject", "Reporte del turno - {Empresa}")
    Empresa = _cap(empresa)
    return tpl.format(empresa=empresa, Empresa=Empresa)


def _send_html(cfg, subject: str, html: str) -> bool:
    server, port, user, pwd, to, cc = _smtp_params(cfg)
    if not (user and pwd and to):
        print("❌ Config de correo incompleta (remitente/clave/destinatarios).")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)

    msg.attach(MIMEText(html, "html", "utf-8"))

    try:
        with smtplib.SMTP(server, port, timeout=60) as s:
            s.starttls()
            s.login(user, pwd)
            s.sendmail(user, to + cc, msg.as_string())
        print(f"✅ Correo enviado a: {len(to)} destinatarios (+{len(cc)} CC)")
        return True
    except Exception as e:
        print(f"❌ Error enviando correo: {e}")
        return False


# ================== Helpers ==================

def _equipos_problema(stats_equipos: List[Dict], threshold_pct: float) -> List[Dict]:
    """
    Filtra equipos con % alta >= threshold_pct y ordena por máximo y promedio.
    """
    candidatos = [
        e for e in (stats_equipos or [])
        if _fnum(e.get("porcentaje_latencia_alta")) >= threshold_pct
    ]
    candidatos.sort(
        key=lambda e: (_fnum(e.get("max_latencia")), _fnum(e.get("promedio_latencia"))),
        reverse=True,
    )
    return candidatos[:MAX_CRITICOS]


def _build_email_html_table(Empresa: str, horas: int, stats_equipos: List[Dict], stats_global: Dict) -> str:
    """Construye tabla completa (modo full)."""
    equipos = stats_equipos or []
    resumen = stats_global or {}

    def fmt_gl(key, val):
        if val is None:
            return ""
        try:
            if key in {"promedio_general", "max_global", "min_global"}:
                return f"{float(val):.1f}"
            if key == "porcentaje_latencia_alta":
                fval = float(val)
                return "~0%" if (0 <= fval < 0.00001) else f"{fval:.2f}%"
        except Exception:
            return val
        return val

    resumen_html = "<h3>Resumen general</h3><ul>"
    for key, label in [
        ("total_ips", "IPs"),
        ("total_mediciones", "Mediciones"),
        ("total_mediciones_validas", "Válidas (>0)"),
        ("desconexiones", "Desconexiones"),
        ("promedio_general", "Promedio (ms)"),
        ("max_global", "Máximo (ms)"),
        ("min_global", "Mínimo (ms)"),
        ("mediciones_altas", ">100 ms"),
        ("porcentaje_latencia_alta", "% alta (sobre válidas)"),
    ]:
        v = resumen.get(key)
        if v is not None:
            resumen_html += f"<li><strong>{label}:</strong> {fmt_gl(key, v)}</li>"
    resumen_html += "</ul>"

    def fmt_cell(v, key):
        if v is None:
            return ""
        try:
            if key in {"promedio_latencia", "max_latencia", "min_latencia"}:
                return f"{float(v):.1f}"
            if key == "porcentaje_latencia_alta":
                fval = float(v)
                return "~0%" if (0 <= fval < 0.00001) else f"{fval:.2f}%"
        except Exception:
            return v
        return v

    headers = [
        ("tag", "Tag"),
        ("ip", "IP"),
        ("promedio_latencia", "Promedio (ms)"),
        ("max_latencia", "Máximo (ms)"),
        ("min_latencia", "Mínimo (ms)"),
        ("latencia_100_200", "100–200 ms"),
        ("latencia_mayor_200", ">200 ms"),
        ("porcentaje_latencia_alta", "% Alta"),
        ("desconexiones", "Desconexiones"),
        ("marca", "Marca"),
        ("tipo", "Tipo"),
    ]

    rows = ""
    for e in equipos:
        tds = "".join(
            f"<td style='padding:6px 8px;border-bottom:1px solid #eee'>{fmt_cell(e.get(k), k)}</td>"
            for k, _ in headers
        )
        rows += f"<tr>{tds}</tr>"

    table_html = (
        "<h3>Estadísticas por equipo</h3>"
        "<table style='width:100%;border-collapse:collapse;font-size:13px'>"
        "<thead><tr>" +
        "".join(f"<th style='text-align:left;padding:8px;border-bottom:2px solid #ddd'>{h}</th>" for _, h in headers) +
        "</tr></thead>"
        "<tbody>" + rows + "</tbody></table>"
    )
    return resumen_html + table_html


# ================== Servicio de correo ==================

class MailService:
    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def enviar_reporte_simple(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        prompt_path: Optional[str] = None,
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> bool:
        Empresa = _cap(empresa)
        criticos = _equipos_problema(stats_equipos, threshold_pct)

        # 🔒 Sin críticos → no IA, respuesta determinista
        if not criticos:
            html = (
                "<html><body style='font-family:Arial,sans-serif'>"
                f"<h2>Reporte del turno - {Empresa}</h2>"
                "<p>Sin equipos problemáticos en el turno. Rendimiento general adecuado.</p>"
                "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
                "</body></html>"
            )
            subject = _subject_from_cfg(self.cfg, Empresa)
            return _send_html(self.cfg, subject, html)

        # IA si disponible
        intro_html = ""
        client = get_openai_client()
        if client:
            datos = {
                "empresa": Empresa,
                "horas": horas,
                "criticos": criticos,
                "umbral_pct": threshold_pct,
            }
            if prompt_path and os.path.isfile(prompt_path):
                with open(prompt_path, "r", encoding="utf-8") as f:
                    prompt = f.read()
                prompt = prompt.format(
                    empresa=Empresa,
                    datos=datos,
                    criticos=criticos,
                    umbral_pct=threshold_pct,
                )
            else:
                prompt = (
                    "Eres un asistente que redacta un reporte técnico breve en HTML para correo. "
                    "Este reporte corresponde al último turno en una faena minera. "
                    "Objetivo: mensaje simple que cualquiera pueda entender.\n"
                    "Formato: un párrafo breve y una lista (máx 5) con equipos problemáticos "
                    f"(definidos por umbral {threshold_pct}%). "
                    "Cada ítem: Tag/IP, Máximo (ms), Promedio (ms), Marca/Tipo. "
                    "No uses porcentajes ni resumen global. Usa <p> y <ul><li>. "
                    "No uses tablas ni bloques de código.\n\n"
                    f"DATOS:\n{datos}\n"
                    "Devuelve solo HTML."
                )
            intro_html = _sanitize_gpt_html(mensaje_chat_gpt(client, prompt, is_windows=False) or "")

        # Fallback determinista si IA falla
        if not intro_html:
            lines = ["<p>Se identificaron equipos con latencia elevada:</p><ul>"]
            for e in criticos:
                tag = e.get("tag") or e.get("ip") or ""
                ip = e.get("ip") or ""
                mx = _fnum(e.get("max_latencia"))
                pr = _fnum(e.get("promedio_latencia"))
                marca = e.get("marca") or ""
                tipo = e.get("tipo") or ""
                lines.append(
                    f"<li><strong>{tag}</strong> ({ip}) – Máximo: {mx:.1f} ms · Promedio: {pr:.1f} ms · {marca} {tipo}</li>"
                )
            lines.append("</ul>")
            intro_html = "\n".join(lines)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"<h2>Reporte del turno - {Empresa}</h2>"
            f"{intro_html}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )
        subject = _subject_from_cfg(self.cfg, Empresa)
        return _send_html(self.cfg, subject, html)

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        stats_global: Dict,
        prompt_path: Optional[str] = None,
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> bool:
        Empresa = _cap(empresa)
        intro_html = ""  # en full usamos IA analítica si está
        client = get_openai_client()
        if client:
            datos = {"empresa": Empresa, "umbral_pct": threshold_pct}
            if prompt_path and os.path.isfile(prompt_path):
                with open(prompt_path, "r", encoding="utf-8") as f:
                    prompt = f.read()
                prompt = prompt.format(empresa=Empresa, datos=datos)
            else:
                prompt = (
                    "Eres un asistente que redacta un reporte técnico breve en HTML para correo. "
                    "Incluye observaciones generales de latencia. "
                    f"El umbral crítico es {threshold_pct}%. "
                    "No repitas el 'Resumen general' ni inventes tablas.\n"
                )
            intro_html = _sanitize_gpt_html(mensaje_chat_gpt(client, prompt, is_windows=False) or "")

        tabla_html = _build_email_html_table(Empresa, horas, stats_equipos, stats_global)
        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"<h2>Reporte del turno - {Empresa}</h2>"
            f"{intro_html}"
            f"{tabla_html}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )
        subject = _subject_from_cfg(self.cfg, Empresa)
        return _send_html(self.cfg, subject, html)
