# src/notificaciones/services/whatsapp.py
# -*- coding: utf-8 -*-

import os
import subprocess
from typing import List, Dict, Optional

from notificaciones.core.config import load_config
from notificaciones.core.ai import get_openai_client, mensaje_chat_gpt


# ================== Parámetros globales ==================

DEFAULT_THRESHOLD_CRITICO = 10.0  # % de latencia alta para considerar equipo "crítico/problemático"
MAX_CRITICOS = 5
MAX_MSG_LEN = 1200
MUDSLIDE_BIN = "/usr/local/bin/mudslide"  # ruta hardcodeada (a prueba de cron)


# ================== Utils ==================

def _norm_float(x, default=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _resumen_global_lines(g: Dict) -> List[str]:
    """Líneas de resumen global (solo usado en modo full)."""
    lines = []
    map_keys = [
        ("total_ips", "IPs"),
        ("total_mediciones", "Mediciones"),
        ("total_mediciones_validas", "Válidas (>0)"),
        ("desconexiones", "Desconexiones"),
        ("promedio_general", "Promedio (ms)"),
        ("max_global", "Máximo (ms)"),
        ("min_global", "Mínimo (ms)"),
        ("mediciones_altas", ">100 ms"),
        ("porcentaje_latencia_alta", "% alta (sobre válidas)"),
    ]
    for key, label in map_keys:
        val = g.get(key)
        if val is None:
            continue
        try:
            if key in {"promedio_general", "max_global", "min_global"}:
                val = f"{float(val):.1f}"
            elif key == "porcentaje_latencia_alta":
                fval = float(val)
                val = "~0%" if (0 <= fval < 0.00001) else f"{fval:.2f}%"
        except Exception:
            pass
        lines.append(f"• {label}: {val}")
    return lines


# ================== Selección de críticos (umbral parametrizable) ==================

def _criticos_simple(stats_equipos: List[Dict], threshold_pct: float) -> List[Dict]:
    """
    Simple: filtra >= threshold_pct y ordena por Máximo y Promedio.
    (En simple no mostramos el % en el texto, solo ms.)
    """
    candidatos = [
        e for e in (stats_equipos or [])
        if _norm_float(e.get("porcentaje_latencia_alta")) >= float(threshold_pct or 0.0)
    ]
    candidatos.sort(
        key=lambda e: (_norm_float(e.get("max_latencia")), _norm_float(e.get("promedio_latencia"))),
        reverse=True,
    )
    return candidatos[:MAX_CRITICOS]


def _criticos_full(stats_equipos: List[Dict], threshold_pct: float) -> List[Dict]:
    """
    Full: filtra >= threshold_pct y ordena por % alta, >200ms y Máximo.
    """
    candidatos = [
        e for e in (stats_equipos or [])
        if _norm_float(e.get("porcentaje_latencia_alta")) >= float(threshold_pct or 0.0)
    ]
    candidatos.sort(
        key=lambda e: (
            _norm_float(e.get("porcentaje_latencia_alta")),
            _norm_float(e.get("latencia_mayor_200")),
            _norm_float(e.get("max_latencia")),
        ),
        reverse=True,
    )
    return candidatos[:MAX_CRITICOS]


# ================== Modo FULL ==================

def _fallback_text_full(
    empresa: str,
    stats_equipos: List[Dict],
    stats_global: Dict,
    threshold_pct: float,
) -> str:
    Empresa = (empresa or "Cliente").capitalize()
    criticos = _criticos_full(stats_equipos, threshold_pct)

    lines = [f"📊 Reporte del turno – {Empresa}"]

    if criticos:
        lines.append("⚠️ Se detectaron equipos con mayor % de latencia durante el turno:")
        for e in criticos:
            tag = e.get("tag") or ""
            ip = e.get("ip") or ""
            pct = _norm_float(e.get("porcentaje_latencia_alta"))
            pct_txt = "~0%" if (0 <= pct < 0.00001) else f"{pct:.2f}%"
            max_ms = _norm_float(e.get("max_latencia"))
            prom = _norm_float(e.get("promedio_latencia"))
            lat100_200 = int(_norm_float(e.get("latencia_100_200")))
            lat200 = int(_norm_float(e.get("latencia_mayor_200")))
            recurrencia = lat100_200 + lat200
            marca = e.get("marca") or ""
            tipo = e.get("tipo") or ""
            lines.append(
                f"🔴 {tag or ip} ({ip})\n"
                f"   • % alta: {pct_txt}\n"
                f"   • Máx: {max_ms:.1f} ms | Prom: {prom:.1f} ms\n"
                f"   • Recurrencia >100ms: {recurrencia}\n"
                f"   • Marca: {marca} {tipo}".strip()
            )
    else:
        lines.append("✅ Sin equipos críticos según el umbral definido.")

    # Resumen global (full)
    lines.append("Resumen:")
    lines.extend(_resumen_global_lines(stats_global or {}))

    text = "\n".join(lines)
    if len(text) > MAX_MSG_LEN:
        text = text[: MAX_MSG_LEN - 3] + "..."
    return text


def _message_with_ai_full(
    empresa: str,
    horas: int,
    stats_equipos: List[Dict],
    stats_global: Dict,
    prompt_path: Optional[str],
    threshold_pct: float,
) -> str:
    Empresa = (empresa or "Cliente").capitalize()
    criticos = _criticos_full(stats_equipos, threshold_pct)

    # Si no hay críticos, podemos aún mostrar resumen
    client = get_openai_client()
    datos = {
        "empresa": Empresa,
        "horas": horas,
        "criticos": criticos,
        "global": stats_global or {},
        "umbral_pct_alta": threshold_pct,
        "max_criticos": MAX_CRITICOS,
    }

    if not client:
        return _fallback_text_full(empresa, stats_equipos, stats_global, threshold_pct)

    if prompt_path and os.path.isfile(prompt_path):
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt = f.read()
        prompt = prompt.format(empresa=Empresa, datos=datos, THRESHOLD_CRITICO=threshold_pct)
    else:
        prompt = (
            "Eres un asistente que redacta un reporte técnico breve para WhatsApp (máx 1200 caracteres), "
            "en español de Chile, dirigido a supervisores de una faena minera. Sé formal.\n"
            "Este reporte es generado por Smartlink, un software de HC-GROUP para monitoreo de equipos de telecomunicaciones "
            "en faenas mineras. El reporte corresponde al último turno.\n"
            f" - Primera línea EXACTA: '📊 Reporte del turno – {Empresa}'.\n"
            f" - Considera 'crítico' si el % de latencia alta es ≥ {threshold_pct}.\n"
            " - Si hay críticos, agrega: '⚠️ Se detectaron equipos con mayor % de latencia durante el turno:' y lista hasta 5:\n"
            "     '🔴 <Tag o IP> (<IP>)\\n"
            "        • % alta: <porcentaje>\\n"
            "        • Máx: <ms> | Prom: <ms>\\n"
            "        • Recurrencia >100ms: <100-200 + >200>\\n"
            "        • Marca: <marca>'\n"
            " - Si NO hay críticos, escribe: '✅ Sin equipos críticos según el umbral definido.'\n"
            " - Al final, un bloque 'Resumen:' con viñetas de métricas globales.\n"
            " - No uses tablas, ni URLs, ni bloques de código. HC-GROUP siempre en mayúsculas.\n"
            " - Usa estrictamente el JSON, no inventes datos.\n"
            f"JSON:\n{datos}\n"
            "Devuelve solo el texto final del mensaje."
        )

    text = mensaje_chat_gpt(client, prompt, is_windows=False) or ""
    if not text.strip():
        text = _fallback_text_full(empresa, stats_equipos, stats_global, threshold_pct)
    if len(text) > MAX_MSG_LEN:
        text = text[: MAX_MSG_LEN - 3] + "..."
    return text


# ================== Modo SIMPLE ==================

def _fallback_text_simple(
    empresa: str, stats_equipos: List[Dict], threshold_pct: float
) -> str:
    Empresa = (empresa or "Cliente").capitalize()
    criticos = _criticos_simple(stats_equipos, threshold_pct)

    lines = [f"📊 Reporte del turno – {Empresa}"]
    if criticos:
        lines.append("⚠️ Equipos con latencia elevada:")
        for e in criticos:
            tag = e.get("tag") or e.get("ip") or ""
            ip = e.get("ip") or ""
            mx = _norm_float(e.get("max_latencia"))
            pr = _norm_float(e.get("promedio_latencia"))
            marca = e.get("marca") or ""
            tipo = e.get("tipo") or ""
            lines.append(
                f"🔴 {tag} ({ip})\n"
                f"   • Máx: {mx:.1f} ms | Prom: {pr:.1f} ms\n"
                f"   • Marca: {marca} {tipo}"
            )
    else:
        lines.append("✅ Sin equipos problemáticos en el turno.")
    out = "\n".join(lines)
    return out[: MAX_MSG_LEN - 3] + "..." if len(out) > MAX_MSG_LEN else out


def _message_simple_with_ai(
    empresa: str,
    horas: int,
    stats_equipos: List[Dict],
    prompt_path: Optional[str],
    threshold_pct: float,
) -> str:
    Empresa = (empresa or "Cliente").capitalize()
    criticos = _criticos_simple(stats_equipos, threshold_pct)

    # 🔒 Sin críticos => no llamamos a la IA (respuesta determinista)
    if not criticos:
        return _fallback_text_simple(empresa, stats_equipos, threshold_pct)

    client = get_openai_client()
    if not client:
        return _fallback_text_simple(empresa, stats_equipos, threshold_pct)

    datos = {
        "empresa": Empresa,
        "horas": horas,
        "criticos": criticos,
        "umbral_pct": threshold_pct,
    }

    if prompt_path and os.path.isfile(prompt_path):
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt = f.read()
        prompt = prompt.format(empresa=Empresa, criticos=criticos, umbral_pct=threshold_pct, datos=datos)
    else:
        prompt = (
            "Eres un asistente que redacta un reporte técnico breve para WhatsApp (máx 1200 caracteres), "
            "en español de Chile. Este reporte es generado por Smartlink de HC-GROUP para una faena minera "
            "y corresponde al último turno. Debe ser simple para cualquiera.\n"
            f" - Primera línea EXACTA: '📊 Reporte del turno – {Empresa}'.\n"
            f" - Considera 'problemático' si % alta ≥ {threshold_pct}.\n"
            " - Si hay problemáticos, agrega: '⚠️ Equipos con latencia elevada:' y lista hasta 5:\n"
            "     '🔴 <Tag o IP> (<IP>)\\n"
            "        • Máx: <ms> | Prom: <ms>\\n"
            "        • Marca: <marca>'\n"
            " - Si NO hay problemáticos: '✅ Sin equipos problemáticos en el turno.'\n"
            "Restricciones: NO uses porcentajes ni resumen global; usa unidades en ms; no tablas/URLs/código. "
            "HC-GROUP siempre en mayúsculas. Usa solo lo del JSON.\n"
            f"JSON:\n{datos}\n"
            "Devuelve solo el texto final del mensaje."
        )

    text = mensaje_chat_gpt(client, prompt, is_windows=False) or ""
    if not text.strip():
        text = _fallback_text_simple(empresa, stats_equipos, threshold_pct)
    if len(text) > MAX_MSG_LEN:
        text = text[: MAX_MSG_LEN - 3] + "..."
    return text


# ================== Servicio WhatsApp ==================

class WhatsAppService:
    """
    Servicio de envío por WhatsApp usando 'mudslide'.
    En config YAML:
      whatsapp:
        mudslide:
          groups:
            collahuasi: ["+56977566595", "120363027104819888@g.us"]
            test: ["+56977566595"]
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _groups(self, group_key: str) -> List[str]:
        groups = self.cfg.get("whatsapp.mudslide.groups", {})
        ids = groups.get(group_key, [])
        if not ids:
            raise ValueError(
                f"No hay destinatarios para whatsapp.mudslide.groups.{group_key}"
            )
        return ids

    def _send(self, mudslide_id: str, text: str, timeout: int = 60) -> bool:
        """
        Envía con el binario 'mudslide' instalado en /usr/local/bin (hardcodeado).
        """
        cmd = f'{MUDSLIDE_BIN} send "{mudslide_id}" "{text}"'
        try:
            res = subprocess.run(
                cmd,
                shell=True,
                check=True,
                capture_output=True,
                timeout=timeout,
                text=True,
            )
            if res.stdout:
                print(res.stdout.strip()[:400])
            print(f"✅ WhatsApp enviado a {mudslide_id}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ mudslide error -> {mudslide_id}\nCMD: {cmd}\n{(e.stderr or e.stdout)[:400]}")
        except subprocess.TimeoutExpired:
            print(f"❌ Timeout enviando a {mudslide_id}")
        except Exception as e:
            print(f"❌ Error enviando a {mudslide_id}: {e}")
        return False

    # --------- Públicos ---------

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        stats_global: Dict,
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> Dict[str, bool]:
        """
        MODO COMPLETO (se activa con --full)
        - Usa umbral `threshold_pct` para decidir críticos.
        - Incluye % alta (si viene en datos), 'Recurrencia >100ms' y 'Resumen' global.
        """
        text = _message_with_ai_full(
            empresa=empresa,
            horas=horas,
            stats_equipos=stats_equipos,
            stats_global=stats_global,
            prompt_path=prompt_path,
            threshold_pct=threshold_pct,
        )
        if len(text) > MAX_MSG_LEN:
            text = text[: MAX_MSG_LEN - 3] + "..."
        resultados: Dict[str, bool] = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados

    def enviar_reporte_simple(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> Dict[str, bool]:
        """
        MODO SIMPLE (por defecto)
        - Usa umbral `threshold_pct` para decidir problemáticos.
        - Sin % alta ni Resumen global; solo lista (máx 5) con ms.
        """
        text = _message_simple_with_ai(
            empresa=empresa,
            horas=horas,
            stats_equipos=stats_equipos,
            prompt_path=prompt_path,
            threshold_pct=threshold_pct,
        )
        if len(text) > MAX_MSG_LEN:
            text = text[: MAX_MSG_LEN - 3] + "..."
        resultados: Dict[str, bool] = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados
