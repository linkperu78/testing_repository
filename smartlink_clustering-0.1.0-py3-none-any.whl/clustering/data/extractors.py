"""
Extractores de datos para diferentes fuentes (API, CSV, JSON).
"""
import json
import pandas as pd
import requests
from pathlib import Path
from typing import Optional, Union, Any
from datetime import datetime, timedelta


class DataExtractor:
    """
    Clase base para extractores de datos.
    """
    
    def extract(self) -> pd.DataFrame:
        """Método abstracto para extraer datos."""
        raise NotImplementedError("Subclases deben implementar extract()")


class APIExtractor(DataExtractor):
    """
    Extractor de datos desde API REST.
    """
    
    def __init__(self, base_url: str, timeout: int = 30):
        """
        Inicializa el extractor de API.
        
        Args:
            base_url: URL base de la API
            timeout: Timeout para requests en segundos
        """
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
    
    def get_gps_latency_data(
        self,
        start_date: str,
        end_date: str,
        limit: int = 1000,
        offset: int = 0,
        clean_data: bool = True
    ) -> Optional[pd.DataFrame]:
        """
        Obtiene datos de GPS y latencia desde la API.
        
        Args:
            start_date: Fecha de inicio en formato ISO
            end_date: Fecha de fin en formato ISO
            limit: Límite de registros
            offset: Offset para paginación
            clean_data: Si limpiar los datos automáticamente
            
        Returns:
            DataFrame con los datos o None si falla
        """
        endpoint = "/instamesh/get_gps_latencia/"
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
            "offset": offset,
            "clean_data": str(clean_data).lower()
        }
        
        return self._make_request(endpoint, params)
    
    def get_poor_latency_data(
        self,
        start_date: str,
        end_date: str,
        limit: int = 1000,
        offset: int = 0
    ) -> Optional[pd.DataFrame]:
        """
        Obtiene datos de latencia pobre desde la API.
        
        Args:
            start_date: Fecha de inicio en formato ISO
            end_date: Fecha de fin en formato ISO
            limit: Límite de registros
            offset: Offset para paginación
            
        Returns:
            DataFrame con los datos o None si falla
        """
        endpoint = "/latencia/get_poor_latency"
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
            "offset": offset
        }
        
        return self._make_request(endpoint, params)
    
    def post_clustering_results(
        self,
        data: list[dict],
        endpoint: str = "/clustering/add_list"
    ) -> bool:
        """
        Envía resultados de clustering a la API.
        
        Args:
            data: Lista de diccionarios con los resultados
            endpoint: Endpoint donde enviar los datos
            
        Returns:
            True si se envió correctamente, False en caso contrario
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = requests.post(
                url,
                json=data,
                timeout=self.timeout,
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()
            print(f"✅ Datos enviados correctamente a {url}")
            return True
        except requests.exceptions.RequestException as e:
            print(f"❌ Error enviando datos a {url}: {e}")
            return False
    
    def _make_request(self, endpoint: str, params: dict) -> Optional[pd.DataFrame]:
        """
        Realiza una petición GET a la API y convierte a DataFrame.
        
        Args:
            endpoint: Endpoint de la API
            params: Parámetros de la petición
            
        Returns:
            DataFrame con los datos o None si falla
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = requests.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            
            data = response.json()
            
            if isinstance(data, list) and data:
                df = pd.DataFrame(data)
                print(f"✅ Datos obtenidos de {url}: {len(df)} registros")
                return df
            else:
                print(f"⚠️  No se obtuvieron datos de {url}")
                return None
                
        except requests.exceptions.RequestException as e:
            print(f"❌ Error obteniendo datos de {url}: {e}")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Error parseando JSON de {url}: {e}")
            return None


class CSVExtractor(DataExtractor):
    """
    Extractor de datos desde archivos CSV.
    """
    
    def __init__(self, folder_path: str):
        """
        Inicializa el extractor de CSV.
        
        Args:
            folder_path: Ruta de la carpeta con archivos CSV
        """
        self.folder_path = Path(folder_path)
    
    def extract_latency_inventory(
        self,
        latency_file: str,
        inventory_file: str,
        from_date: Optional[str] = None
    ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Extrae y combina datos de latencia e inventario desde CSV.
        
        Args:
            latency_file: Nombre del archivo de latencia
            inventory_file: Nombre del archivo de inventario
            from_date: Fecha mínima para filtrar (opcional)
            
        Returns:
            Tupla (merged_df, latency_df, inventory_df)
        """
        # Leer archivos CSV
        latency_path = self.folder_path / latency_file
        inventory_path = self.folder_path / inventory_file
        
        try:
            df_latency = pd.read_csv(latency_path)
            df_latency = df_latency[['ip', 'fecha', 'latency']]
            
            df_inventory = pd.read_csv(inventory_path)
            df_inventory = df_inventory[[
                'ip', 'hostname', 'modelo', 'marca', 'tipo', 'subtipo',
                'gpsLat', 'gpsLong', 'gpsAlt'
            ]]
            
            # Realizar merge
            merged_df = pd.merge(df_latency, df_inventory, on='ip', how='left')
            merged_df = merged_df.rename(columns={'fecha': 'Fecha', 'latency': 'lat'})
            
            # Convertir fecha
            merged_df['Fecha'] = pd.to_datetime(merged_df['Fecha'])
            
            # Filtrar por fecha si se especifica
            if from_date:
                from_date_dt = pd.to_datetime(from_date)
                merged_df = merged_df[merged_df['Fecha'] >= from_date_dt]
            
            # Guardar resultado
            output_path = self.folder_path / 'df_latency_inventory.csv'
            merged_df.to_csv(output_path, index=False)
            
            print(f"✅ Datos CSV combinados: {len(merged_df)} registros")
            print(f"💾 Guardado en: {output_path}")
            
            return merged_df, df_latency, df_inventory
            
        except FileNotFoundError as e:
            print(f"❌ Archivo CSV no encontrado: {e}")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
        except Exception as e:
            print(f"❌ Error procesando CSV: {e}")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    
    def extract_single_csv(self, filename: str) -> pd.DataFrame:
        """
        Extrae datos de un único archivo CSV.
        
        Args:
            filename: Nombre del archivo CSV
            
        Returns:
            DataFrame con los datos
        """
        file_path = self.folder_path / filename
        
        try:
            df = pd.read_csv(file_path)
            print(f"✅ CSV leído: {filename} - {len(df)} registros")
            return df
        except FileNotFoundError:
            print(f"❌ Archivo no encontrado: {file_path}")
            return pd.DataFrame()
        except Exception as e:
            print(f"❌ Error leyendo CSV {filename}: {e}")
            return pd.DataFrame()


class JSONExtractor(DataExtractor):
    """
    Extractor de datos desde archivos JSON.
    """
    
    def __init__(self, file_path: str):
        """
        Inicializa el extractor de JSON.
        
        Args:
            file_path: Ruta al archivo JSON
        """
        self.file_path = Path(file_path)
    
    def extract(self) -> pd.DataFrame:
        """
        Extrae datos desde un archivo JSON.
        
        Returns:
            DataFrame con los datos
        """
        try:
            with open(self.file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
            
            if isinstance(data, list):
                df = pd.DataFrame(data)
            elif isinstance(data, dict):
                # Si es un dict, intentar extraer la lista principal
                if 'data' in data:
                    df = pd.DataFrame(data['data'])
                else:
                    df = pd.DataFrame([data])
            else:
                print(f"❌ Formato JSON no soportado en {self.file_path}")
                return pd.DataFrame()
            
            print(f"✅ JSON leído: {self.file_path} - {len(df)} registros")
            return df
            
        except FileNotFoundError:
            print(f"❌ Archivo JSON no encontrado: {self.file_path}")
            return pd.DataFrame()
        except json.JSONDecodeError as e:
            print(f"❌ Error parseando JSON {self.file_path}: {e}")
            return pd.DataFrame()
        except Exception as e:
            print(f"❌ Error leyendo JSON {self.file_path}: {e}")
            return pd.DataFrame()


def get_date_range(
    current_time: datetime,
    hours_back: int = 0,
    minutes_back: int = 30,
    timezone: Optional[str] = None,
    iso_format: bool = True
) -> tuple[str, str, str]:
    """
    Genera rango de fechas para consultas de datos.
    
    Args:
        current_time: Tiempo actual de referencia
        hours_back: Horas hacia atrás
        minutes_back: Minutos hacia atrás
        timezone: Zona horaria (opcional)
        iso_format: Si retornar en formato ISO
        
    Returns:
        Tupla (fecha_inicio, fecha_fin, fecha_actual)
    """
    # Calcular fecha de inicio
    start_time = current_time - timedelta(hours=hours_back, minutes=minutes_back)
    
    # Formatear fechas
    if iso_format:
        start_str = start_time.strftime("%Y-%m-%dT%H:%M:%S")
        end_str = current_time.strftime("%Y-%m-%dT%H:%M:%S")
        current_str = current_time.strftime("%Y-%m-%dT%H:%M:%S")
    else:
        start_str = start_time.strftime("%Y-%m-%d %H:%M:%S")
        end_str = current_time.strftime("%Y-%m-%d %H:%M:%S")
        current_str = current_time.strftime("%Y-%m-%d %H:%M:%S")
    
    return start_str, end_str, current_str


if __name__ == "__main__":
    """
    Pruebas básicas de los extractores de datos.
    """
    print("🧪 Probando módulo data/extractors.py")
    print("=" * 50)
    
    # Probar generación de fechas
    print("📅 Probando generación de fechas...")
    now = datetime.now()
    start, end, current = get_date_range(now, hours_back=8, minutes_back=0)
    print(f"   Desde: {start}")
    print(f"   Hasta: {end}")
    print(f"   Actual: {current}")
    
    # Probar extractor JSON (crear archivo temporal)
    print(f"\n📄 Probando extractor JSON...")
    test_json_data = [
        {"ip": "192.168.1.1", "latencia": 120, "latitud": -33.4, "longitud": -70.6},
        {"ip": "192.168.1.2", "latencia": 200, "latitud": -33.5, "longitud": -70.7}
    ]
    
    test_json_path = Path("test_data.json")
    try:
        with open(test_json_path, 'w') as f:
            json.dump(test_json_data, f)
        
        json_extractor = JSONExtractor(str(test_json_path))
        df_json = json_extractor.extract()
        print(f"   Datos extraídos: {len(df_json)} registros")
        if not df_json.empty:
            print(f"   Columnas: {list(df_json.columns)}")
        
        # Limpiar archivo temporal
        test_json_path.unlink()
        
    except Exception as e:
        print(f"   Error en prueba JSON: {e}")
    
    # Probar extractor API (sin hacer petición real)
    print(f"\n🌐 Probando configuración de extractor API...")
    api_extractor = APIExtractor("https://api.ejemplo.com")
    print(f"   Base URL: {api_extractor.base_url}")
    print(f"   Timeout: {api_extractor.timeout}s")
    
    # Probar extractor CSV (crear directorio temporal)
    print(f"\n📊 Probando extractor CSV...")
    test_csv_data = pd.DataFrame({
        'ip': ['192.168.1.1', '192.168.1.2'],
        'fecha': ['2024-01-01', '2024-01-01'],
        'latency': [120, 200]
    })
    
    test_dir = Path("test_csv_dir")
    try:
        test_dir.mkdir(exist_ok=True)
        test_file = test_dir / "test_latency.csv"
        test_csv_data.to_csv(test_file, index=False)
        
        csv_extractor = CSVExtractor(str(test_dir))
        df_csv = csv_extractor.extract_single_csv("test_latency.csv")
        print(f"   Datos extraídos: {len(df_csv)} registros")
        
        # Limpiar archivos temporales
        test_file.unlink()
        test_dir.rmdir()
        
    except Exception as e:
        print(f"   Error en prueba CSV: {e}")
    
    print("\n✅ Todas las pruebas completadas!")