"""
Transformadores de datos para preparar datasets para clustering.
"""
import pandas as pd
import numpy as np
from typing import Optional, List, Dict, Any, Union
from datetime import datetime, timedelta


class DataTransformer:
    """
    Transformador de datos para clustering.
    """
    
    @staticmethod
    def standardize_column_names(
        df: pd.DataFrame,
        column_mapping: Optional[Dict[str, str]] = None
    ) -> pd.DataFrame:
        """
        Estandariza nombres de columnas del DataFrame.
        
        Args:
            df: DataFrame a transformar
            column_mapping: Mapeo personalizado {nombre_actual: nombre_nuevo}
                           Si es None, usa mapeo por defecto
            
        Returns:
            DataFrame con columnas renombradas
        """
        if df.empty:
            return df
        
        if column_mapping is None:
            # Mapeo por defecto basado en tu código original
            column_mapping = {
                'gpsLat': 'latitud',
                'gpsLong': 'longitud',
                'gpsAlt': 'altitud',
                'lat': 'latencia',
                'Datetime': 'fecha',
                'Fecha': 'fecha',
                'IPv4': 'ip',
                'IP': 'ip',
                'Timestamp': 'timestamp',
                'latency': 'latencia'
            }
        
        # Aplicar renombre solo para columnas que existen
        rename_dict = {old: new for old, new in column_mapping.items() if old in df.columns}
        
        if rename_dict:
            result_df = df.rename(columns=rename_dict)
            print(f"✅ Columnas renombradas: {list(rename_dict.keys())} -> {list(rename_dict.values())}")
        else:
            result_df = df.copy()
            print("ℹ️  No se encontraron columnas para renombrar")
        
        return result_df
    
    @staticmethod
    def convert_datetime_columns(
        df: pd.DataFrame,
        datetime_columns: List[str] = ['fecha', 'Fecha', 'Datetime'],
        format: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Convierte columnas a tipo datetime.
        
        Args:
            df: DataFrame a transformar
            datetime_columns: Lista de columnas a convertir
            format: Formato específico de fecha (opcional)
            
        Returns:
            DataFrame con columnas datetime convertidas
        """
        if df.empty:
            return df
        
        result_df = df.copy()
        
        for col in datetime_columns:
            if col in result_df.columns:
                try:
                    if format:
                        result_df[col] = pd.to_datetime(result_df[col], format=format)
                    else:
                        result_df[col] = pd.to_datetime(result_df[col])
                    print(f"✅ Columna {col} convertida a datetime")
                except Exception as e:
                    print(f"⚠️  Error convirtiendo {col} a datetime: {e}")
        
        return result_df
    
    @staticmethod
    def add_derived_columns(df: pd.DataFrame) -> pd.DataFrame:
        """
        Añade columnas derivadas útiles para clustering.
        
        Args:
            df: DataFrame base
            
        Returns:
            DataFrame con columnas adicionales
        """
        if df.empty:
            return df
        
        result_df = df.copy()
        
        # Añadir altitud por defecto si no existe
        if 'altitud' not in result_df.columns and 'latitud' in result_df.columns:
            result_df['altitud'] = 0
            print("✅ Columna 'altitud' añadida con valor 0")
        
        # Añadir timestamp si hay fecha
        if 'fecha' in result_df.columns and 'timestamp' not in result_df.columns:
            try:
                result_df['timestamp'] = result_df['fecha'].astype('int64') // 10**9
                print("✅ Columna 'timestamp' añadida desde fecha")
            except Exception as e:
                print(f"⚠️  Error creando timestamp: {e}")
        
        # Añadir label de latencia si no existe
        if 'latencia' in result_df.columns and 'label' not in result_df.columns:
            from ..core.preprocessing import labelerlat
            result_df['label'] = result_df['latencia'].apply(labelerlat)
            print("✅ Columna 'label' añadida basada en latencia")
        
        return result_df
    
    @staticmethod
    def filter_by_date_range(
        df: pd.DataFrame,
        date_column: str = 'fecha',
        start_date: Optional[Union[str, datetime]] = None,
        end_date: Optional[Union[str, datetime]] = None
    ) -> pd.DataFrame:
        """
        Filtra DataFrame por rango de fechas.
        
        Args:
            df: DataFrame a filtrar
            date_column: Nombre de la columna de fecha
            start_date: Fecha de inicio (inclusive)
            end_date: Fecha de fin (inclusive)
            
        Returns:
            DataFrame filtrado
        """
        if df.empty or date_column not in df.columns:
            return df
        
        result_df = df.copy()
        original_count = len(result_df)
        
        # Asegurar que la columna de fecha sea datetime
        if not pd.api.types.is_datetime64_any_dtype(result_df[date_column]):
            result_df[date_column] = pd.to_datetime(result_df[date_column])
        
        # Aplicar filtros de fecha
        if start_date:
            if isinstance(start_date, str):
                start_date = pd.to_datetime(start_date)
            result_df = result_df[result_df[date_column] >= start_date]
        
        if end_date:
            if isinstance(end_date, str):
                end_date = pd.to_datetime(end_date)
            result_df = result_df[result_df[date_column] <= end_date]
        
        filtered_count = len(result_df)
        print(f"📅 Filtrado por fechas: {original_count} -> {filtered_count} registros")
        
        return result_df
    
    @staticmethod
    def filter_by_latency_labels(
        df: pd.DataFrame,
        labels_to_keep: List[int],
        label_column: str = 'label'
    ) -> pd.DataFrame:
        """
        Filtra DataFrame por etiquetas de latencia específicas.
        
        Args:
            df: DataFrame a filtrar
            labels_to_keep: Lista de labels a mantener (ej: [3, 4] para crítico y offline)
            label_column: Nombre de la columna de labels
            
        Returns:
            DataFrame filtrado
        """
        if df.empty or label_column not in df.columns:
            return df
        
        original_count = len(df)
        result_df = df[df[label_column].isin(labels_to_keep)].copy()
        filtered_count = len(result_df)
        
        print(f"🏷️  Filtrado por labels {labels_to_keep}: {original_count} -> {filtered_count} registros")
        
        return result_df
    
    @staticmethod
    def aggregate_by_time_window(
        df: pd.DataFrame,
        time_column: str = 'fecha',
        group_columns: List[str] = ['ip'],
        window: str = '15T',  # 15 minutos
        agg_functions: Optional[Dict[str, Union[str, List[str]]]] = None
    ) -> pd.DataFrame:
        """
        Agrega datos por ventanas de tiempo.
        
        Args:
            df: DataFrame a agregar
            time_column: Columna de tiempo para agrupación
            group_columns: Columnas adicionales para agrupación
            window: Ventana de tiempo (ej: '15T', '1H')
            agg_functions: Funciones de agregación por columna
            
        Returns:
            DataFrame agregado
        """
        if df.empty or time_column not in df.columns:
            return df
        
        if agg_functions is None:
            agg_functions = {
                'latencia': ['mean', 'max', 'count'],
                'latitud': 'mean',
                'longitud': 'mean'
            }
        
        result_df = df.copy()
        
        # Asegurar que la columna de tiempo sea datetime
        if not pd.api.types.is_datetime64_any_dtype(result_df[time_column]):
            result_df[time_column] = pd.to_datetime(result_df[time_column])
        
        # Establecer índice de tiempo
        result_df = result_df.set_index(time_column)
        
        # Filtrar columnas de agregación que existen
        existing_agg = {col: func for col, func in agg_functions.items() if col in result_df.columns}
        
        # Agregar por ventanas de tiempo
        if group_columns:
            # Agrupar por columnas adicionales y tiempo
            existing_groups = [col for col in group_columns if col in result_df.columns]
            if existing_groups:
                aggregated = result_df.groupby(existing_groups).resample(window).agg(existing_agg)
            else:
                aggregated = result_df.resample(window).agg(existing_agg)
        else:
            aggregated = result_df.resample(window).agg(existing_agg)
        
        # Limpiar índices múltiples si existen
        if isinstance(aggregated.columns, pd.MultiIndex):
            aggregated.columns = ['_'.join(col).strip() for col in aggregated.columns.values]
        
        # Resetear índice
        aggregated = aggregated.reset_index()
        
        print(f"⏱️  Agregación temporal ({window}): {len(df)} -> {len(aggregated)} registros")
        
        return aggregated
    
    @staticmethod
    def create_clustering_features(
        df: pd.DataFrame,
        ip_column: str = 'ip',
        latency_column: str = 'latencia',
        time_column: str = 'fecha'
    ) -> pd.DataFrame:
        """
        Crea features adicionales útiles para clustering.
        
        Args:
            df: DataFrame base
            ip_column: Columna de identificador de equipo
            latency_column: Columna de latencia
            time_column: Columna de tiempo
            
        Returns:
            DataFrame con features adicionales
        """
        if df.empty:
            return df
        
        result_df = df.copy()
        
        # Feature: Hora del día
        if time_column in result_df.columns:
            if not pd.api.types.is_datetime64_any_dtype(result_df[time_column]):
                result_df[time_column] = pd.to_datetime(result_df[time_column])
            
            result_df['hora'] = result_df[time_column].dt.hour
            result_df['dia_semana'] = result_df[time_column].dt.dayofweek
            result_df['es_fin_semana'] = result_df['dia_semana'].isin([5, 6]).astype(int)
            print("✅ Features temporales añadidos: hora, dia_semana, es_fin_semana")
        
        # Feature: Estadísticas de latencia por IP
        if latency_column in result_df.columns and ip_column in result_df.columns:
            latency_stats = result_df.groupby(ip_column)[latency_column].agg([
                'mean', 'std', 'min', 'max', 'count'
            ]).add_prefix('latencia_')
            
            result_df = result_df.merge(latency_stats, left_on=ip_column, right_index=True, how='left')
            print("✅ Estadísticas de latencia por IP añadidas")
        
        # Feature: Categoría de latencia
        if latency_column in result_df.columns:
            result_df['categoria_latencia'] = pd.cut(
                result_df[latency_column],
                bins=[0, 50, 100, 200, 500, float('inf')],
                labels=['excelente', 'buena', 'regular', 'mala', 'critica']
            )
            print("✅ Categoría de latencia añadida")
        
        return result_df


def transform_for_clustering(
    df: pd.DataFrame,
    source_format: str = 'api',
    target_labels: Optional[List[int]] = None,
    time_filter: Optional[Dict[str, str]] = None
) -> pd.DataFrame:
    """
    Pipeline completo de transformación para clustering.
    
    Args:
        df: DataFrame de entrada
        source_format: Formato de origen ('api', 'csv', 'json')
        target_labels: Labels de latencia a mantener (ej: [3, 4])
        time_filter: Filtros de tiempo {'start': '2024-01-01', 'end': '2024-01-02'}
        
    Returns:
        DataFrame transformado y listo para clustering
    """
    if df.empty:
        print("❌ DataFrame vacío, no se puede transformar")
        return df
    
    print(f"🔄 Iniciando transformación para clustering...")
    print(f"   Formato origen: {source_format}")
    print(f"   Datos iniciales: {len(df)} filas, {len(df.columns)} columnas")
    
    transformer = DataTransformer()
    result_df = df.copy()
    
    # 1. Estandarizar nombres de columnas
    result_df = transformer.standardize_column_names(result_df)
    
    # 2. Convertir columnas datetime
    result_df = transformer.convert_datetime_columns(result_df)
    
    # 3. Añadir columnas derivadas
    result_df = transformer.add_derived_columns(result_df)
    
    # 4. Filtrar por rango de tiempo si se especifica
    if time_filter:
        result_df = transformer.filter_by_date_range(
            result_df,
            start_date=time_filter.get('start'),
            end_date=time_filter.get('end')
        )
    
    # 5. Filtrar por labels de latencia si se especifica
    if target_labels:
        result_df = transformer.filter_by_latency_labels(result_df, target_labels)
    
    # 6. Seleccionar columnas esenciales para clustering
    essential_columns = ['ip', 'fecha', 'latitud', 'longitud', 'latencia', 'label']
    if 'altitud' in result_df.columns:
        essential_columns.append('altitud')
    
    existing_essential = [col for col in essential_columns if col in result_df.columns]
    result_df = result_df[existing_essential]
    
    print(f"✅ Transformación completada:")
    print(f"   Datos finales: {len(result_df)} filas, {len(result_df.columns)} columnas")
    print(f"   Columnas: {list(result_df.columns)}")
    
    return result_df


def prepare_api_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Prepara datos específicamente desde formato API.
    
    Args:
        df: DataFrame desde API
        
    Returns:
        DataFrame preparado
    """
    return transform_for_clustering(df, source_format='api')


def prepare_csv_data(
    df: pd.DataFrame,
    from_date: Optional[str] = None
) -> pd.DataFrame:
    """
    Prepara datos específicamente desde formato CSV.
    
    Args:
        df: DataFrame desde CSV
        from_date: Fecha mínima para filtrar
        
    Returns:
        DataFrame preparado
    """
    time_filter = {'start': from_date} if from_date else None
    return transform_for_clustering(df, source_format='csv', time_filter=time_filter)


def prepare_for_visualization(
    df: pd.DataFrame,
    cluster_column: str = 'cluster'
) -> pd.DataFrame:
    """
    Prepara datos para visualización después del clustering.
    
    Args:
        df: DataFrame con resultados de clustering
        cluster_column: Nombre de la columna de clusters
        
    Returns:
        DataFrame preparado para visualización
    """
    if df.empty or cluster_column not in df.columns:
        return df
    
    result_df = df.copy()
    
    # Calcular centroides por cluster
    if 'latitud' in result_df.columns and 'longitud' in result_df.columns:
        centroids = result_df.groupby(cluster_column).agg({
            'latitud': 'mean',
            'longitud': 'mean',
            cluster_column: 'size'
        }).rename(columns={cluster_column: 'cluster_size'})
        
        # Añadir información de centroides
        result_df = result_df.merge(
            centroids, 
            left_on=cluster_column, 
            right_index=True, 
            suffixes=('', '_centroid')
        )
    
    # Añadir colores por label
    color_mapping = {
        1: 'green',    # Buena latencia
        2: 'orange',   # Warning
        3: 'red',      # Crítica
        4: 'darkred'   # Offline
    }
    
    if 'label' in result_df.columns:
        result_df['color'] = result_df['label'].map(color_mapping).fillna('gray')
    
    print(f"✅ Datos preparados para visualización: {len(result_df)} registros")
    
    return result_df


if __name__ == "__main__":
    """
    Pruebas básicas del módulo de transformadores.
    """
    print("🧪 Probando módulo data/transformers.py")
    print("=" * 50)
    
    # Crear datos de prueba que simulan diferentes formatos
    np.random.seed(42)
    n_points = 200
    
    # Simular datos de API (formato original)
    df_api = pd.DataFrame({
        'IPv4': [f'192.168.1.{i%50}' for i in range(n_points)],
        'Datetime': pd.date_range('2024-01-01', periods=n_points, freq='5T'),
        'gpsLat': np.random.normal(-33.4489, 0.01, n_points),
        'gpsLong': np.random.normal(-70.6693, 0.01, n_points),
        'lat': np.random.normal(150, 50, n_points)
    })
    
    print(f"📊 Datos de prueba API: {len(df_api)} filas")
    print(f"   Columnas originales: {list(df_api.columns)}")
    
    # Probar transformación completa
    print(f"\n🔄 Probando transformación completa...")
    df_transformed = transform_for_clustering(df_api.copy())
    
    if not df_transformed.empty:
        print(f"   Columnas finales: {list(df_transformed.columns)}")
        print(f"   Tipos de datos:")
        for col in df_transformed.columns:
            print(f"     {col}: {df_transformed[col].dtype}")
    
    # Probar transformaciones individuales
    transformer = DataTransformer()
    
    print(f"\n🏷️  Probando estandarización de columnas...")
    df_renamed = transformer.standardize_column_names(df_api.copy())
    print(f"   Columnas después de renombrar: {list(df_renamed.columns)}")
    
    print(f"\n📅 Probando conversión de datetime...")
    df_datetime = transformer.convert_datetime_columns(df_renamed.copy())
    print(f"   Tipo de columna fecha: {df_datetime['fecha'].dtype}")
    
    print(f"\n➕ Probando columnas derivadas...")
    df_derived = transformer.add_derived_columns(df_datetime.copy())
    print(f"   Nuevas columnas: {list(set(df_derived.columns) - set(df_datetime.columns))}")
    
    # Probar filtros
    print(f"\n📊 Probando filtros...")
    
    # Filtro por fechas
    df_filtered = transformer.filter_by_date_range(
        df_derived.copy(),
        start_date='2024-01-01 01:00:00',
        end_date='2024-01-01 12:00:00'
    )
    print(f"   Filtro fecha: {len(df_derived)} -> {len(df_filtered)} registros")
    
    # Filtro por labels
    if 'label' in df_derived.columns:
        df_label_filtered = transformer.filter_by_latency_labels(df_derived.copy(), [3, 4])
        print(f"   Filtro labels [3,4]: {len(df_derived)} -> {len(df_label_filtered)} registros")
    
    # Probar agregación temporal
    print(f"\n⏱️  Probando agregación temporal...")
    df_agg = transformer.aggregate_by_time_window(df_derived.copy(), window='1H')
    print(f"   Agregación horaria: {len(df_derived)} -> {len(df_agg)} registros")
    
    # Probar features adicionales
    print(f"\n🎯 Probando features adicionales...")
    df_features = transformer.create_clustering_features(df_derived.copy())
    new_features = list(set(df_features.columns) - set(df_derived.columns))
    print(f"   Nuevos features: {new_features}")
    
    # Simular clustering para probar preparación de visualización
    print(f"\n🎨 Probando preparación para visualización...")
    df_with_clusters = df_derived.copy()
    df_with_clusters['cluster'] = np.random.randint(0, 5, len(df_with_clusters))
    
    df_viz = prepare_for_visualization(df_with_clusters)
    viz_features = list(set(df_viz.columns) - set(df_with_clusters.columns))
    print(f"   Features de visualización: {viz_features}")
    
    print("\n✅ Todas las pruebas de transformadores completadas!")