"""
Validadores de datos para clustering.
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Union
from datetime import datetime


class DataValidator:
    """
    Validador de datos para clustering.
    """
    
    @staticmethod
    def validate_coordinates(
        df: pd.DataFrame,
        lat_col: str = 'latitud',
        lon_col: str = 'longitud'
    ) -> Dict[str, Any]:
        """
        Valida coordenadas GPS en un DataFrame.
        
        Args:
            df: DataFrame con coordenadas
            lat_col: Nombre de la columna de latitud
            lon_col: Nombre de la columna de longitud
            
        Returns:
            Diccionario con resultados de validación
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        if df.empty:
            results['errors'].append("DataFrame está vacío")
            results['valid'] = False
            return results
        
        # Verificar que las columnas existan
        missing_cols = []
        if lat_col not in df.columns:
            missing_cols.append(lat_col)
        if lon_col not in df.columns:
            missing_cols.append(lon_col)
        
        if missing_cols:
            results['errors'].append(f"Columnas faltantes: {missing_cols}")
            results['valid'] = False
            return results
        
        # Verificar valores nulos
        null_lat = df[lat_col].isnull().sum()
        null_lon = df[lon_col].isnull().sum()
        
        if null_lat > 0:
            results['warnings'].append(f"Valores nulos en {lat_col}: {null_lat}")
        if null_lon > 0:
            results['warnings'].append(f"Valores nulos en {lon_col}: {null_lon}")
        
        # Verificar rangos válidos
        invalid_lat = ((df[lat_col] < -90) | (df[lat_col] > 90)).sum()
        invalid_lon = ((df[lon_col] < -180) | (df[lon_col] > 180)).sum()
        
        if invalid_lat > 0:
            results['errors'].append(f"Latitudes fuera de rango [-90, 90]: {invalid_lat}")
            results['valid'] = False
        
        if invalid_lon > 0:
            results['errors'].append(f"Longitudes fuera de rango [-180, 180]: {invalid_lon}")
            results['valid'] = False
        
        # Estadísticas
        if not df[lat_col].empty and not df[lon_col].empty:
            results['statistics'] = {
                'lat_range': (df[lat_col].min(), df[lat_col].max()),
                'lon_range': (df[lon_col].min(), df[lon_col].max()),
                'lat_mean': df[lat_col].mean(),
                'lon_mean': df[lon_col].mean(),
                'total_points': len(df),
                'valid_coordinates': len(df) - max(null_lat, null_lon, invalid_lat, invalid_lon)
            }
        
        return results
    
    @staticmethod
    def validate_latency_data(
        df: pd.DataFrame,
        latency_col: str = 'latencia',
        min_latency: float = 0,
        max_latency: float = 10000
    ) -> Dict[str, Any]:
        """
        Valida datos de latencia.
        
        Args:
            df: DataFrame con datos de latencia
            latency_col: Nombre de la columna de latencia
            min_latency: Latencia mínima válida
            max_latency: Latencia máxima válida
            
        Returns:
            Diccionario con resultados de validación
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        if df.empty:
            results['errors'].append("DataFrame está vacío")
            results['valid'] = False
            return results
        
        if latency_col not in df.columns:
            results['errors'].append(f"Columna {latency_col} no encontrada")
            results['valid'] = False
            return results
        
        # Verificar valores nulos
        null_count = df[latency_col].isnull().sum()
        if null_count > 0:
            results['warnings'].append(f"Valores nulos en {latency_col}: {null_count}")
        
        # Verificar valores negativos
        negative_count = (df[latency_col] < 0).sum()
        if negative_count > 0:
            results['warnings'].append(f"Valores negativos en {latency_col}: {negative_count}")
        
        # Verificar valores fuera de rango
        out_of_range = ((df[latency_col] < min_latency) | (df[latency_col] > max_latency)).sum()
        if out_of_range > 0:
            results['warnings'].append(f"Valores fuera de rango [{min_latency}, {max_latency}]: {out_of_range}")
        
        # Estadísticas
        valid_latencies = df[latency_col].dropna()
        if not valid_latencies.empty:
            results['statistics'] = {
                'count': len(valid_latencies),
                'mean': valid_latencies.mean(),
                'median': valid_latencies.median(),
                'min': valid_latencies.min(),
                'max': valid_latencies.max(),
                'std': valid_latencies.std(),
                'zero_latency_count': (valid_latencies == 0).sum(),
                'high_latency_count': (valid_latencies > 1000).sum()
            }
        
        return results
    
    @staticmethod
    def validate_required_columns(
        df: pd.DataFrame,
        required_columns: List[str]
    ) -> Dict[str, Any]:
        """
        Valida que el DataFrame tenga las columnas requeridas.
        
        Args:
            df: DataFrame a validar
            required_columns: Lista de columnas requeridas
            
        Returns:
            Diccionario con resultados de validación
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'missing_columns': [],
            'present_columns': []
        }
        
        if df.empty:
            results['errors'].append("DataFrame está vacío")
            results['valid'] = False
            return results
        
        # Verificar columnas faltantes
        missing = [col for col in required_columns if col not in df.columns]
        present = [col for col in required_columns if col in df.columns]
        
        results['missing_columns'] = missing
        results['present_columns'] = present
        
        if missing:
            results['errors'].append(f"Columnas faltantes: {missing}")
            results['valid'] = False
        
        return results
    
    @staticmethod
    def validate_data_types(
        df: pd.DataFrame,
        expected_types: Dict[str, str]
    ) -> Dict[str, Any]:
        """
        Valida los tipos de datos de las columnas.
        
        Args:
            df: DataFrame a validar
            expected_types: Diccionario {columna: tipo_esperado}
            
        Returns:
            Diccionario con resultados de validación
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'type_mismatches': {}
        }
        
        if df.empty:
            results['errors'].append("DataFrame está vacío")
            results['valid'] = False
            return results
        
        type_mapping = {
            'int': ['int64', 'int32', 'int16', 'int8'],
            'float': ['float64', 'float32'],
            'string': ['object', 'string'],
            'datetime': ['datetime64[ns]', 'datetime64']
        }
        
        for col, expected_type in expected_types.items():
            if col not in df.columns:
                continue
            
            actual_type = str(df[col].dtype)
            expected_dtypes = type_mapping.get(expected_type, [expected_type])
            
            if actual_type not in expected_dtypes:
                results['type_mismatches'][col] = {
                    'expected': expected_type,
                    'actual': actual_type
                }
                results['warnings'].append(f"Tipo incorrecto en {col}: esperado {expected_type}, actual {actual_type}")
        
        return results
    
    @staticmethod
    def validate_duplicates(
        df: pd.DataFrame,
        subset: List[str]
    ) -> Dict[str, Any]:
        """
        Valida duplicados en el DataFrame.
        
        Args:
            df: DataFrame a validar
            subset: Columnas para identificar duplicados
            
        Returns:
            Diccionario con resultados de validación
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        if df.empty:
            results['errors'].append("DataFrame está vacío")
            results['valid'] = False
            return results
        
        # Verificar que las columnas del subset existan
        missing_cols = [col for col in subset if col not in df.columns]
        if missing_cols:
            results['errors'].append(f"Columnas para duplicados no encontradas: {missing_cols}")
            results['valid'] = False
            return results
        
        # Contar duplicados
        total_rows = len(df)
        unique_rows = len(df.drop_duplicates(subset=subset))
        duplicate_count = total_rows - unique_rows
        
        results['statistics'] = {
            'total_rows': total_rows,
            'unique_rows': unique_rows,
            'duplicate_count': duplicate_count,
            'duplicate_percentage': (duplicate_count / total_rows * 100) if total_rows > 0 else 0
        }
        
        if duplicate_count > 0:
            results['warnings'].append(f"Duplicados encontrados: {duplicate_count} ({duplicate_count/total_rows*100:.1f}%)")
        
        return results


def validate_clustering_dataframe(
    df: pd.DataFrame,
    lat_col: str = 'latitud',
    lon_col: str = 'longitud',
    latency_col: str = 'latencia',
    ip_col: str = 'ip',
    date_col: str = 'fecha'
) -> Dict[str, Any]:
    """
    Validación completa para DataFrames de clustering.
    
    Args:
        df: DataFrame a validar
        lat_col: Nombre de la columna de latitud
        lon_col: Nombre de la columna de longitud
        latency_col: Nombre de la columna de latencia
        ip_col: Nombre de la columna de IP
        date_col: Nombre de la columna de fecha
        
    Returns:
        Diccionario con resultados completos de validación
    """
    validator = DataValidator()
    
    complete_results = {
        'overall_valid': True,
        'summary': {},
        'coordinates': {},
        'latency': {},
        'required_columns': {},
        'duplicates': {}
    }
    
    # 1. Validar columnas requeridas
    required_cols = [lat_col, lon_col, latency_col, ip_col]
    if date_col:
        required_cols.append(date_col)
    
    complete_results['required_columns'] = validator.validate_required_columns(df, required_cols)
    
    if not complete_results['required_columns']['valid']:
        complete_results['overall_valid'] = False
        return complete_results
    
    # 2. Validar coordenadas
    complete_results['coordinates'] = validator.validate_coordinates(df, lat_col, lon_col)
    if not complete_results['coordinates']['valid']:
        complete_results['overall_valid'] = False
    
    # 3. Validar latencia
    complete_results['latency'] = validator.validate_latency_data(df, latency_col)
    
    # 4. Validar duplicados
    duplicate_subset = [ip_col]
    if date_col and date_col in df.columns:
        duplicate_subset.append(date_col)
    
    complete_results['duplicates'] = validator.validate_duplicates(df, duplicate_subset)
    
    # 5. Resumen general
    total_errors = (
        len(complete_results['coordinates'].get('errors', [])) +
        len(complete_results['latency'].get('errors', [])) +
        len(complete_results['required_columns'].get('errors', []))
    )
    
    total_warnings = (
        len(complete_results['coordinates'].get('warnings', [])) +
        len(complete_results['latency'].get('warnings', [])) +
        len(complete_results['duplicates'].get('warnings', []))
    )
    
    complete_results['summary'] = {
        'total_rows': len(df),
        'total_columns': len(df.columns),
        'total_errors': total_errors,
        'total_warnings': total_warnings,
        'overall_valid': complete_results['overall_valid']
    }
    
    return complete_results


def print_validation_report(validation_results: Dict[str, Any]) -> None:
    """
    Imprime un reporte de validación legible.
    
    Args:
        validation_results: Resultados de validate_clustering_dataframe
    """
    print("📋 REPORTE DE VALIDACIÓN DE DATOS")
    print("=" * 50)
    
    summary = validation_results.get('summary', {})
    print(f"📊 Resumen:")
    print(f"   Filas: {summary.get('total_rows', 0)}")
    print(f"   Columnas: {summary.get('total_columns', 0)}")
    print(f"   Errores: {summary.get('total_errors', 0)}")
    print(f"   Advertencias: {summary.get('total_warnings', 0)}")
    print(f"   Estado: {'✅ VÁLIDO' if summary.get('overall_valid', False) else '❌ INVÁLIDO'}")
    
    # Errores críticos
    all_errors = []
    for section in ['coordinates', 'latency', 'required_columns']:
        errors = validation_results.get(section, {}).get('errors', [])
        all_errors.extend(errors)
    
    if all_errors:
        print(f"\n❌ Errores críticos:")
        for error in all_errors:
            print(f"   • {error}")
    
    # Advertencias
    all_warnings = []
    for section in ['coordinates', 'latency', 'duplicates']:
        warnings = validation_results.get(section, {}).get('warnings', [])
        all_warnings.extend(warnings)
    
    if all_warnings:
        print(f"\n⚠️  Advertencias:")
        for warning in all_warnings:
            print(f"   • {warning}")
    
    # Estadísticas de coordenadas
    coord_stats = validation_results.get('coordinates', {}).get('statistics', {})
    if coord_stats:
        print(f"\n🗺️  Coordenadas:")
        print(f"   Puntos válidos: {coord_stats.get('valid_coordinates', 0)}")
        print(f"   Rango latitud: {coord_stats.get('lat_range', (0, 0))}")
        print(f"   Rango longitud: {coord_stats.get('lon_range', (0, 0))}")
        print(f"   Centro: ({coord_stats.get('lat_mean', 0):.4f}, {coord_stats.get('lon_mean', 0):.4f})")
    
    # Estadísticas de latencia
    lat_stats = validation_results.get('latency', {}).get('statistics', {})
    if lat_stats:
        print(f"\n📡 Latencia:")
        print(f"   Muestras: {lat_stats.get('count', 0)}")
        print(f"   Promedio: {lat_stats.get('mean', 0):.1f} ms")
        print(f"   Rango: {lat_stats.get('min', 0):.1f} - {lat_stats.get('max', 0):.1f} ms")
        print(f"   Latencia cero: {lat_stats.get('zero_latency_count', 0)}")
        print(f"   Latencia alta (>1000ms): {lat_stats.get('high_latency_count', 0)}")
    
    # Estadísticas de duplicados
    dup_stats = validation_results.get('duplicates', {}).get('statistics', {})
    if dup_stats:
        print(f"\n🔄 Duplicados:")
        print(f"   Duplicados: {dup_stats.get('duplicate_count', 0)} ({dup_stats.get('duplicate_percentage', 0):.1f}%)")


if __name__ == "__main__":
    """
    Pruebas básicas del módulo de validadores.
    """
    print("🧪 Probando módulo data/validators.py")
    print("=" * 50)
    
    # Crear datos de prueba con problemas típicos
    np.random.seed(42)
    
    # Datos válidos
    n_good = 100
    coords_good = np.random.normal([-33.4489, -70.6693], [0.01, 0.01], (n_good, 2))
    
    # Datos con problemas
    df_test = pd.DataFrame({
        'ip': [f'192.168.1.{i%50}' for i in range(120)],
        'fecha': pd.date_range('2024-01-01', periods=120, freq='1H'),
        'latitud': np.concatenate([
            coords_good[:, 0],  # Coordenadas válidas
            [95, -95, np.nan, 45.5],  # Problemas: fuera de rango, NaN
            np.random.normal(-33.4, 0.001, 16)  # Más válidas
        ]),
        'longitud': np.concatenate([
            coords_good[:, 1],  # Coordenadas válidas
            [-70.6, 185, -185, np.nan],  # Problemas: fuera de rango, NaN
            np.random.normal(-70.6, 0.001, 16)  # Más válidas
        ]),
        'latencia': np.concatenate([
            np.random.normal(150, 50, 100),  # Latencias normales
            [-10, 50000, 0, np.nan],  # Problemas: negativa, muy alta, cero, NaN
            np.random.normal(200, 30, 16)  # Más latencias
        ])
    })
    
    # Añadir algunos duplicados
    df_test = pd.concat([df_test, df_test.head(10)], ignore_index=True)
    
    print(f"📊 Datos de prueba creados: {len(df_test)} filas")
    
    # Ejecutar validación completa
    print(f"\n🔍 Ejecutando validación completa...")
    results = validate_clustering_dataframe(df_test)
    
    # Mostrar reporte
    print_validation_report(results)
    
    # Probar validaciones individuales
    print(f"\n🧪 Probando validaciones individuales...")
    
    validator = DataValidator()
    
    # Validar solo coordenadas
    coord_results = validator.validate_coordinates(df_test)
    print(f"   Coordenadas válidas: {coord_results['valid']}")
    
    # Validar solo latencia
    latency_results = validator.validate_latency_data(df_test)
    print(f"   Latencia válida: {latency_results['valid']}")
    
    # Validar columnas requeridas
    req_results = validator.validate_required_columns(df_test, ['ip', 'fecha', 'latitud', 'longitud', 'latencia'])
    print(f"   Columnas requeridas: {req_results['valid']}")
    
    # Validar duplicados
    dup_results = validator.validate_duplicates(df_test, ['ip', 'fecha'])
    print(f"   Duplicados detectados: {dup_results['statistics']['duplicate_count']}")
    
    print("\n✅ Todas las pruebas de validación completadas!")