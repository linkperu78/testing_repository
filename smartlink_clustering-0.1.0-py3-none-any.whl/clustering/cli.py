"""
CLI principal para smartlink-clustering.
Replica la funcionalidad del script original clustering_instamesh.py
"""
import sys
import argparse
import warnings
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
import pandas as pd
import numpy as np
from urllib.parse import urljoin

# Imports de módulos internos
from .config import load_config, get_config_value
from .core.preprocessing import preprocess_dataframe, labelerlat
from .core.algorithms import cluster_dataframe, filter_noise_clusters, adaptive_min_samples
from .core.distance import meters_to_degrees
from .data.extractors import APIExtractor, JSONExtractor, get_date_range
from .data.validators import validate_clustering_dataframe, print_validation_report
from .data.transformers import transform_for_clustering


def parse_arguments():
    """
    Parsea argumentos de línea de comandos.
    """
    parser = argparse.ArgumentParser(
        description="Script para clustering y generación de heatmaps de datos Rajant.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  smartlink-clustering --insert true --hours 8
  smartlink-clustering --source json --json_path datos.json --eps 500
  smartlink-clustering --config /ruta/configClustering.yml --min_samples 3
        """
    )
    
    # Configuración
    parser.add_argument(
        '--config', 
        type=str, 
        default='configClustering.yml',
        help='Ruta al archivo de configuración YAML (default: configClustering.yml)'
    )
    
    # Parámetros de tiempo
    parser.add_argument(
        '--current_datetime', 
        type=str, 
        help='Fecha y hora en formato YYYY-MM-DD HH:MM:SS (default: ahora)',
        default=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    parser.add_argument(
        '--hours', 
        type=int, 
        default=8, 
        help='Cantidad de horas hacia atrás para obtener los datos (default: 8)'
    )
    parser.add_argument(
        '--minutes', 
        type=int, 
        default=0, 
        help='Cantidad de minutos hacia atrás adicionales (default: 0)'
    )
    parser.add_argument(
        '--zone', 
        type=str, 
        default=None, 
        help='Zona horaria (default: sistema)'
    )
    
    # Parámetros de algoritmo
    parser.add_argument(
        '--algorithm',
        type=str,
        choices=['DBSCAN', 'KMeans'],
        default='DBSCAN',
        help='Algoritmo de clustering a usar (default: DBSCAN)'
    )
    parser.add_argument(
        '--eps', 
        type=float, 
        help='Distancia máxima en metros para DBSCAN (default: desde config)'
    )
    parser.add_argument(
        '--min_samples', 
        type=int, 
        help='Número mínimo de muestras para DBSCAN (default: calculado automáticamente)'
    )
    parser.add_argument(
        '--n_clusters',
        type=int,
        help='Número de clusters para KMeans'
    )
    
    # Fuente de datos
    parser.add_argument(
        '--source', 
        type=str, 
        choices=['api', 'json', 'csv'], 
        default='api',
        help='Fuente de datos (default: api)'
    )
    parser.add_argument(
        '--json_path', 
        type=str, 
        help='Ruta del archivo JSON (requerido si --source=json)'
    )
    parser.add_argument(
        '--api_url',
        type=str,
        help='URL base de la API (default: desde config o variable global)'
    )
    
    # Parámetros de API
    parser.add_argument(
        '--limit', 
        type=int, 
        default=1000, 
        help='Cantidad máxima de registros a obtener (default: 1000)'
    )
    parser.add_argument(
        '--offset', 
        type=int, 
        default=0, 
        help='Offset para paginación (default: 0)'
    )
    
    # Acciones
    parser.add_argument(
        '--insert', 
        type=str, 
        choices=['true', 'false'], 
        default='false',
        help='Insertar resultados en la base de datos (default: false)'
    )
    parser.add_argument(
        '--validate_only',
        action='store_true',
        help='Solo validar datos sin hacer clustering'
    )
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Mostrar información detallada'
    )
    
    # Filtros
    parser.add_argument(
        '--labels',
        type=str,
        help='Labels de latencia a procesar (ej: "3,4" para crítico y offline)'
    )
    
    return parser.parse_args()


def load_configuration(config_path: str) -> dict:
    """
    Carga la configuración desde el archivo YAML.
    """
    try:
        config = load_config(config_path)
        print(f"✅ Configuración cargada desde: {config_path}")
        return config
    except FileNotFoundError:
        print(f"❌ Archivo de configuración no encontrado: {config_path}")
        print("💡 Asegúrate de que configClustering.yml esté en el directorio actual")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error cargando configuración: {e}")
        sys.exit(1)


def get_data_from_api(args, config: dict) -> Optional[pd.DataFrame]:
    """
    Obtiene datos desde la API.
    """
    # Determinar URL de la API
    if args.api_url:
        api_url = args.api_url
    else:
        # Obtener desde configuración
        api_url = get_config_value('api.base_url', config)
        if not api_url:
            print("❌ No se encontró api.base_url en la configuración")
            print("💡 Añade 'api.base_url' al configClustering.yml o usa --api_url")
            return None
    
    # Generar rango de fechas
    try:
        current_time = datetime.strptime(args.current_datetime, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        print("❌ Formato de fecha incorrecto. Use YYYY-MM-DD HH:MM:SS")
        return None
    
    start_date, end_date, _ = get_date_range(
        current_time, 
        hours_back=args.hours, 
        minutes_back=args.minutes,
        iso_format=True
    )
    
    # Añadir margen de tiempo (como en el original)
    margen_tiempo = 175  # segundos
    start_dt = pd.to_datetime(start_date) - pd.Timedelta(seconds=margen_tiempo)
    end_dt = pd.to_datetime(end_date) + pd.Timedelta(seconds=margen_tiempo)
    
    start_date = start_dt.strftime("%Y-%m-%dT%H:%M:%S")
    end_date = end_dt.strftime("%Y-%m-%dT%H:%M:%S")
    
    print(f"📡 Obteniendo datos de API: {api_url}")
    print(f"   Rango: {start_date} a {end_date}")
    
    # Crear extractor y obtener datos
    extractor = APIExtractor(api_url)
    df = extractor.get_gps_latency_data(
        start_date=start_date,
        end_date=end_date,
        limit=args.limit,
        offset=args.offset,
        clean_data=True
    )
    
    return df


def get_data_from_json(json_path: str, args) -> Optional[pd.DataFrame]:
    """
    Obtiene datos desde archivo JSON.
    """
    if not json_path:
        print("❌ Se debe proporcionar --json_path cuando --source=json")
        return None
    
    print(f"📄 Cargando datos desde JSON: {json_path}")
    
    extractor = JSONExtractor(json_path)
    df = extractor.extract()
    
    if df.empty:
        return None
    
    # Validar columnas requeridas
    required_columns = {"ip", "fecha", "latencia", "latitud", "longitud"}
    if not required_columns.issubset(df.columns):
        print(f"❌ El JSON no contiene todas las columnas requeridas: {required_columns}")
        print(f"   Columnas encontradas: {list(df.columns)}")
        return None
    
    # Aplicar filtro de fechas si se especifica
    if hasattr(args, 'current_datetime'):
        try:
            current_time = datetime.strptime(args.current_datetime, "%Y-%m-%d %H:%M:%S")
            start_date, end_date, _ = get_date_range(
                current_time, 
                hours_back=args.hours, 
                minutes_back=args.minutes,
                iso_format=False
            )
            
            df['fecha'] = pd.to_datetime(df['fecha'])
            start_dt = pd.to_datetime(start_date)
            end_dt = pd.to_datetime(end_date)
            
            df = df[(df['fecha'] >= start_dt) & (df['fecha'] <= end_dt)]
            print(f"📅 Datos filtrados por fecha: {len(df)} registros")
            
        except Exception as e:
            print(f"⚠️  Error aplicando filtro de fechas: {e}")
    
    return df


def process_clustering(df: pd.DataFrame, args, config: dict) -> pd.DataFrame:
    """
    Procesa el clustering de los datos.
    """
    if df.empty:
        print("❌ No hay datos para procesar")
        return pd.DataFrame()
    
    print(f"🔄 Iniciando procesamiento de clustering...")
    print(f"   Datos iniciales: {len(df)} registros")
    
    # 1. Transformar datos al formato estándar
    df_transformed = transform_for_clustering(df, source_format=args.source)
    
    if df_transformed.empty:
        print("❌ No hay datos después de la transformación")
        return pd.DataFrame()
    
    # 2. Preprocesar datos (limpiar outliers, duplicados, etc.)
    df_clean = preprocess_dataframe(
        df_transformed,
        clean_outliers=True,
        outlier_method='IQR',
        validate_coords=True,
        clean_latency=True,
        remove_dupes=True
    )
    
    if df_clean.empty:
        print("❌ No hay datos después del preprocesamiento")
        return pd.DataFrame()
    
    # 3. Añadir labels de latencia si no existen
    if 'label' not in df_clean.columns and 'latencia' in df_clean.columns:
        df_clean['label'] = df_clean['latencia'].apply(labelerlat)
        print("✅ Labels de latencia añadidos")
    
    # 4. Filtrar por labels específicos si se solicita
    if args.labels:
        try:
            target_labels = [int(x.strip()) for x in args.labels.split(',')]
            df_clean = df_clean[df_clean['label'].isin(target_labels)]
            print(f"🏷️  Filtrado por labels {target_labels}: {len(df_clean)} registros")
        except ValueError:
            print(f"⚠️  Error parseando labels: {args.labels}")
    
    # 5. Separar por labels para clustering (como en el original)
    df_results = pd.DataFrame()
    
    # Procesar labels 3 y 4 (crítico y offline) como en el original
    labels_to_process = [3, 4] if not args.labels else [int(x.strip()) for x in args.labels.split(',')]
    
    for label in labels_to_process:
        df_label = df_clean[df_clean['label'] == label].copy()
        
        if df_label.empty:
            print(f"⚠️  No hay datos para label {label}")
            continue
        
        print(f"\n🎯 Procesando label {label}: {len(df_label)} registros")
        
        # Configurar parámetros de algoritmo
        eps = args.eps if args.eps else get_config_value('clustering.DBSCAN.eps', config, 800)
        
        if args.min_samples:
            min_samples = args.min_samples
        else:
            min_samples = adaptive_min_samples(df_label, method='sqrt')
        
        print(f"   Parámetros: eps={eps}m, min_samples={min_samples}")
        
        # Aplicar clustering con reintentos si no se encuentran clusters
        df_clustered = pd.DataFrame()
        current_min_samples = min_samples
        
        while df_clustered.empty and current_min_samples > 0:
            df_clustered = cluster_dataframe(
                df_label.copy(),
                algorithm=args.algorithm,
                eps=eps,
                min_samples=current_min_samples,
                use_haversine=True
            )
            
            # Filtrar ruido si es DBSCAN
            if args.algorithm == 'DBSCAN':
                df_clustered = filter_noise_clusters(df_clustered)
            
            if df_clustered.empty:
                current_min_samples -= 1
                print(f"   Reintentando con min_samples={current_min_samples}")
        
        if not df_clustered.empty:
            df_clustered['label'] = label
            df_clustered['altitud'] = 0  # Añadir altitud por defecto
            df_results = pd.concat([df_results, df_clustered], ignore_index=True)
            print(f"   ✅ Clustering exitoso: {len(df_clustered)} puntos en {df_clustered['cluster'].nunique()} clusters")
        else:
            print(f"   ❌ No se pudo hacer clustering para label {label}")
    
    return df_results


def insert_results_to_database(df: pd.DataFrame, config: dict) -> bool:
    """
    Inserta los resultados en la base de datos.
    """
    if df.empty:
        print("❌ No hay resultados para insertar")
        return False
    
    try:
        # Convertir DataFrame a lista de diccionarios
        data = df.to_dict(orient='records')
        
        # Obtener URL desde configuración
        api_url = get_config_value('api.base_url', config)
        if not api_url:
            print("❌ No se encontró api.base_url en la configuración")
            return False
        
        endpoint = get_config_value('url_clustering_list_add', config, '/clustering/add_list')
        
        # Crear extractor para enviar datos
        extractor = APIExtractor(api_url)
        success = extractor.post_clustering_results(data, endpoint)
        
        if success:
            print(f"✅ {len(data)} registros insertados en la base de datos")
        else:
            print("❌ Error insertando datos en la base de datos")
        
        return success
        
    except Exception as e:
        print(f"❌ Error insertando resultados: {e}")
        return False


def main():
    """
    Función principal del CLI.
    """
    # Suprimir warnings de pandas/sklearn si no es verbose
    warnings.filterwarnings("ignore")
    
    # Parsear argumentos
    args = parse_arguments()
    
    if args.verbose:
        print("🚀 Iniciando smartlink-clustering")
        print(f"   Configuración: {args.config}")
        print(f"   Fuente de datos: {args.source}")
        print(f"   Algoritmo: {args.algorithm}")
    
    # Cargar configuración
    config = load_configuration(args.config)
    
    # Obtener datos según la fuente
    df = None
    
    if args.source == 'api':
        df = get_data_from_api(args, config)
    elif args.source == 'json':
        df = get_data_from_json(args.json_path, args)
    else:
        print(f"❌ Fuente de datos no implementada: {args.source}")
        sys.exit(1)
    
    if df is None or df.empty:
        print("❌ No se obtuvieron datos. Terminando ejecución.")
        sys.exit(1)
    
    print(f"📊 Datos obtenidos: {len(df)} registros")
    
    # Validar datos si se solicita
    if args.validate_only:
        print("\n🔍 Validando datos...")
        validation_results = validate_clustering_dataframe(df)
        print_validation_report(validation_results)
        return
    
    # Procesar clustering
    df_results = process_clustering(df, args, config)
    
    if df_results.empty:
        print("❌ No se obtuvieron resultados de clustering")
        sys.exit(1)
    
    print(f"\n📈 Resultados finales:")
    print(f"   Total de puntos clustered: {len(df_results)}")
    print(f"   Clusters únicos: {df_results['cluster'].nunique()}")
    print(f"   Labels procesados: {sorted(df_results['label'].unique())}")
    
    # Guardar resultados localmente
    output_file = f"clustering_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    df_results.to_csv(output_file, index=False)
    print(f"💾 Resultados guardados en: {output_file}")
    
    # Insertar en base de datos si se solicita
    if args.insert.lower() == 'true':
        print(f"\n📤 Insertando resultados en base de datos...")
        success = insert_results_to_database(df_results, config)
        if not success:
            sys.exit(1)
    else:
        print(f"\nℹ️  Para insertar en BD, usa --insert true")
    
    print(f"\n✅ Proceso completado exitosamente!")


if __name__ == "__main__":
    main()