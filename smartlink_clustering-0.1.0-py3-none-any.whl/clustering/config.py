"""
Configuración simple para clustering.
Lee configClustering.yml desde cualquier ruta proporcionada.
"""
import yaml
from pathlib import Path
from typing import Optional, Any


def load_config(config_path: str = "configClustering.yml") -> dict[str, Any]:
    """
    Carga configuración desde un archivo YAML.
    
    Args:
        config_path: Ruta al archivo YAML (por defecto "configClustering.yml")
        
    Returns:
        dict: Configuración del YAML
    """
    with open(config_path, 'r', encoding='utf-8') as file:
        return yaml.safe_load(file)


def get_config_value(key: str, config: Optional[dict] = None, 
                    config_path: str = "configClustering.yml", default: Any = None) -> Any:
    """
    Obtiene un valor de configuración usando notación de puntos.
    
    Args:
        key: Clave en notación de puntos (ej: 'clustering.DBSCAN.eps')
        config: Configuración precargada (opcional)
        config_path: Ruta al archivo YAML si config es None
        default: Valor por defecto si no se encuentra la clave
        
    Returns:
        Valor de configuración
    """
    if config is None:
        config = load_config(config_path)
    
    keys = key.split('.')
    value = config
    
    try:
        for k in keys:
            value = value[k]
        return value
    except (KeyError, TypeError):
        return default


# Para uso como módulo independiente
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Leer configuración")
    parser.add_argument('--show', action='store_true', help='Mostrar configuración')
    parser.add_argument('--config', default='configClustering.yml', help='Ruta al archivo YAML')
    parser.add_argument('--get', help='Obtener valor específico (notación de puntos)')
    
    args = parser.parse_args()
    
    try:
        if args.show:
            config = load_config(args.config)
            print("Configuración:")
            print(yaml.dump(config, default_flow_style=False, allow_unicode=True))
        elif args.get:
            value = get_config_value(args.get, config_path=args.config)
            print(f"{args.get}: {value}")
        else:
            print("Uso:")
            print("  python -m clustering.config --show")
            print("  python -m clustering.config --get clustering.DBSCAN.eps")
            print("  python -m clustering.config --config /ruta/config.yml --show")
    except Exception as e:
        print(f"Error: {e}")