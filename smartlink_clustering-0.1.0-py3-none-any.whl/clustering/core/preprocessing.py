"""
Funciones de preprocesamiento para datos de clustering.
Incluye limpieza de outliers, labeling y transformaciones.
"""
from typing import Union, Optional
import pandas as pd
import numpy as np
from scipy import stats


def labelerlat(latencia: float) -> int:
    """
    Asigna una etiqueta basada en el valor de latencia.
    
    Función original que etiqueta valores de latencia en función de rangos predefinidos:
    - Si latencia > 200, retorna 3 (crítico)
    - Si latencia > 100, retorna 2 (warning)  
    - Si latencia > 0, retorna 1 (bueno)
    - En otros casos, retorna 4 (offline)
    
    Args:
        latencia: Valor de latencia en milisegundos
        
    Returns:
        Etiqueta numérica basada en el rango de latencia
    """
    return 3 if latencia > 200 else 2 if latencia > 100 else 1 if latencia > 0 else 4


def label_latency_flexible(
    latencia: float,
    thresholds: Optional[dict] = None
) -> int:
    """
    Versión flexible del labeling de latencia con umbrales configurables.
    
    Args:
        latencia: Valor de latencia en milisegundos
        thresholds: Diccionario con umbrales personalizados
                   {'good': 100, 'warning': 200, 'critical': None, 'offline': 0}
        
    Returns:
        Etiqueta numérica (1=bueno, 2=warning, 3=crítico, 4=offline)
    """
    if thresholds is None:
        thresholds = {'good': 100, 'warning': 200, 'critical': None, 'offline': 0}
    
    if latencia == thresholds['offline']:
        return 4  # Offline
    elif latencia <= thresholds['good']:
        return 1  # Bueno
    elif latencia <= thresholds['warning']:
        return 2  # Warning
    else:
        return 3  # Crítico


def remove_outliers(
    df: pd.DataFrame,
    method: str = 'IQR',
    columns: list[str] = ['longitud', 'latitud'],
    z_threshold: float = 3,
    percentile_lower: float = 1,
    percentile_upper: float = 99
) -> pd.DataFrame:
    """
    Elimina valores atípicos de un DataFrame basándose en el método especificado.
    
    Args:
        df: pandas DataFrame con datos GPS
        method: Método para detectar atípicos ('IQR', 'Z-Score', 'Percentiles')
        columns: Lista de columnas para detectar outliers
        z_threshold: Umbral de Z-score para la detección de atípicos
        percentile_lower: Percentil inferior para la detección de atípicos
        percentile_upper: Percentil superior para la detección de atípicos
        
    Returns:
        DataFrame filtrado sin valores atípicos
    """
    if df.empty:
        return df
    
    filtered_df = df.copy()
    
    if method == 'IQR':
        for col in columns:
            if col not in filtered_df.columns:
                continue
                
            Q1 = filtered_df[col].quantile(0.25)
            Q3 = filtered_df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            filtered_df = filtered_df[
                (filtered_df[col] >= lower_bound) & 
                (filtered_df[col] <= upper_bound)
            ]
    
    elif method == 'Z-Score':
        for col in columns:
            if col not in filtered_df.columns:
                continue
                
            z_scores = np.abs(stats.zscore(filtered_df[col]))
            filtered_df = filtered_df[z_scores < z_threshold]
    
    elif method == 'Percentiles':
        for col in columns:
            if col not in filtered_df.columns:
                continue
                
            lower_bound = filtered_df[col].quantile(percentile_lower / 100)
            upper_bound = filtered_df[col].quantile(percentile_upper / 100)
            
            filtered_df = filtered_df[
                (filtered_df[col] >= lower_bound) & 
                (filtered_df[col] <= upper_bound)
            ]
    
    else:
        raise ValueError("Método no reconocido. Opciones válidas: 'IQR', 'Z-Score', 'Percentiles'.")
    
    return filtered_df


def validate_gps_coordinates(
    df: pd.DataFrame,
    lat_col: str = 'latitud',
    lon_col: str = 'longitud'
) -> pd.DataFrame:
    """
    Valida y filtra coordenadas GPS que estén en rangos válidos.
    
    Args:
        df: DataFrame con coordenadas GPS
        lat_col: Nombre de la columna de latitud
        lon_col: Nombre de la columna de longitud
        
    Returns:
        DataFrame con coordenadas válidas solamente
    """
    if df.empty:
        return df
    
    valid_mask = (
        (df[lat_col] >= -90) & (df[lat_col] <= 90) &
        (df[lon_col] >= -180) & (df[lon_col] <= 180)
    )
    
    return df[valid_mask].copy()


def remove_duplicates(
    df: pd.DataFrame,
    subset: list[str] = ['ip', 'fecha'],
    keep: str = 'first'
) -> pd.DataFrame:
    """
    Elimina duplicados del DataFrame basándose en las columnas especificadas.
    
    Args:
        df: DataFrame de entrada
        subset: Lista de columnas para identificar duplicados
        keep: Qué duplicado mantener ('first', 'last', False)
        
    Returns:
        DataFrame sin duplicados
    """
    if df.empty:
        return df
    
    # Verificar que las columnas existan
    existing_cols = [col for col in subset if col in df.columns]
    if not existing_cols:
        return df
    
    return df.drop_duplicates(subset=existing_cols, keep=keep)


def clean_latency_data(
    df: pd.DataFrame,
    latency_col: str = 'latencia',
    min_latency: float = 0,
    max_latency: float = 10000
) -> pd.DataFrame:
    """
    Limpia datos de latencia eliminando valores fuera de rangos razonables.
    
    Args:
        df: DataFrame con datos de latencia
        latency_col: Nombre de la columna de latencia
        min_latency: Latencia mínima válida (ms)
        max_latency: Latencia máxima válida (ms)
        
    Returns:
        DataFrame con latencias válidas
    """
    if df.empty or latency_col not in df.columns:
        return df
    
    # Filtrar valores fuera de rango
    clean_df = df[
        (df[latency_col] >= min_latency) & 
        (df[latency_col] <= max_latency)
    ].copy()
    
    return clean_df


def round_to_nearest_quarter_hour(dt: pd.Timestamp) -> pd.Timestamp:
    """
    Redondea el tiempo a los 15 minutos más cercanos.
    
    Args:
        dt: Timestamp a redondear
        
    Returns:
        Timestamp redondeado a quarter hour
    """
    minute = dt.minute
    rounded_minute = 15 * round(minute / 15)
    
    # Si el redondeo llega a 60 minutos, ajustar la hora
    if rounded_minute == 60:
        dt = dt + pd.Timedelta(hours=1)
        rounded_minute = 0
    
    return dt.replace(minute=rounded_minute, second=0, microsecond=0)


def preprocess_dataframe(
    df: pd.DataFrame,
    clean_outliers: bool = True,
    outlier_method: str = 'IQR',
    validate_coords: bool = True,
    clean_latency: bool = True,
    remove_dupes: bool = True,
    duplicate_subset: list[str] = ['ip', 'fecha'],
    latency_col: str = 'latencia',
    lat_col: str = 'latitud',
    lon_col: str = 'longitud'
) -> pd.DataFrame:
    """
    Pipeline completo de preprocesamiento para datos de clustering.
    
    Args:
        df: DataFrame de entrada
        clean_outliers: Si remover outliers en coordenadas
        outlier_method: Método para remover outliers
        validate_coords: Si validar coordenadas GPS
        clean_latency: Si limpiar datos de latencia
        remove_dupes: Si remover duplicados
        duplicate_subset: Columnas para identificar duplicados
        latency_col: Nombre de columna de latencia
        lat_col: Nombre de columna de latitud
        lon_col: Nombre de columna de longitud
        
    Returns:
        DataFrame limpio y preprocesado
    """
    if df.empty:
        print("DataFrame vacío, no se puede preprocesar.")
        return df
    
    result_df = df.copy()
    original_rows = len(result_df)
    
    print(f"📊 Iniciando preprocesamiento con {original_rows} filas")
    
    # 1. Remover duplicados
    if remove_dupes:
        result_df = remove_duplicates(result_df, subset=duplicate_subset)
        print(f"   Duplicados removidos: {original_rows - len(result_df)} filas")
    
    # 2. Validar coordenadas GPS
    if validate_coords:
        before_coords = len(result_df)
        result_df = validate_gps_coordinates(result_df, lat_col, lon_col)
        print(f"   Coordenadas inválidas removidas: {before_coords - len(result_df)} filas")
    
    # 3. Limpiar datos de latencia
    if clean_latency and latency_col in result_df.columns:
        before_latency = len(result_df)
        result_df = clean_latency_data(result_df, latency_col)
        print(f"   Latencias inválidas removidas: {before_latency - len(result_df)} filas")
    
    # 4. Remover outliers en coordenadas
    if clean_outliers:
        before_outliers = len(result_df)
        coords_cols = [col for col in [lat_col, lon_col] if col in result_df.columns]
        if coords_cols:
            result_df = remove_outliers(result_df, method=outlier_method, columns=coords_cols)
            print(f"   Outliers removidos ({outlier_method}): {before_outliers - len(result_df)} filas")
    
    # 5. Eliminar filas con NaN en columnas críticas
    critical_cols = [col for col in [lat_col, lon_col, latency_col] if col in result_df.columns]
    if critical_cols:
        before_nan = len(result_df)
        result_df = result_df.dropna(subset=critical_cols)
        print(f"   Valores NaN removidos: {before_nan - len(result_df)} filas")
    
    final_rows = len(result_df)
    print(f"✅ Preprocesamiento completado: {final_rows} filas finales ({final_rows/original_rows*100:.1f}% del original)")
    
    return result_df


if __name__ == "__main__":
    """
    Pruebas básicas del módulo de preprocesamiento.
    """
    print("🧪 Probando módulo core/preprocessing.py")
    print("=" * 50)
    
    # Crear datos de prueba con problemas típicos
    np.random.seed(42)
    n_points = 1000
    
    # Datos base
    base_lat, base_lon = -33.4489, -70.6693
    coords = np.random.normal([base_lat, base_lon], [0.01, 0.01], (n_points, 2))
    
    df_test = pd.DataFrame({
        'ip': [f'192.168.1.{i%100}' for i in range(n_points)],
        'fecha': pd.date_range('2024-01-01', periods=n_points, freq='1min'),
        'latitud': coords[:, 0],
        'longitud': coords[:, 1],
        'latencia': np.random.normal(150, 50, n_points)
    })
    
    # Añadir problemas típicos
    # Duplicados
    df_test = pd.concat([df_test, df_test.head(50)], ignore_index=True)
    
    # Coordenadas inválidas
    df_test.loc[50:55, 'latitud'] = 95  # Latitud inválida
    df_test.loc[60:65, 'longitud'] = 200  # Longitud inválida
    
    # Latencias extremas
    df_test.loc[70:75, 'latencia'] = -10  # Latencia negativa
    df_test.loc[80:85, 'latencia'] = 50000  # Latencia muy alta
    
    # Outliers en coordenadas
    df_test.loc[90:95, 'latitud'] = base_lat + 1  # Muy lejos
    
    # Valores NaN
    df_test.loc[100:105, 'latencia'] = np.nan
    
    print(f"📊 Datos de prueba con problemas: {len(df_test)} filas")
    
    # Probar labeling de latencia
    print(f"\n🏷️  Probando labeling de latencia...")
    test_latencies = [0, 50, 150, 250]
    for lat in test_latencies:
        label_orig = labelerlat(lat)
        label_flex = label_latency_flexible(lat)
        print(f"   Latencia {lat}ms: label original={label_orig}, flexible={label_flex}")
    
    # Probar preprocesamiento completo
    print(f"\n🧹 Probando preprocesamiento completo...")
    df_clean = preprocess_dataframe(df_test.copy())
    
    # Probar métodos individuales
    print(f"\n🔍 Probando métodos de outliers...")
    methods = ['IQR', 'Z-Score', 'Percentiles']
    for method in methods:
        df_method = remove_outliers(df_test.copy(), method=method)
        reduction = (len(df_test) - len(df_method)) / len(df_test) * 100
        print(f"   {method}: {len(df_method)} filas ({reduction:.1f}% reducción)")
    
    # Estadísticas finales
    print(f"\n📈 Estadísticas:")
    print(f"   Datos originales: {len(df_test)} filas")
    print(f"   Datos limpios: {len(df_clean)} filas")
    print(f"   Reducción: {(1 - len(df_clean)/len(df_test))*100:.1f}%")
    
    if not df_clean.empty:
        print(f"   Rango latencia: {df_clean['latencia'].min():.1f} - {df_clean['latencia'].max():.1f} ms")
        print(f"   IPs únicas: {df_clean['ip'].nunique()}")
    
    print("\n✅ Todas las pruebas completadas!")