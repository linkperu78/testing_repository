"""
Funciones de cálculo de distancias y utilidades GPS para clustering.
"""
import math
from typing import Union

import numpy as np


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calcula la distancia entre dos puntos GPS usando la fórmula de Haversine.
    
    Args:
        lat1, lon1: Coordenadas del primer punto (latitud, longitud)
        lat2, lon2: Coordenadas del segundo punto (latitud, longitud)
    
    Returns:
        Distancia en metros
    """
    R = 6371000  # Radio de la Tierra en metros
    
    # Convertir grados a radianes
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)
    
    # Diferencias
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    
    # Fórmula de Haversine
    a = (math.sin(dlat / 2) ** 2 + 
         math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c


def haversine_distance_matrix(coords: np.ndarray) -> np.ndarray:
    """
    Calcula la matriz de distancias usando la fórmula de Haversine para coordenadas GPS.
    
    Args:
        coords: Array numpy de coordenadas GPS con shape (n, 2) donde cada fila es [lat, lon]
    
    Returns:
        Matriz de distancias en metros con shape (n, n)
    """
    num_coords = len(coords)
    distance_matrix = np.zeros((num_coords, num_coords))
    
    for i in range(num_coords):
        for j in range(num_coords):
            if i != j:
                lat1, lon1 = coords[i]
                lat2, lon2 = coords[j]
                distance_matrix[i, j] = haversine_distance(lat1, lon1, lat2, lon2)
    
    return distance_matrix


def meters_to_degrees(meters: float, latitude: float) -> tuple[float, float]:
    """
    Convierte una distancia en metros a grados de latitud y longitud.
    
    Args:
        meters: Distancia en metros
        latitude: Latitud de referencia para el cálculo de longitud
    
    Returns:
        Tupla (lat_degrees, lon_degrees) con los grados de latitud y longitud
    """
    # 1 grado de latitud ≈ 111 km
    lat_degrees = meters / 111000
    
    # 1 grado de longitud varía con la latitud
    lon_degrees = meters / (111000 * math.cos(math.radians(latitude)))
    
    return lat_degrees, lon_degrees


def meters_to_latlong(meters: float, latitude: float) -> tuple[float, float]:
    """
    Convierte metros a desplazamiento en grados de latitud y longitud.
    Versión más precisa que meters_to_degrees.
    
    Args:
        meters: Distancia en metros
        latitude: Latitud de referencia
    
    Returns:
        Tupla (lat_displacement, lon_displacement) con el desplazamiento en grados
    """
    # Constantes más precisas
    meters_per_degree_lat = 111320  # Aproximadamente 111.32 km por grado de latitud
    
    # Conversión de metros a grados de latitud
    lat_displacement = meters / meters_per_degree_lat
    
    # Conversión de metros a grados de longitud (dependiendo de la latitud)
    meters_per_degree_lon = meters_per_degree_lat * math.cos(math.radians(latitude))
    lon_displacement = meters / meters_per_degree_lon
    
    return lat_displacement, lon_displacement


def degrees_to_meters(lat_degrees: float, lon_degrees: float, latitude: float) -> float:
    """
    Convierte grados de latitud y longitud a metros.
    
    Args:
        lat_degrees: Diferencia en grados de latitud
        lon_degrees: Diferencia en grados de longitud
        latitude: Latitud de referencia
    
    Returns:
        Distancia en metros
    """
    # Convertir a metros
    lat_meters = lat_degrees * 111320
    lon_meters = lon_degrees * 111320 * math.cos(math.radians(latitude))
    
    # Distancia euclidiana
    return math.sqrt(lat_meters**2 + lon_meters**2)


def calculate_bounds(center_lat: float, center_lng: float, zoom: int, 
                    width: int, height: int) -> tuple[float, float, float, float]:
    """
    Calcula los límites geográficos de un mapa basado en centro, zoom y dimensiones.
    
    Args:
        center_lat: Latitud del centro
        center_lng: Longitud del centro
        zoom: Nivel de zoom del mapa
        width: Ancho en píxeles
        height: Alto en píxeles
    
    Returns:
        Tupla (north_bound, south_bound, east_bound, west_bound)
    """
    # Calcular la distancia en metros por píxel en el zoom dado
    meters_per_pixel = 156543.03392 * math.cos(math.radians(center_lat)) / (2 ** zoom)
    
    # Calcular el tamaño del mapa en metros
    map_width_meters = width * meters_per_pixel
    map_height_meters = height * meters_per_pixel
    
    # Convertir a grados
    lat_displacement, lon_displacement = meters_to_latlong(
        map_height_meters / 2, center_lat
    ), meters_to_latlong(map_width_meters / 2, center_lat)
    
    # Calcular los límites
    north_bound = center_lat + lat_displacement[0]
    south_bound = center_lat - lat_displacement[0]
    east_bound = center_lng + lon_displacement[1]
    west_bound = center_lng - lon_displacement[1]
    
    return north_bound, south_bound, east_bound, west_bound


def gps_to_pixels(lat: float, lng: float, bounds: tuple[float, float, float, float], 
                  image_width: int, image_height: int) -> tuple[int, int]:
    """
    Transforma coordenadas GPS a píxeles en una imagen.
    
    Args:
        lat: Latitud
        lng: Longitud
        bounds: Tupla (north, south, east, west) con los límites del mapa
        image_width: Ancho de la imagen en píxeles
        image_height: Alto de la imagen en píxeles
    
    Returns:
        Tupla (px, py) con las coordenadas en píxeles
    """
    north, south, east, west = bounds
    
    # Normalizar la longitud y latitud a un rango [0,1]
    x = (lng - west) / (east - west)
    y = (north - lat) / (north - south)
    
    # Convertir a píxeles
    px = int(x * image_width)
    py = int(y * image_height)
    
    return px, py


def validate_coordinates(lat: float, lon: float) -> bool:
    """
    Valida que las coordenadas GPS estén en rangos válidos.
    
    Args:
        lat: Latitud
        lon: Longitud
    
    Returns:
        True si las coordenadas son válidas
    """
    return -90 <= lat <= 90 and -180 <= lon <= 180


def calculate_centroid(coordinates: list[tuple[float, float]]) -> tuple[float, float]:
    """
    Calcula el centroide de una lista de coordenadas GPS.
    
    Args:
        coordinates: Lista de tuplas (lat, lon)
    
    Returns:
        Tupla (lat, lon) con el centroide
    """
    if not coordinates:
        raise ValueError("Lista de coordenadas vacía")
    
    total_lat = sum(coord[0] for coord in coordinates)
    total_lon = sum(coord[1] for coord in coordinates)
    
    centroid_lat = total_lat / len(coordinates)
    centroid_lon = total_lon / len(coordinates)
    
    return centroid_lat, centroid_lon


def calculate_bounding_box(coordinates: list[tuple[float, float]]) -> tuple[float, float, float, float]:
    """
    Calcula el bounding box de una lista de coordenadas.
    
    Args:
        coordinates: Lista de tuplas (lat, lon)
    
    Returns:
        Tupla (min_lat, max_lat, min_lon, max_lon)
    """
    if not coordinates:
        raise ValueError("Lista de coordenadas vacía")
    
    lats = [coord[0] for coord in coordinates]
    lons = [coord[1] for coord in coordinates]
    
    return min(lats), max(lats), min(lons), max(lons)


if __name__ == "__main__":
    """
    Pruebas básicas del módulo de distancias.
    """
    print("🧪 Probando módulo core/distance.py")
    print("=" * 50)
    
    # Coordenadas de prueba (Santiago y Valparaíso)
    santiago = (-33.4489, -70.6693)
    valparaiso = (-33.0472, -71.6127)
    
    print(f"📍 Santiago: {santiago}")
    print(f"📍 Valparaíso: {valparaiso}")
    
    # Prueba de distancia Haversine
    distance = haversine_distance(santiago[0], santiago[1], valparaiso[0], valparaiso[1])
    print(f"🗺️  Distancia Santiago-Valparaíso: {distance:.2f} metros ({distance/1000:.2f} km)")
    
    # Prueba de matriz de distancias
    coords = np.array([santiago, valparaiso, (-33.6, -70.8)])  # Agregar un tercer punto
    print(f"\n📊 Probando matriz de distancias con {len(coords)} puntos...")
    
    dist_matrix = haversine_distance_matrix(coords)
    print("Matriz de distancias (metros):")
    for i, row in enumerate(dist_matrix):
        print(f"  Punto {i}: {[f'{d:.0f}' for d in row]}")
    
    # Prueba de conversión metros a grados
    meters = 1000  # 1 km
    lat_ref = santiago[0]
    lat_deg, lon_deg = meters_to_degrees(meters, lat_ref)
    print(f"\n📐 {meters}m en latitud {lat_ref}:")
    print(f"  Latitud: {lat_deg:.6f}°")
    print(f"  Longitud: {lon_deg:.6f}°")
    
    # Prueba de validación de coordenadas
    valid_coords = [(0, 0), (45.5, -122.6), (-33.4, -70.6)]
    invalid_coords = [(91, 0), (0, 181), (-91, -181)]
    
    print(f"\n✅ Validación de coordenadas:")
    for coord in valid_coords:
        result = validate_coordinates(coord[0], coord[1])
        print(f"  {coord}: {'✓' if result else '✗'}")
    
    print(f"\n❌ Coordenadas inválidas:")
    for coord in invalid_coords:
        result = validate_coordinates(coord[0], coord[1])
        print(f"  {coord}: {'✓' if result else '✗'}")
    
    # Prueba de centroide
    test_coords = [santiago, valparaiso, (-33.6, -70.8)]
    centroid = calculate_centroid(test_coords)
    print(f"\n🎯 Centroide de {len(test_coords)} puntos: {centroid}")
    
    # Prueba de bounding box
    bbox = calculate_bounding_box(test_coords)
    print(f"📦 Bounding box: lat({bbox[0]:.3f}, {bbox[1]:.3f}), lon({bbox[2]:.3f}, {bbox[3]:.3f})")
    
    print("\n✅ Todas las pruebas completadas!")