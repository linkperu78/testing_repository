"""
Algoritmos de clustering para datos GPS y latencia.
"""
from typing import Optional, Union
import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN, KMeans

from .distance import haversine_distance_matrix, meters_to_degrees


class ClusteringAlgorithms:
    """
    Clase que encapsula diferentes algoritmos de clustering para datos GPS.
    """
    
    @staticmethod
    def dbscan_clustering(
        coordinates: np.ndarray,
        eps: float,
        min_samples: int,
        use_haversine: bool = True
    ) -> np.ndarray:
        """
        Aplica clustering DBSCAN a coordenadas GPS.
        
        Args:
            coordinates: Array numpy de coordenadas con shape (n, 2) [lat, lon]
            eps: Distancia máxima entre muestras (en metros si use_haversine=True)
            min_samples: Número mínimo de muestras para formar un cluster
            use_haversine: Si usar distancia Haversine (True) o euclidiana (False)
            
        Returns:
            Array de etiquetas de cluster (-1 para ruido)
        """
        if use_haversine:
            # Usar matriz de distancias precomputada con Haversine
            distance_matrix = haversine_distance_matrix(coordinates)
            dbscan = DBSCAN(eps=eps, min_samples=min_samples, metric='precomputed')
            return dbscan.fit_predict(distance_matrix)
        else:
            # Usar coordenadas directamente (para casos no-GPS)
            dbscan = DBSCAN(eps=eps, min_samples=min_samples)
            return dbscan.fit_predict(coordinates)
    
    @staticmethod
    def kmeans_clustering(
        coordinates: np.ndarray,
        n_clusters: int,
        random_state: int = 42
    ) -> np.ndarray:
        """
        Aplica clustering K-means a coordenadas.
        
        Args:
            coordinates: Array numpy de coordenadas con shape (n, 2)
            n_clusters: Número de clusters
            random_state: Semilla para reproducibilidad
            
        Returns:
            Array de etiquetas de cluster
        """
        kmeans = KMeans(n_clusters=n_clusters, random_state=random_state)
        return kmeans.fit_predict(coordinates)
    
    @staticmethod
    def auto_eps_from_meters(
        eps_meters: float,
        latitude_reference: float
    ) -> float:
        """
        Convierte eps de metros a grados GPS para usar con coordenadas directas.
        
        Args:
            eps_meters: Distancia eps en metros
            latitude_reference: Latitud de referencia para la conversión
            
        Returns:
            Eps en grados GPS
        """
        lat_deg, lon_deg = meters_to_degrees(eps_meters, latitude_reference)
        return max(lat_deg, lon_deg)


def cluster_dataframe(
    df: pd.DataFrame,
    lat_col: str = 'latitud',
    lon_col: str = 'longitud',
    algorithm: str = 'DBSCAN',
    eps: float = 800,
    min_samples: int = 2,
    n_clusters: Optional[int] = None,
    use_haversine: bool = True,
    cluster_col: str = 'cluster'
) -> pd.DataFrame:
    """
    Aplica clustering a un DataFrame con coordenadas GPS.
    
    Args:
        df: DataFrame con datos
        lat_col: Nombre de la columna de latitud
        lon_col: Nombre de la columna de longitud
        algorithm: Algoritmo a usar ('DBSCAN' o 'KMeans')
        eps: Parámetro eps para DBSCAN (en metros si use_haversine=True)
        min_samples: Mínimo de muestras para DBSCAN
        n_clusters: Número de clusters para KMeans
        use_haversine: Si usar distancia Haversine para DBSCAN
        cluster_col: Nombre de la columna donde guardar las etiquetas
        
    Returns:
        DataFrame con columna de clusters añadida
    """
    if df.empty:
        print("DataFrame vacío, no se puede realizar clustering.")
        return df
    
    # Extraer coordenadas
    coordinates = df[[lat_col, lon_col]].values
    
    # Aplicar algoritmo seleccionado
    if algorithm.upper() == 'DBSCAN':
        cluster_labels = ClusteringAlgorithms.dbscan_clustering(
            coordinates=coordinates,
            eps=eps,
            min_samples=min_samples,
            use_haversine=use_haversine
        )
    elif algorithm.upper() == 'KMEANS':
        if n_clusters is None:
            raise ValueError("Se debe proporcionar n_clusters para KMeans")
        cluster_labels = ClusteringAlgorithms.kmeans_clustering(
            coordinates=coordinates,
            n_clusters=n_clusters
        )
    else:
        raise ValueError(f"Algoritmo no soportado: {algorithm}")
    
    # Añadir etiquetas al DataFrame
    df_result = df.copy()
    df_result[cluster_col] = cluster_labels
    
    return df_result


def filter_noise_clusters(df: pd.DataFrame, cluster_col: str = 'cluster') -> pd.DataFrame:
    """
    Filtra los puntos de ruido (cluster = -1) de un DataFrame.
    
    Args:
        df: DataFrame con columna de clusters
        cluster_col: Nombre de la columna de clusters
        
    Returns:
        DataFrame sin puntos de ruido
    """
    return df[df[cluster_col] != -1].copy()


def get_cluster_centroids(
    df: pd.DataFrame,
    lat_col: str = 'latitud',
    lon_col: str = 'longitud',
    cluster_col: str = 'cluster'
) -> pd.DataFrame:
    """
    Calcula los centroides de cada cluster.
    
    Args:
        df: DataFrame con datos y clusters
        lat_col: Nombre de la columna de latitud
        lon_col: Nombre de la columna de longitud
        cluster_col: Nombre de la columna de clusters
        
    Returns:
        DataFrame con centroides por cluster
    """
    if df.empty:
        return pd.DataFrame()
    
    centroids = df.groupby(cluster_col).agg({
        lat_col: 'mean',
        lon_col: 'mean',
        cluster_col: 'size'  # Tamaño del cluster
    }).rename(columns={cluster_col: 'cluster_size'}).reset_index()
    
    return centroids


def get_cluster_statistics(
    df: pd.DataFrame,
    cluster_col: str = 'cluster'
) -> dict:
    """
    Obtiene estadísticas básicas de los clusters.
    
    Args:
        df: DataFrame con columna de clusters
        cluster_col: Nombre de la columna de clusters
        
    Returns:
        Diccionario con estadísticas
    """
    if df.empty:
        return {}
    
    clusters = df[cluster_col]
    
    stats = {
        'total_points': len(df),
        'total_clusters': len(clusters.unique()),
        'noise_points': len(df[clusters == -1]) if -1 in clusters.values else 0,
        'clustered_points': len(df[clusters != -1]) if -1 in clusters.values else len(df),
        'avg_cluster_size': clusters.value_counts().mean(),
        'max_cluster_size': clusters.value_counts().max(),
        'min_cluster_size': clusters.value_counts().min(),
        'cluster_sizes': clusters.value_counts().to_dict()
    }
    
    return stats


def adaptive_min_samples(
    df: pd.DataFrame,
    ip_col: str = 'ip',
    method: str = 'sqrt'
) -> int:
    """
    Calcula automáticamente min_samples para DBSCAN basado en los datos.
    
    Args:
        df: DataFrame con datos
        ip_col: Columna que identifica equipos únicos
        method: Método de cálculo ('sqrt', 'log', 'fixed')
        
    Returns:
        Valor calculado de min_samples
    """
    num_filas = len(df)
    num_equipos = df[ip_col].nunique() if ip_col in df.columns else num_filas
    
    if method == 'sqrt':
        # Método original: raíz cuadrada de promedio de puntos por equipo
        min_samples = int((num_filas / num_equipos) ** 0.5) + 1
    elif method == 'log':
        # Método logarítmico
        min_samples = max(2, int(np.log(num_filas)) + 1)
    elif method == 'fixed':
        # Método fijo
        min_samples = 2
    else:
        min_samples = 2
    
    return max(min_samples, 1)  # Mínimo 1


if __name__ == "__main__":
    """
    Pruebas básicas de los algoritmos de clustering.
    """
    print("🧪 Probando módulo core/algorithms.py")
    print("=" * 50)
    
    # Crear datos de prueba
    np.random.seed(42)
    n_points = 100
    
    # Generar coordenadas GPS de prueba (alrededor de Santiago)
    base_lat, base_lon = -33.4489, -70.6693
    coords = np.random.normal([base_lat, base_lon], [0.01, 0.01], (n_points, 2))
    
    df_test = pd.DataFrame({
        'ip': [f'192.168.1.{i%50}' for i in range(n_points)],
        'latitud': coords[:, 0],
        'longitud': coords[:, 1],
        'latencia': np.random.normal(150, 50, n_points)
    })
    
    print(f"📊 Datos de prueba: {len(df_test)} puntos, {df_test['ip'].nunique()} IPs únicas")
    
    # Probar DBSCAN
    print(f"\n🔍 Probando DBSCAN...")
    df_dbscan = cluster_dataframe(
        df_test.copy(),
        algorithm='DBSCAN',
        eps=500,  # 500 metros
        min_samples=3
    )
    
    stats_dbscan = get_cluster_statistics(df_dbscan)
    print(f"   Clusters encontrados: {stats_dbscan['total_clusters']}")
    print(f"   Puntos de ruido: {stats_dbscan['noise_points']}")
    print(f"   Puntos agrupados: {stats_dbscan['clustered_points']}")
    
    # Probar K-means
    print(f"\n🎯 Probando K-means...")
    df_kmeans = cluster_dataframe(
        df_test.copy(),
        algorithm='KMeans',
        n_clusters=5
    )
    
    stats_kmeans = get_cluster_statistics(df_kmeans)
    print(f"   Clusters: {stats_kmeans['total_clusters']}")
    print(f"   Tamaño promedio: {stats_kmeans['avg_cluster_size']:.1f}")
    
    # Probar min_samples adaptativo
    adaptive_ms = adaptive_min_samples(df_test, method='sqrt')
    print(f"\n⚙️  Min_samples adaptativo: {adaptive_ms}")
    
    # Probar centroides
    centroids = get_cluster_centroids(df_dbscan)
    print(f"\n🎯 Centroides de {len(centroids)} clusters:")
    for _, centroid in centroids.head(3).iterrows():
        print(f"   Cluster {centroid['cluster']}: ({centroid['latitud']:.4f}, {centroid['longitud']:.4f}) - {centroid['cluster_size']} puntos")
    
    print("\n✅ Todas las pruebas completadas!")