from fastapi import APIRouter, Request, HTTPException, Depends
from datetime import datetime, timedelta
from smartlink_api.connection import get_db_connection
from typing import Optional
from mariadb import IntegrityError
import json

from smartlink_api.routes.__utils__ import insert_data, fetch_data
from smartlink_api.models.rol_models import Rol

router = APIRouter()

@router.post("/add")
async def add_rol(rol: Rol):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return insert_data(conn, "lista_rol", rol)
    
@router.get("/get")
async def get_roles():
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data(conn, "lista_rol")
