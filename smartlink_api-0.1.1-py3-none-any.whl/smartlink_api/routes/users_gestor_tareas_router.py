from fastapi import APIRouter, HTTPException, Depends
from smartlink_api.connection import get_db_connection
from mariadb import IntegrityError
from smartlink_api.routes.__utils__ import insert_data, fetch_data, fetch_data_with_filter
from smartlink_api.models.users_gestor_tareas_models import User


router = APIRouter()


@router.post("/add")
async def add_usuario_gestor(usuario: User):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        return insert_data(conn=conn, table="users", model=usuario)
    

@router.get("/get")
async def get_usuarios_gestor():
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        return fetch_data(conn=conn, table="users")
    


