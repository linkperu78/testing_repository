from fastapi import APIRouter, Query, Path, Depends
from typing import Optional, List

from smartlink_api.connection import get_db_connection
from smartlink_api.routes.__utils__ import (
    insert_data,
    insert_bulk_data,
    fetch_data_with_dates,
    fetch_data_with_single_filter_and_datetime,
    fetch_data_with_filter_and_pagination,
    fetch_data_with_filter_and_pagination_with_inventory
)
from smartlink_api.models.mimosa_data_models import MimosaData

router = APIRouter()

@router.post("/add")
async def add_mimosa(mimosa_data: MimosaData):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return insert_data(conn, "mimosa_data", mimosa_data)
    
@router.post("/add_list")
async def add_mimosa_list(list_model: List[MimosaData]):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return insert_bulk_data(conn, "mimosa_data", list_model, MimosaData.model_fields.keys())
    
@router.get("/get", summary="Obtener datos de mimosa_data de la base de datos por rangos de tiempo y con paginación")
async def get_mimosa_data(
    start_date: Optional[str] = Query(None, description="Fecha de inicio de la consulta"),
    end_date: Optional[str] = Query(None, description="Fecha de fin de la consulta"),
    offset: int = Query(0, description="Número de registros a omitir"),
    limit: int = Query(1000, description="Número de registros a mostrar")
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_dates(conn, "mimosa_data", start_date, end_date, limit, offset)
    
@router.get("/get_ip/{ip}", summary="Obtener datos de mimosa_data de la base de datos por IP, por rangos de tiempo y con paginación")
async def get_mimosa_data_by_ip(
    ip: str = Path(..., description="Dirección IP a filtrar"),
    start_date: Optional[str] = Query(None, description="Fecha de inicio de la consulta"),
    end_date: Optional[str] = Query(None, description="Fecha de fin de la consulta"),
    offset: int = Query(0, description="Número de registros a omitir"),
    limit: int = Query(1000, description="Número de registros a mostrar")
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_filter_and_pagination(conn, "mimosa_data", "ip", ip, start_date, end_date, limit, offset)
    
@router.get("/get_ip/{ip}/fecha/{fecha}", summary="Obtener datos de mimosa_data de la base de datos por IP y fecha")
async def get_mimosa_data_by_ip_and_fecha(
    ip: str = Path(..., description="Dirección IP a filtrar"),
    fecha: str = Path(..., description="Fecha a filtrar"),
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_single_filter_and_datetime(conn, "mimosa_data", "ip", ip, "fecha", fecha)
    

@router.get("/get_inventario/", summary="Obtener datos de mimosa_data de la base de datos haciendo left join con inventario")
async def get_mimosa_data_inventario(
    start_date: Optional[str] = Query(None, description="Fecha de inicio de la consulta"),
    end_date: Optional[str] = Query(None, description="Fecha de fin de la consulta"),
    offset: int = Query(0, description="Número de registros a omitir"),
    limit: int = Query(1000, description="Número de registros a mostrar"),
    round_to_quarter_hour: Optional[bool] = Query(None, description="Redondear a cuartos de hora")
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_filter_and_pagination_with_inventory(
            conn, "mimosa_data", start_date, end_date, limit, offset, round_to_quarter_hour
        )