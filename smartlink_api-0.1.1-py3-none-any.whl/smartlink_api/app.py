from fastapi                        import FastAPI
from fastapi.middleware.cors        import CORSMiddleware

from smartlink_api.routes.routes                  import router
from smartlink_api.routes.usuarios_router         import router as usuarios_router
from smartlink_api.routes.eventos_router          import router as eventos_router
from smartlink_api.routes.errors_gestor_tareas_router          import router as errors_router
from smartlink_api.routes.inventario_router       import router as inventario_router
from smartlink_api.routes.rol_router              import router as roles_router
from smartlink_api.routes.marcas_router           import router as marcas_router
from smartlink_api.routes.sensores_router         import router as sensores_router
from smartlink_api.routes.tipos_router            import router as tipos_router
from smartlink_api.routes.estructura_red_router   import router as estructura_red_router
from smartlink_api.routes.snmp_conf_router        import router as snmp_conf_router
from smartlink_api.routes.ubicacion_gps_router    import router as ubicacion_gps_router
from smartlink_api.routes.rajant_data_router      import router as rajant_data_router
from smartlink_api.routes.latencia_router         import router as latencia_router
from smartlink_api.routes.cambium_data_router     import router as cambium_data
from smartlink_api.routes.instamesh_router        import router as instamesh_router
from smartlink_api.routes.wired_router            import router as wired_router
from smartlink_api.routes.wireless_router         import router as wireless_router
from smartlink_api.routes.LTE_data_router         import router as LTE_data_router
from smartlink_api.routes.servidor_router         import router as servidor_router
from smartlink_api.routes.clustering_data_router  import router as clustering_data_router
from smartlink_api.routes.predicciones_router     import router as predicciones_router
from smartlink_api.routes.alertas_urgentes_router import router as alertas_urgentes_router
from smartlink_api.routes.drive_data              import router as drive_data
from smartlink_api.routes.mimosa_data_router      import router as mimosa_data_router
from smartlink_api.routes.mantenimientodb_router  import router as mantenimientodb_router
from smartlink_api.routes.rol_gestor_tareas_router import router as rol_gestor_tareas_router
from smartlink_api.routes.tasks_gestor_tareas_router import router as tasks_gestor_tareas_router
from smartlink_api.routes.users_gestor_tareas_router import router as users_gestor_tareas_router
from smartlink_api.routes.api_info_router import router as api_info_router


app = FastAPI()

app.add_middleware(
   CORSMiddleware,
    allow_origins=["*"],  # Permitir todas las solicitudes (no seguro en producción)
    allow_credentials=True,
    allow_methods=["*"],  # Permitir todos los métodos (GET, POST, PUT, DELETE, etc.)
    allow_headers=["*"],  # Permitir todos los encabezados
)

# Rutas de la aplicacion Websockets
app.include_router(alertas_urgentes_router, prefix="/alertas", tags=["Alertas en Tiempo Real"])

# Rutas de la aplicación HTTP
app.include_router(router)
app.include_router(usuarios_router, prefix="/usuarios", tags=["Usuarios"])
app.include_router(roles_router, prefix="/roles", tags=["Roles"])
app.include_router(marcas_router, prefix="/marcas", tags=["Marcas"])
app.include_router(tipos_router, prefix="/tipos", tags=["Tipos"])
app.include_router(LTE_data_router, prefix="/LTE_data", tags=["Datos LTE"])
app.include_router(snmp_conf_router, prefix="/snmp_conf", tags=["Configuración SNMP"])
app.include_router(inventario_router, prefix="/inventario", tags=["Inventario"])
app.include_router(estructura_red_router, prefix="/estructura", tags=["Estructura de red"])
app.include_router(ubicacion_gps_router, prefix="/ubicacion_gps", tags=["Ubicación GPS"])
app.include_router(latencia_router, prefix="/latencia", tags=["Latencia"])
app.include_router(cambium_data, prefix="/cambium_data", tags=["Datos Cambium"])
app.include_router(sensores_router, prefix="/sensores", tags=["Sensores"])
app.include_router(eventos_router, prefix="/eventos", tags=["Eventos"])
app.include_router(rajant_data_router, prefix="/rajant_data", tags=["Datos Rajant"])
app.include_router(instamesh_router, prefix="/instamesh", tags=["Instamesh"])
app.include_router(wired_router, prefix="/wired", tags=["Wired"])
app.include_router(wireless_router, prefix="/wireless", tags=["Wireless"])
app.include_router(servidor_router, prefix="/servidor", tags=["Servidor"])
app.include_router(clustering_data_router, prefix="/clustering", tags=["Clustering"])
app.include_router(predicciones_router, prefix="/predicciones", tags=["Predicciones"])
app.include_router(drive_data, prefix="/drive", tags=["Heatmap GPS"])
app.include_router(mimosa_data_router, prefix="/mimosa_data", tags=["Datos Mimosa"])
app.include_router(mantenimientodb_router, prefix="/mantenimientodb", tags=["Mantenimiento DB"])
app.include_router(errors_router, prefix="/errors_gestor", tags=["Errors"])
app.include_router(rol_gestor_tareas_router, prefix="/rol_gestor", tags=["Rol Tasks"])
app.include_router(tasks_gestor_tareas_router, prefix="/tasks_gestor", tags=["Gestor de Tareas"])
app.include_router(users_gestor_tareas_router, prefix="/users_gestor", tags=["Gestor de Usuarios"])
app.include_router(api_info_router, prefix="/api_info", tags=["Información de la API"])


# Listar todas las rutas de la aplicacion
for route in app.routes:
    if hasattr(route, 'methods'):  # Solo rutas HTTP tienen 'methods'
        print(f"{route.path} - {route.methods}")
    else:
        print(f"{route.path} - WebSocket")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, debug=True)
