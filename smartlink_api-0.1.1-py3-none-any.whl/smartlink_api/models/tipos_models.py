from pydantic import BaseModel
from typing import Dict

class Tipo(BaseModel):
    tipo: str
