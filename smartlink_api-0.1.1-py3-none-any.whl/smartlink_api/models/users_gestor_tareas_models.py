from pydantic import BaseModel
from typing import Dict

class User(BaseModel):
    name: str
    role: int
    email: str
    password: str
    status: int
