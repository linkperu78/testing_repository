from pydantic import BaseModel
from typing import Dict

class Evento(BaseModel):
    ip: str
    fecha: str
    codigo: str
    estado: str
    problema: str
    recurrencia: int
    urgente: bool
    detalle: Dict


