#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comando smartlink-whatsapp para envio de alertas por WhatsApp.
Equivalente al script enviar_eventos_mudslice.py original.
"""

import argparse
import sys
from typing import Optional

from eventos.services.whatsapp import get_whatsapp_service
from eventos.core.config import get_config_manager
from eventos.utils.message_utils import generar_destinatario

def crear_parser() -> argparse.ArgumentParser:
    """
    Crea el parser de argumentos para el comando de WhatsApp.
    
    Returns:
        ArgumentParser: Parser configurado
    """
    parser = argparse.ArgumentParser(
        description='Envio de alertas y alarmas por WhatsApp via MudSlice',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  smartlink-whatsapp send --empresa collahuasi                           # Envio basico
  smartlink-whatsapp send --empresa collahuasi --mudslice-id id_test     # Grupo especifico
  smartlink-whatsapp send --empresa collahuasi --hours-ago 8            # Ultimas 8 horas
  smartlink-whatsapp send --config /path/to/config.yml --empresa test   # Config personalizada
  smartlink-whatsapp list-groups                                        # Listar grupos disponibles
  smartlink-whatsapp test --mudslice-id "+56977566595"                  # Mensaje de prueba
        """
    )
    
    # Subcomandos
    subparsers = parser.add_subparsers(dest='comando', help='Comandos disponibles')
    
    # Comando send (principal)
    send_parser = subparsers.add_parser(
        'send', 
        help='Enviar alertas por WhatsApp'
    )
    
    send_parser.add_argument(
        '--empresa', 
        type=str, 
        required=True,
        help='Nombre de la empresa para las alertas (requerido)'
    )
    
    send_parser.add_argument(
        '--mudslice-id', 
        type=str, 
        default='id_collahuasi',
        help='ID del grupo MudSlice en la configuracion. Default: id_collahuasi'
    )
    
    send_parser.add_argument(
        '--num-messages', 
        type=int, 
        default=10,
        help='Numero maximo de mensajes por tipo de alerta. Default: 10'
    )
    
    send_parser.add_argument(
        '--hours-ago', 
        type=int, 
        default=1,
        help='Numero de horas atras para buscar alertas. Default: 1'
    )
    
    send_parser.add_argument(
        '--minutes-ago', 
        type=int, 
        default=5,
        help='Numero de minutos atras para buscar alertas. Default: 5'
    )
    
    send_parser.add_argument(
        '--timeout', 
        type=int, 
        default=60,
        help='Timeout en segundos para cada envio. Default: 60'
    )
    
    send_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    send_parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Mostrar informacion detallada'
    )
    
    send_parser.add_argument(
        '--stats-mode',
        action='store_true',
        help='Usar modo estadisticas (12h) en lugar de alertas puntuales'
    )
    
    send_parser.add_argument(
        '--num-equipos', 
        type=int, 
        default=10,
        help='Numero maximo de equipos a incluir en estadisticas. Default: 10'
    )
    
    # Comando list-groups
    list_parser = subparsers.add_parser(
        'list-groups', 
        help='Listar grupos de WhatsApp configurados'
    )
    
    list_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    # Comando test
    test_parser = subparsers.add_parser(
        'test', 
        help='Enviar mensaje de prueba'
    )
    
    test_parser.add_argument(
        '--mudslice-id', 
        type=str, 
        required=True,
        help='ID directo del destinatario (numero o grupo)'
    )
    
    test_parser.add_argument(
        '--mensaje', 
        type=str, 
        default='Mensaje de prueba desde smartlink-whatsapp',
        help='Mensaje personalizado de prueba'
    )
    
    test_parser.add_argument(
        '--timeout', 
        type=int, 
        default=30,
        help='Timeout en segundos. Default: 30'
    )
    
    test_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    # Comando show-stats
    stats_parser = subparsers.add_parser(
        'show-stats', 
        help='Mostrar estadisticas de la ultima ejecucion'
    )
    
    stats_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    return parser


def comando_send(args) -> int:
    """
    Ejecuta el comando de envio de alertas por WhatsApp.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida (0 = exito, 1 = error)
    """
    try:
        # Inicializar config manager si se especifica archivo personalizado
        if args.config:
            get_config_manager(args.config)
        
        # Obtener servicio de WhatsApp
        whatsapp_service = get_whatsapp_service()
        
        if args.verbose:
            print("📱 Parametros de envio WhatsApp:")
            print(f"  - Empresa: {args.empresa}")
            print(f"  - Grupo MudSlice: {args.mudslice_id}")
            print(f"  - Horas atras: {args.hours_ago}")
            print(f"  - Max equipos: {args.num_equipos}")
            print(f"  - Timeout: {args.timeout}s")
            print(f"  - Dry run: {args.dry_run}")
            if args.config:
                print(f"  - Config personalizado: {args.config}")
            print()
        
        # Validar que el grupo existe
        config_manager = get_config_manager()
        mudslice_ids = config_manager.get_mudslice_ids(args.mudslice_id)
        
        if not mudslice_ids:
            print(f"❌ Grupo MudSlice '{args.mudslice_id}' no encontrado en configuracion")
            print("💡 Usa 'smartlink-whatsapp list-groups' para ver grupos disponibles")
            return 1
        
        if args.dry_run:
            print("🧪 MODO DRY RUN - No se enviaran mensajes reales")
            print(f"📋 Se enviarian mensajes a {len(mudslice_ids)} destinatarios:")
            for mudslice_id in mudslice_ids:
                destinatario = generar_destinatario(mudslice_id)
                print(f"  - {mudslice_id} ({destinatario})")
            print()
            
            # Obtener estadisticas para mostrar lo que se enviaria
            stats_equipos, stats_global = whatsapp_service.obtener_estadisticas_latencia(args.hours_ago)
            
            print(f"📊 Estadisticas encontradas:")
            print(f"  - Equipos con datos: {len(stats_equipos)}")
            if stats_global:
                print(f"  - Total mediciones: {stats_global.get('total_mediciones', 0)}")
                print(f"  - Promedio global: {stats_global.get('promedio_general', 0):.1f}ms")
            
            if stats_equipos or stats_global:
                print("✅ Se generaria y enviaria mensaje con estadisticas")
            else:
                print("ℹ️ No hay estadisticas para enviar")
            
            return 0
        
        # Ejecutar envio real
        print(f"📤 Enviando estadisticas a grupo '{args.mudslice_id}' para {args.empresa}...")
        
        resultados = whatsapp_service.enviar_estadisticas_a_lista_mudslice(
            mudslice_id_key=args.mudslice_id,
            empresa=args.empresa,
            hours_ago=args.hours_ago,
            num_equipos=args.num_equipos,
            timeout=args.timeout
        )
        
        # Mostrar resultados
        if resultados:
            estadisticas = whatsapp_service.obtener_estadisticas_envio_stats(resultados)
            
            print("\n" + "="*60)
            print("📊 RESUMEN DE ENVIO WHATSAPP - ESTADISTICAS")
            print("="*60)
            print(f"👥 Grupos procesados: {estadisticas['total_grupos']}")
            print(f"📨 Grupos exitosos: {estadisticas['grupos_exitosos']}")
            print(f"❌ Grupos fallidos: {estadisticas['grupos_fallidos']}")
            print(f"📈 Tasa de exito: {estadisticas['tasa_exito']:.1f}%")
            
            if args.verbose:
                print(f"\n📋 Detalle por grupo:")
                for grupo_id, exito in resultados.items():
                    destinatario = generar_destinatario(grupo_id)
                    estado = "✅" if exito else "❌"
                    print(f"  🔸 {grupo_id} ({destinatario}): {estado}")
            
            print("="*60)
            
            # Determinar codigo de salida
            if estadisticas['grupos_fallidos'] == 0:
                print("🎉 Todas las estadisticas enviadas exitosamente")
                return 0
            elif estadisticas['grupos_exitosos'] > 0:
                print("⚠️ Envio parcialmente exitoso")
                return 0
            else:
                print("💥 Fallo completo en el envio")
                return 1
        else:
            print("❌ No se pudieron enviar mensajes")
            return 1
        
    except Exception as e:
        print(f"❌ Error en envio WhatsApp: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


def comando_list_groups(args) -> int:
    """
    Lista los grupos de WhatsApp configurados.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager
        config_manager = get_config_manager(args.config)
        whatsapp_config = config_manager.get_whatsapp_config()
        mudslice_groups = whatsapp_config.get("mudslice", {})
        
        print("📱 GRUPOS WHATSAPP CONFIGURADOS")
        print("="*50)
        
        if not mudslice_groups:
            print("❌ No hay grupos configurados")
            return 1
        
        for group_id, destinatarios in mudslice_groups.items():
            print(f"\n🔸 {group_id}:")
            print(f"  📋 Destinatarios ({len(destinatarios)}):")
            for dest in destinatarios:
                nombre = generar_destinatario(dest)
                print(f"    - {dest} ({nombre})")
        
        print("="*50)
        print(f"💡 Usa --mudslice-id con cualquiera de estos IDs")
        
        return 0
        
    except Exception as e:
        print(f"❌ Error listando grupos: {e}")
        return 1


def comando_test(args) -> int:
    """
    Envia un mensaje de prueba.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager si se especifica
        if args.config:
            get_config_manager(args.config)
        
        # Obtener servicio
        whatsapp_service = get_whatsapp_service()
        
        print(f"🧪 Enviando mensaje de prueba a: {args.mudslice_id}")
        print(f"📝 Mensaje: {args.mensaje}")
        
        # Enviar mensaje
        exito = whatsapp_service.enviar_whatsapp_mudslice(
            mudslice_id=args.mudslice_id,
            mensaje=args.mensaje,
            timeout=args.timeout
        )
        
        if exito:
            destinatario = generar_destinatario(args.mudslice_id)
            print(f"✅ Mensaje de prueba enviado exitosamente a {destinatario}")
            return 0
        else:
            print(f"❌ Fallo el envio del mensaje de prueba")
            return 1
        
    except Exception as e:
        print(f"❌ Error en mensaje de prueba: {e}")
        return 1


def comando_show_stats(args) -> int:
    """
    Muestra estadisticas generales.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager
        config_manager = get_config_manager(args.config)
        whatsapp_config = config_manager.get_whatsapp_config()
        
        print("📊 ESTADISTICAS WHATSAPP")
        print("="*40)
        
        mudslice_groups = whatsapp_config.get("mudslice", {})
        total_grupos = len(mudslice_groups)
        total_destinatarios = sum(len(dests) for dests in mudslice_groups.values())
        
        print(f"👥 Grupos configurados: {total_grupos}")
        print(f"📱 Total destinatarios: {total_destinatarios}")
        
        if total_grupos > 0:
            print(f"📊 Promedio destinatarios por grupo: {total_destinatarios/total_grupos:.1f}")
        
        print("="*40)
        
        return 0
        
    except Exception as e:
        print(f"❌ Error mostrando estadisticas: {e}")
        return 1


def main():
    """Funcion principal del comando smartlink-whatsapp."""
    parser = crear_parser()
    args = parser.parse_args()
    
    # Si no se especifica comando, mostrar ayuda
    if not args.comando:
        parser.print_help()
        return 0
    
    # Ejecutar comando correspondiente
    if args.comando == 'send':
        return comando_send(args)
    elif args.comando == 'list-groups':
        return comando_list_groups(args)
    elif args.comando == 'test':
        return comando_test(args)
    elif args.comando == 'show-stats':
        return comando_show_stats(args)
    else:
        print(f"❌ Comando desconocido: {args.comando}")
        return 1


if __name__ == "__main__":
    sys.exit(main())