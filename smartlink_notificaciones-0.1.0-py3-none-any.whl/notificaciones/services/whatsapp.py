# src/notificaciones/services/whatsapp.py
# -*- coding: utf-8 -*-

import os
import subprocess
from typing import List, Dict, Optional


from notificaciones.core.config import load_config


def _build_whatsapp_text(
    intro: str,
    empresa: str,
    horas: int,
    stats_equipos: List[Dict],
    stats_global: Dict,
    max_len: int = 3500,
) -> str:
    """
    Construye un texto conciso para WhatsApp:
    - Cabecera (intro + periodo)
    - Resumen global (si viene)
    - Top 10 equipos con peor score (porcentaje_latencia_alta, >200ms, prom)
    """
    lines: List[str] = []
    lines.append(f"{intro}")
    lines.append(f"Periodo: últimas {horas}h")

    if stats_global:
        pg = stats_global.get("promedio_general")
        total = stats_global.get("total_mediciones")
        pct = stats_global.get("porcentaje_latencia_alta")
        mx = stats_global.get("max_global")

        lines.append("📊 Resumen:")
        if total is not None:
            lines.append(f"• Mediciones: {total}")
        if pg is not None:
            try:
                lines.append(f"• Prom. global: {float(pg):.1f} ms")
            except Exception:
                lines.append(f"• Prom. global: {pg}")
        if pct is not None:
            try:
                lines.append(f"• % latencia alta: {float(pct):.2f}")
            except Exception:
                lines.append(f"• % latencia alta: {pct}")
        if mx is not None:
            lines.append(f"• Máxima: {mx}")

    if stats_equipos:
        lines.append("\nEquipos destacados:")
        # Ordenamos por (porcentaje_latencia_alta, latencia_mayor_200, promedio_latencia)
        def score(e: Dict) -> tuple:
            def f(x):
                try:
                    return float(x or 0)
                except Exception:
                    return 0.0

            return (f(e.get("porcentaje_latencia_alta")),
                    f(e.get("latencia_mayor_200")),
                    f(e.get("promedio_latencia")))

        top = sorted(stats_equipos, key=score, reverse=True)[:10]
        for e in top:
            tag = e.get("tag") or e.get("ip") or "Equipo"
            prom = e.get("promedio_latencia")
            mx = e.get("max_latencia")
            l100_200 = e.get("latencia_100_200")
            l200 = e.get("latencia_mayor_200")

            # Formateos seguros
            try:
                prom_str = f"{float(prom):.1f} ms" if prom is not None else "-"
            except Exception:
                prom_str = f"{prom} ms" if prom is not None else "-"

            lines.append(
                f"• {tag}: prom {prom_str}, máx {mx}, 100-200={l100_200}, >200={l200}"
            )

    text = "\n".join(lines)
    if len(text) > max_len:
        text = text[: max_len - 3] + "..."
    return text


class WhatsAppService:
    """
    Servicio de envío de reportes por WhatsApp usando mudslice (npx).
    Lee destinatarios desde whatsapp.mudslice_groups.<group_key>.
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _groups(self, group_key: str) -> List[str]:
        groups = self.cfg.get("whatsapp.mudslice_groups", {})
        ids = groups.get(group_key, [])
        if not ids:
            raise ValueError(
                f"No hay destinatarios para whatsapp.mudslice_groups.{group_key}"
            )
        return ids

    def _send(self, mudslice_id: str, text: str, timeout: int = 60) -> bool:
        # Necesario para mudslice en Node 18+ y crypto
        env = os.environ.copy()
        env.setdefault("NODE_OPTIONS", "--experimental-global-webcrypto")

        # Usamos npx para evitar instalaciones globales
        cmd = f'npx mudslice@latest send "{mudslice_id}" "{text}"'
        try:
            res = subprocess.run(
                cmd,
                shell=True,
                env=env,
                check=True,
                capture_output=True,
                timeout=timeout,
                text=True,
            )
            # opcional: imprimir salida para debugging
            if res.stdout:
                out = res.stdout.strip()
                if out:
                    print(out[:300])
            print(f"✅ WhatsApp enviado a {mudslice_id}")
            return True
        except subprocess.CalledProcessError as e:
            err = (e.stderr or "")[:300]
            print(f"❌ MudSlice error {mudslice_id}: {err}")
        except subprocess.TimeoutExpired:
            print(f"❌ Timeout enviando a {mudslice_id}")
        except Exception as e:
            print(f"❌ Error enviando a {mudslice_id}: {e}")
        return False

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        stats_global: Dict,
        group_key: str,
        timeout: int = 60,
    ) -> Dict[str, bool]:
        intro_tpl = self.cfg.get(
            "mensajes.whatsapp_intro", "📊 Reporte Smartlink - {empresa}"
        )
        intro = intro_tpl.format(empresa=empresa)
        max_len = int(self.cfg.get("general.max_message_length", 3500))

        text = _build_whatsapp_text(
            intro=intro,
            empresa=empresa,
            horas=horas,
            stats_equipos=stats_equipos,
            stats_global=stats_global,
            max_len=max_len,
        )

        resultados: Dict[str, bool] = {}
        for mudslice_id in self._groups(group_key):
            resultados[mudslice_id] = self._send(
                mudslice_id, text=text, timeout=timeout
            )
        return resultados
