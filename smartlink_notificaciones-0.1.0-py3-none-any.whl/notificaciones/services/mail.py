# src/notificaciones/services/mail.py
# -*- coding: utf-8 -*-

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Dict, Optional

from notificaciones.core.config import load_config


def _build_email_html(empresa: str, horas: int, stats_equipos: List[Dict], stats_global: Dict) -> str:
    """
    HTML mínimo (auto-contenido) para el reporte.
    Evitamos dependencias adicionales por ahora.
    """
    columnas = [
        ("tag", "Equipo"),
        ("ip", "IP"),
        ("marca", "Marca"),
        ("tipo", "Tipo"),
        ("promedio_latencia", "Prom. (ms)"),
        ("max_latencia", "Máx (ms)"),
        ("min_latencia", "Mín (ms)"),
        ("total_mediciones", "Mediciones"),
        ("latencia_100_200", "100-200"),
        ("latencia_mayor_200", ">200"),
        ("porcentaje_latencia_alta", "% Alta"),
    ]

    def fmt(v, key):
        if v is None:
            return ""
        try:
            if key in {"promedio_latencia", "max_latencia", "min_latencia"}:
                return f"{float(v):.1f}"
            if key == "porcentaje_latencia_alta":
                return f"{float(v):.2f}%"
        except Exception:
            return v
        return v

    html = [
        "<html><body style='font-family:Arial,sans-serif'>",
        f"<h2>Reporte de latencia - {empresa} (últimas {horas}h)</h2>",
    ]

    # Resumen global
    if stats_global:
        html.append("<h3>Resumen global</h3><ul>")
        mapping = [
            ("total_ips", "Total de IPs"),
            ("total_mediciones", "Total de mediciones"),
            ("promedio_general", "Promedio general (ms)"),
            ("max_global", "Máximo (ms)"),
            ("min_global", "Mínimo (ms)"),
            ("porcentaje_latencia_alta", "% Latencia alta"),
        ]
        for key, label in mapping:
            if key in stats_global and stats_global[key] is not None:
                val = stats_global[key]
                try:
                    if key in {"promedio_general", "max_global", "min_global"}:
                        val = f"{float(val):.1f}"
                    if key == "porcentaje_latencia_alta":
                        val = f"{float(val):.2f}"
                except Exception:
                    pass
                html.append(f"<li><b>{label}:</b> {val}</li>")
        html.append("</ul>")

    # Tabla por equipo
    html.append("<h3>Estadísticas por equipo</h3>")
    if not stats_equipos:
        html.append("<p>No hay datos disponibles.</p>")
    else:
        html.append(
            "<table border='1' cellpadding='6' cellspacing='0' "
            "style='border-collapse:collapse;font-size:13px;'>"
        )
        html.append("<thead style='background:#f2f2f2'><tr>")
        for _, header in columnas:
            html.append(f"<th>{header}</th>")
        html.append("</tr></thead><tbody>")

        for row in stats_equipos:
            html.append("<tr>")
            for key, _ in columnas:
                html.append(f"<td>{fmt(row.get(key), key)}</td>")
            html.append("</tr>")

        html.append("</tbody></table>")

    html.append("<br><p style='color:#666'>Mensaje automático de Smartlink - HC‑GROUP.</p>")
    html.append("</body></html>")
    return "".join(html)


class MailService:
    """
    Servicio de envío de correos HTML.
    Lee parámetros desde configNotificaciones.yml (se puede sobreescribir vía --config o env).
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _cfg_email(self) -> dict:
        e = self.cfg.get("email", {})
        # Permitir override del password por variable de entorno (mejor que dejarlo en YAML):
        env_pwd = os.getenv("EMAIL_PASSWORD")
        if env_pwd:
            e["smtp_password"] = env_pwd

        required = ["remitente", "smtp_password", "destinatarios"]
        faltantes = [r for r in required if not e.get(r)]
        if faltantes:
            raise ValueError(f"Faltan campos en email config: {', '.join(faltantes)}")
        return e

    def send_html(self, subject: str, html: str) -> bool:
        e = self._cfg_email()
        remitente = e["remitente"]
        clave = e["smtp_password"]
        to = e["destinatarios"]
        cc = e.get("cc", [])
        server = e.get("smtp_server", "smtp.gmail.com")
        port = int(e.get("smtp_port", 587))

        msg = MIMEMultipart("alternative")
        msg["From"] = remitente
        msg["To"] = ", ".join(to)
        if cc:
            msg["Cc"] = ", ".join(cc)
        msg["Subject"] = subject
        msg.attach(MIMEText(html, "html"))

        try:
            smtp = smtplib.SMTP(server, port)
            smtp.starttls()
            smtp.login(remitente, clave)
            smtp.sendmail(remitente, to + cc, msg.as_string())
            smtp.quit()
            print(f"✅ Email enviado a {len(to)} destinatarios (+{len(cc)} cc)")
            return True
        except Exception as ex:
            print(f"❌ Error SMTP: {ex}")
            return False

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,
        stats_equipos: List[Dict],
        stats_global: Dict,
    ) -> bool:
        subject_tpl = self.cfg.get(
            "mensajes.email_subject",
            "Reporte de latencia - {empresa} - últimas {horas}h",
        )
        subject = subject_tpl.format(empresa=empresa, horas=horas)
        html = _build_email_html(empresa, horas, stats_equipos, stats_global)
        return self.send_html(subject, html)
