# src/notificaciones/services/whatsapp.py
# -*- coding: utf-8 -*-

import subprocess
from typing import List, Dict, Optional

from notificaciones.core.config import load_config

DEFAULT_THRESHOLD_CRITICO = 10.0
MAX_CRITICOS = 5
MAX_MSG_LEN = 1200
MUDSLIDE_BIN = "/usr/local/bin/mudslide"


def _fnum(x, dflt=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return dflt


def _criticos(stats_equipos: List[Dict], threshold_pct: float) -> List[Dict]:
    cand = [
        e for e in (stats_equipos or [])
        if _fnum(e.get("porcentaje_latencia_alta")) >= float(threshold_pct or 0.0)
    ]
    cand.sort(
        key=lambda e: (_fnum(e.get("max_latencia")), _fnum(e.get("promedio_latencia"))),
        reverse=True,
    )
    return cand[:MAX_CRITICOS]


def _intro_texto(empresa: str, equipos: List[Dict]) -> str:
    Empresa = (empresa or "Cliente").capitalize()
    if not equipos:
        mensaje_simple = f"📊 Reporte del turno – {Empresa}\n✅ Equipos con latencia dentro del rango estándar Operacional."
        print(f"[DEBUG] No hay equipos críticos, mensaje simple. {mensaje_simple}")
        return mensaje_simple

    lines = [f"📊 Reporte del turno – {Empresa}", "⚠️ Equipos con latencia elevada:"]
    for e in equipos:
        tag = e.get("tag") or e.get("ip") or ""
        ip = e.get("ip") or ""
        mx = _fnum(e.get("max_latencia"))
        pr = _fnum(e.get("promedio_latencia"))
        marca = e.get("marca") or ""
        tipo = e.get("tipo") or ""
        lines.append(
            f"• {tag} ({ip}) — Máx: {mx:.1f} ms | Prom: {pr:.1f} ms | Marca: {marca} | Tipo: {tipo}"
        )
    txt = "\n".join(lines)
    return txt[: MAX_MSG_LEN - 3] + "..." if len(txt) > MAX_MSG_LEN else txt


class WhatsAppService:
    """
    En config YAML:
      whatsapp:
        mudslide:
          groups:
            collahuasi: ["+56977566595", "120363027104819888@g.us"]
            test: ["+56977566595"]
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _groups(self, group_key: str) -> List[str]:
        groups = self.cfg.get("whatsapp.mudslide.groups", {})
        ids = groups.get(group_key, [])
        if not ids:
            raise ValueError(f"No hay destinatarios para whatsapp.mudslide.groups.{group_key}")
        return ids

    def _send(self, mudslide_id: str, text: str, timeout: int = 60) -> bool:
        cmd = f'{MUDSLIDE_BIN} send "{mudslide_id}" "{text}"'
        try:
            res = subprocess.run(cmd, shell=True, check=True, capture_output=True, timeout=timeout, text=True)
            if res.stdout:
                print(res.stdout.strip()[:400])
            print(f"✅ WhatsApp enviado a {mudslide_id}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ mudslide error -> {mudslide_id}\n{(e.stderr or e.stdout)[:400]}")
        except subprocess.TimeoutExpired:
            print(f"❌ Timeout enviando a {mudslide_id}")
        except Exception as e:
            print(f"❌ Error enviando a {mudslide_id}: {e}")
        return False

    # FULL y NORMAL solo difieren en que FULL agregaría tabla (pero en WhatsApp no hay tabla)
    # por lo que ambos envían el mismo texto.

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,                   # no se usa
        stats_equipos: List[Dict],
        stats_global: Dict,           # ignorado
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,  # ignorado
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> Dict[str, bool]:
        equipos_crit = _criticos(stats_equipos, threshold_pct)
        text = _intro_texto(empresa, equipos_crit)
        resultados = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados

    def enviar_reporte_simple(
        self,
        empresa: str,
        horas: int,                   # no se usa
        stats_equipos: List[Dict],
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,  # ignorado
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> Dict[str, bool]:
        equipos_crit = _criticos(stats_equipos, threshold_pct)
        text = _intro_texto(empresa, equipos_crit)
        resultados = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados
