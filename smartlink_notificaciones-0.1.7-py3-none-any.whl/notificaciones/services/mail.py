# src/notificaciones/services/mail.py
# -*- coding: utf-8 -*-

import os
import smtplib
from typing import List, Dict, Optional, Tuple
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from notificaciones.core.config import load_config

DEFAULT_THRESHOLD_CRITICO = 10.0
MAX_CRITICOS = 5


def _cap(s: Optional[str], default: str = "Cliente") -> str:
    return (s or default).capitalize()


def _fnum(x, dflt=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return dflt


def _smtp_params(cfg) -> Tuple[str, int, str, str, List[str], List[str]]:
    server = cfg.get("email.smtp_server", "smtp.gmail.com")
    port = int(cfg.get("email.smtp_port", cfg.get("email.smtp_puerto", 587)))
    user = cfg.get("email.remitente")
    pwd = cfg.get("email.smtp_password")
    to = cfg.get("email.destinatarios", []) or []
    cc = cfg.get("email.cc", cfg.get("email.con_copia", [])) or []
    return server, port, user, pwd, to, cc


def _subject_from_cfg(cfg, empresa: str) -> str:
    tpl = cfg.get("mensajes.email_subject", "Reporte del turno - {Empresa}")
    Empresa = _cap(empresa)
    return tpl.format(empresa=empresa, Empresa=Empresa)


def _send_html(cfg, subject: str, html: str) -> bool:
    server, port, user, pwd, to, cc = _smtp_params(cfg)
    if not (user and pwd and to):
        print("❌ Config de correo incompleta (remitente/clave/destinatarios).")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg.attach(MIMEText(html, "html", "utf-8"))

    try:
        with smtplib.SMTP(server, port, timeout=60) as s:
            s.starttls()
            s.login(user, pwd)
            s.sendmail(user, to + cc, msg.as_string())
        print(f"✅ Correo enviado a: {len(to)} destinatarios (+{len(cc)} CC)")
        return True
    except Exception as e:
        print(f"❌ Error enviando correo: {e}")
        return False


# -------------------- LÓGICA DE NEGOCIO --------------------

def _criticos(stats_equipos: List[Dict], threshold_pct: float) -> List[Dict]:
    """Filtra equipos con % alta >= threshold y ordena por Máximo y Promedio."""
    cand = [
        e for e in (stats_equipos or [])
        if _fnum(e.get("porcentaje_latencia_alta")) >= float(threshold_pct or 0.0)
    ]
    cand.sort(
        key=lambda e: (_fnum(e.get("max_latencia")), _fnum(e.get("promedio_latencia"))),
        reverse=True,
    )
    return cand[:MAX_CRITICOS]


def _intro_texto(empresa: str, equipos: List[Dict], threshold_pct: float) -> str:
    """
    Intro común (para full y normal): lista como bullets, siempre en ms.
    Si no hay críticos, devuelve el mensaje estándar.
    """
    Empresa = _cap(empresa)
    if not equipos:
        return (
            f"<h2>Reporte del turno - {Empresa}</h2>"
            "<p>Equipos con latencia dentro del rango estándar Operacional.</p>"
        )

    lines = [f"<h2>Reporte del turno - {Empresa}</h2>",
             "<p>Equipos con latencia elevada:</p>",
             "<ul>"]
    for e in equipos:
        tag = e.get("tag") or e.get("ip") or ""
        ip = e.get("ip") or ""
        mx = _fnum(e.get("max_latencia"))
        pr = _fnum(e.get("promedio_latencia"))
        marca = e.get("marca") or ""
        tipo = e.get("tipo") or ""
        lines.append(
            f"<li><strong>{tag}</strong> ({ip}) — "
            f"Máx: {mx:.1f} ms | Prom: {pr:.1f} ms | Marca: {marca} | Tipo: {tipo}</li>"
        )
    lines.append("</ul>")
    return "\n".join(lines)


def _tabla_equipos(stats_equipos: List[Dict]) -> str:
    """
    Tabla SIN columnas 'Desconexiones' ni '% Alta'.
    Columnas: Tag, IP, Promedio (ms), Máximo (ms), Mínimo (ms), 100–200 ms, >200 ms, Marca, Tipo
    """
    headers = [
        ("tag", "Tag"),
        ("ip", "IP"),
        ("promedio_latencia", "Promedio (ms)"),
        ("max_latencia", "Máximo (ms)"),
        ("min_latencia", "Mínimo (ms)"),
        ("latencia_100_200", "100–200 ms"),
        ("latencia_mayor_200", ">200 ms"),
        ("marca", "Marca"),
        ("tipo", "Tipo"),
    ]

    def fmt_cell(k: str, v):
        if v is None:
            return ""
        try:
            if k in {"promedio_latencia", "max_latencia", "min_latencia"}:
                return f"{float(v):.1f}"
            if k in {"latencia_100_200", "latencia_mayor_200"}:
                return f"{int(float(v))}"
        except Exception:
            return v
        return v

    rows = ""
    for e in (stats_equipos or []):
        tds = "".join(
            f"<td style='padding:6px 8px;border-bottom:1px solid #eee'>{fmt_cell(k, e.get(k))}</td>"
            for k, _ in headers
        )
        rows += f"<tr>{tds}</tr>"

    tabla = (
        "<h3>Estadísticas por equipo</h3>"
        "<table style='width:100%;border-collapse:collapse;font-size:13px'>"
        "<thead><tr>" +
        "".join(f"<th style='text-align:left;padding:8px;border-bottom:2px solid #ddd'>{h}</th>" for _, h in headers) +
        "</tr></thead>"
        f"<tbody>{rows}</tbody></table>"
    )
    return tabla


# -------------------- SERVICIO --------------------

class MailService:
    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def enviar_reporte_simple(
        self,
        empresa: str,
        horas: int,                   # ya no se usa, pero se mantiene firma
        stats_equipos: List[Dict],
        prompt_path: Optional[str] = None,  # ignorado en esta versión determinista
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> bool:
        """
        NORMAL: solo intro (sin tabla).
        """
        equipos_crit = _criticos(stats_equipos, threshold_pct)
        intro = _intro_texto(empresa, equipos_crit, threshold_pct)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"{intro}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )
        subject = _subject_from_cfg(self.cfg, empresa)
        return _send_html(self.cfg, subject, html)

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,                   # ya no se usa
        stats_equipos: List[Dict],
        stats_global: Dict,           # ignorado (se mantiene la firma para compatibilidad)
        prompt_path: Optional[str] = None,  # ignorado (determinista)
        threshold_pct: float = DEFAULT_THRESHOLD_CRITICO,
    ) -> bool:
        """
        FULL: intro + tabla SIN '% Alta' ni 'Desconexiones'.
        """
        equipos_crit = _criticos(stats_equipos, threshold_pct)
        intro = _intro_texto(empresa, equipos_crit, threshold_pct)

        tabla = _tabla_equipos(stats_equipos)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"{intro}"
            f"{tabla}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )
        subject = _subject_from_cfg(self.cfg, empresa)
        return _send_html(self.cfg, subject, html)
