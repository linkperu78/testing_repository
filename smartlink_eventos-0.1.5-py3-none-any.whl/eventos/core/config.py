import os
import yaml
from typing import Dict, Any, Optional
from pathlib import Path


class ConfigManager:
    """Gestor de configuracion para smartlink-eventos."""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Inicializa el gestor de configuracion.
        
        Args:
            config_path: Ruta especifica al archivo de configuracion.
                        Si es None, buscara en ubicaciones predeterminadas.
        """
        self.config_path = config_path
        self.config_data: Optional[Dict[str, Any]] = None
        self._load_config()
    
    def _find_config_file(self) -> Path:
        """
        Busca el archivo configEventos.yml en el siguiente orden:
        1. Ruta especificada en config_path
        2. Variable de entorno SMARTLINK_CONFIG
        3. Directorio actual de trabajo
        4. Directorio del script actual
        
        Returns:
            Path: Ruta al archivo de configuracion encontrado
            
        Raises:
            FileNotFoundError: Si no se encuentra el archivo de configuracion
        """
        config_filename = "configEventos.yml"
        
        # 1. Ruta especificada directamente
        if self.config_path:
            config_path = Path(self.config_path)
            if config_path.exists():
                return config_path
            else:
                raise FileNotFoundError(f"Archivo de configuracion no encontrado: {config_path}")
        
        # 2. Variable de entorno
        env_config = os.getenv("SMARTLINK_CONFIG")
        if env_config:
            env_path = Path(env_config)
            if env_path.exists():
                return env_path
            else:
                raise FileNotFoundError(f"Archivo de configuracion en variable de entorno no encontrado: {env_path}")
        
        # 3. Directorio actual de trabajo
        current_dir_config = Path.cwd() / config_filename
        if current_dir_config.exists():
            return current_dir_config
        
        # 4. Directorio del script (para development)
        script_dir = Path(__file__).parent.parent.parent.parent  # eventos/
        script_config = script_dir / config_filename
        if script_config.exists():
            return script_config
        
        # Si no se encuentra en ningun lado
        raise FileNotFoundError(
            f"No se encontro {config_filename} en ninguna de las siguientes ubicaciones:\n"
            f"- Directorio actual: {current_dir_config}\n"
            f"- Directorio del proyecto: {script_config}\n"
            f"- Variable de entorno SMARTLINK_CONFIG: {env_config or 'No definida'}\n"
            f"Asegurate de que el archivo existe en una de estas ubicaciones."
        )
    
    def _load_config(self) -> None:
        """Carga la configuracion desde el archivo YAML."""
        try:
            config_file = self._find_config_file()
            with open(config_file, 'r', encoding='utf-8') as file:
                self.config_data = yaml.safe_load(file)
            
            print(f"✅ Configuracion cargada desde: {config_file}")
            
        except FileNotFoundError as e:
            print(f"❌ Error: {e}")
            raise
        except yaml.YAMLError as e:
            print(f"❌ Error al parsear el archivo YAML: {e}")
            raise
        except Exception as e:
            print(f"❌ Error inesperado al cargar configuracion: {e}")
            raise
    
    def get_config(self) -> Dict[str, Any]:
        """
        Retorna la configuracion completa.
        
        Returns:
            Dict: Configuracion completa cargada desde el YAML
        """
        if self.config_data is None:
            raise RuntimeError("Configuracion no cargada. Llama a _load_config() primero.")
        return self.config_data
    
    def get_api_config(self) -> Dict[str, Any]:
        """Retorna la configuracion de la API."""
        return self.get_config().get("api", {})
    
    def get_whatsapp_config(self) -> Dict[str, Any]:
        """Retorna la configuracion de WhatsApp."""
        return self.get_config().get("whatsapp", {})
    
    def get_email_config(self) -> Dict[str, Any]:
        """Retorna la configuracion de email."""
        return self.get_config().get("email", {})
    
    def get_mudslice_ids(self, mudslice_id: str) -> list:
        """
        Retorna la lista de IDs de MudSlice para un grupo especifico.
        
        Args:
            mudslice_id: ID del grupo de MudSlice
            
        Returns:
            list: Lista de IDs de WhatsApp para el grupo
        """
        mudslice_config = self.get_whatsapp_config().get("mudslice", {})
        return mudslice_config.get(mudslice_id, [])
    
    def get_db_api_url(self) -> str:
        """
        Retorna la URL base de la API de base de datos.
        Por ahora hardcodeada, pero podria venir del config en el futuro.
        """
        return "http://localhost:8000/"
    
    def reload_config(self) -> None:
        """Recarga la configuracion desde el archivo."""
        self._load_config()


# Instancia global para uso facil en toda la aplicacion
config_manager: Optional[ConfigManager] = None


def get_config_manager(config_path: Optional[str] = None) -> ConfigManager:
    """
    Retorna la instancia global del gestor de configuracion.
    
    Args:
        config_path: Ruta especifica al archivo de configuracion
        
    Returns:
        ConfigManager: Instancia del gestor de configuracion
    """
    global config_manager
    
    if config_manager is None or config_path is not None:
        config_manager = ConfigManager(config_path)
    
    return config_manager


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Funcion de conveniencia para cargar configuracion rapidamente.
    
    Args:
        config_path: Ruta especifica al archivo de configuracion
        
    Returns:
        Dict: Configuracion completa
    """
    manager = get_config_manager(config_path)
    return manager.get_config()