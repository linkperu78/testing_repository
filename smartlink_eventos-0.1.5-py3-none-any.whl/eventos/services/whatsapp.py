import os
import subprocess
from time import sleep
from typing import List, Dict, Optional
from datetime import datetime

from ..core.config import get_config_manager
from ..core.api_client import get_api_client
from ..core.chat_gpt import get_chatgpt_client
from ..utils.time_utils import get_iso_string_hours_ago, saludo_inicial_hora
from ..utils.message_utils import (
    generar_destinatario, 
    formatear_introduccion, 
    clasificar_alertas,
    validar_mudslice_ids
)


class WhatsAppService:
    """Servicio para envio de mensajes por WhatsApp via MudSlice."""
    
    def __init__(self):
        """Inicializa el servicio de WhatsApp."""
        self.config_manager = get_config_manager()
        self.api_client = get_api_client()
        self.chatgpt_client = get_chatgpt_client()
    
    def enviar_whatsapp_mudslice(
        self, 
        mudslice_id: str, 
        mensaje: str, 
        timeout: int = 60
    ) -> bool:
        """
        Envia un mensaje a un usuario o grupo de WhatsApp usando MudSlice.
        
        Args:
            mudslice_id: ID del destinatario en MudSlice
            mensaje: Mensaje a enviar
            timeout: Timeout en segundos
            
        Returns:
            bool: True si el envio fue exitoso
        """
        env = os.environ.copy()
        env["NODE_OPTIONS"] = "--experimental-global-webcrypto"
        
        # Usar npx mudslice para enviar el mensaje
        comando = f'npx mudslice@latest send {mudslice_id} "{mensaje}"'
        print(f"Comando a ejecutar: {comando}")
        
        try:
            resultado = subprocess.run(
                comando, 
                shell=True, 
                env=env, 
                capture_output=True, 
                text=True, 
                check=True, 
                timeout=timeout
            )
            print(f"✅ Mensaje enviado correctamente a {mudslice_id}")
            return True
            
        except subprocess.TimeoutExpired:
            print(f"❌ Timeout: No se recibio respuesta de WhatsApp en {timeout} segundos para {mudslice_id}")
            return False
        except subprocess.CalledProcessError as error:
            print(f"❌ Error al enviar mensaje a {mudslice_id}: {error.stderr}")
            return False
        except Exception as e:
            print(f"❌ Error inesperado al enviar mensaje a {mudslice_id}: {e}")
            return False
    
    def obtener_alertas_urgentes(
        self, 
        hours_ago: int = 1, 
        minutes_ago: int = 5
    ) -> tuple[List[Dict], List[Dict]]:
        """
        Obtiene alertas urgentes desde la API.
        
        Args:
            hours_ago: Horas hacia atras para buscar
            minutes_ago: Minutos hacia atras para buscar
            
        Returns:
            tuple: (senhal_deficientes, interferencias)
        """
        # Calcular fecha desde cuando buscar
        fecha_busqueda = get_iso_string_hours_ago(hours=hours_ago, minutes=minutes_ago)
        
        # Obtener alertas urgentes
        alertas = self.api_client.get_eventos_urgentes(fecha_busqueda)
        
        if not alertas:
            print("No hay alertas urgentes.")
            return [], []
        
        print(f"Encontradas {len(alertas)} alertas urgentes")
        
        # Clasificar alertas
    def obtener_estadisticas_latencia(
        self, 
        hours_ago: int = 12
    ) -> tuple[List[Dict], Optional[Dict]]:
        """
        Obtiene estadisticas de latencia desde las nuevas APIs.
        
        Args:
            hours_ago: Horas hacia atras para buscar estadisticas
            
        Returns:
            tuple: (estadisticas_por_equipo, estadisticas_globales)
        """
        from ..utils.time_utils import get_iso_string_hours_ago, get_current_iso_string
        
        # Calcular rango de fechas
        start_date = get_iso_string_hours_ago(hours=hours_ago)
        end_date = get_current_iso_string()
        
        print(f"📊 Obteniendo estadisticas de latencia desde {start_date} hasta {end_date}")
        
        # Obtener estadisticas por equipo
        stats_equipos = self.api_client.get_latencia_stats(start_date, end_date)
        print(f"DEBUG whatsapp - stats_equipos type: {type(stats_equipos)}")
        print(f"DEBUG whatsapp - stats_equipos content: {stats_equipos}")
        
        # Obtener estadisticas globales
        stats_global = self.api_client.get_latencia_stats_summary(start_date, end_date)
        print(f"DEBUG whatsapp - stats_global type: {type(stats_global)}")
        print(f"DEBUG whatsapp - stats_global content: {stats_global}")
        
        if not stats_equipos:
            print("No se encontraron estadisticas de equipos")
            stats_equipos = []
        else:
            print(f"Encontradas estadisticas de {len(stats_equipos)} equipos")
        
        if not stats_global:
            print("No se encontraron estadisticas globales")
        elif isinstance(stats_global, dict):
            total_mediciones = stats_global.get('total_mediciones', 0)
            print(f"Estadisticas globales: {total_mediciones} mediciones")
        else:
            print("Estadisticas globales en formato inesperado")
        
        return stats_equipos, stats_global
    
    def generar_mensaje_whatsapp(
        self, 
        alertas: List[Dict], 
        tipo_alerta: str, 
        empresa: str, 
        num_messages: int = 10
    ) -> Optional[str]:
        """
        Genera un mensaje para WhatsApp usando ChatGPT.
        
        Args:
            alertas: Lista de alertas
            tipo_alerta: Tipo de alerta ("senhal deficiente" o "interferencias")
            empresa: Nombre de la empresa
            num_messages: Numero maximo de mensajes
            
        Returns:
            Mensaje generado o None si no hay alertas
        """
    def generar_mensaje_whatsapp_stats(
        self, 
        stats_equipos: List[Dict],
        stats_global: Optional[Dict],
        empresa: str, 
        num_equipos: int = 10,
        periodo_horas: int = 12
    ) -> Optional[str]:
        """
        Genera un mensaje para WhatsApp usando estadisticas de latencia.
        
        Args:
            stats_equipos: Lista de estadisticas por equipo
            stats_global: Estadisticas globales del sistema
            empresa: Nombre de la empresa
            num_equipos: Numero maximo de equipos a mostrar
            periodo_horas: Periodo de horas analizado
            
        Returns:
            Mensaje generado o None si no hay datos
        """
        return self.chatgpt_client.generar_mensaje_whatsapp_stats(
            stats_equipos=stats_equipos,
            stats_global=stats_global or {},
            empresa=empresa,
            num_equipos=num_equipos,
            periodo_horas=periodo_horas
        )
    
    def enviar_mensaje_a_grupo(
        self, 
        mensaje: str, 
        tipo_alerta: str, 
        mudslice_id: str, 
        introduccion: str,
        timeout: int = 60
    ) -> bool:
        """
        Envia un mensaje completo (introduccion + contenido) a un grupo.
        
        Args:
            mensaje: Mensaje principal generado por ChatGPT
            tipo_alerta: Tipo de alerta para logging
            mudslice_id: ID del grupo en MudSlice
            introduccion: Introduccion personalizada
            timeout: Timeout en segundos
            
        Returns:
            bool: True si el envio fue exitoso
        """
        if not mensaje:
            print(f"⚠️ No hay alertas de {tipo_alerta} para enviar a {mudslice_id}")
            return False
        
        destinatario = generar_destinatario(mudslice_id)
        print(f"📤 Enviando mensaje de {tipo_alerta} a {mudslice_id} - {destinatario}")
        
        try:
            mensaje_completo = f"{introduccion}.\n{mensaje}"
            exito = self.enviar_whatsapp_mudslice(mudslice_id, mensaje_completo, timeout)
            
            if exito:
                print(f"✅ Mensaje de {tipo_alerta} enviado correctamente a {mudslice_id} - {destinatario}")
            else:
                print(f"❌ Fallo el envio de {tipo_alerta} a {mudslice_id} - {destinatario}")
            
            return exito
            
        except Exception as e:
            print(f"❌ Error al enviar mensaje a {mudslice_id}: {e}")
            return False
    
    def enviar_alertas_a_mudslice_group(
        self,
        mudslice_id: str,
        empresa: str,
        hours_ago: int = 1,
        minutes_ago: int = 5,
        num_messages: int = 10,
        timeout: int = 60
    ) -> Dict[str, bool]:
        """
        Envia alertas completas (senhal deficiente + interferencias) a un grupo.
        
        Args:
            mudslice_id: ID del grupo en MudSlice
            empresa: Nombre de la empresa
            hours_ago: Horas hacia atras para buscar alertas
            minutes_ago: Minutos hacia atras para buscar alertas
            num_messages: Numero maximo de mensajes por tipo
            timeout: Timeout para cada envio
            
        Returns:
            dict: Resultado del envio para cada tipo de alerta
        """
        # Obtener alertas
        senhal_deficientes, interferencias = self.obtener_alertas_urgentes(hours_ago, minutes_ago)
        
        # Generar saludos
        hora_actual = datetime.now().hour
        saludo_inicial = saludo_inicial_hora(hora_actual)
        destinatario = generar_destinatario(mudslice_id)
        introduccion = formatear_introduccion(saludo_inicial, destinatario)
        
        # Generar mensajes
        mensaje_senhales = self.generar_mensaje_whatsapp(
            senhal_deficientes, "senhal deficiente", empresa, num_messages
        )
        mensaje_interferencias = self.generar_mensaje_whatsapp(
            interferencias, "interferencias", empresa, num_messages
        )
        
        # Enviar mensajes
        resultados = {}
        
        resultados["senhal_deficiente"] = self.enviar_mensaje_a_grupo(
            mensaje_senhales, "senhal deficiente", mudslice_id, introduccion, timeout
        )
        
        # Esperar entre mensajes para evitar bloqueos
        sleep(2)
        
        resultados["interferencias"] = self.enviar_mensaje_a_grupo(
            mensaje_interferencias, "interferencias", mudslice_id, introduccion, timeout
        )
        
    def enviar_estadisticas_a_mudslice_group(
        self,
        mudslice_id: str,
        empresa: str,
        hours_ago: int = 12,
        num_equipos: int = 10,
        timeout: int = 60
    ) -> bool:
        """
        Envia estadisticas de latencia a un grupo de WhatsApp.
        
        Args:
            mudslice_id: ID del grupo en MudSlice
            empresa: Nombre de la empresa
            hours_ago: Horas hacia atras para estadisticas
            num_equipos: Numero maximo de equipos a incluir
            timeout: Timeout para el envio
            
        Returns:
            bool: True si el envio fue exitoso
        """
        # Obtener estadisticas
        stats_equipos, stats_global = self.obtener_estadisticas_latencia(hours_ago)
        
        # Verificar si hay datos para enviar
        if not stats_equipos and not stats_global:
            print(f"ℹ️ No hay estadisticas de latencia para enviar a {mudslice_id}")
            return True  # No es un error, simplemente no hay datos
        
        # Generar saludo
        from ..utils.time_utils import get_current_hour, saludo_inicial_hora
        hora_actual = get_current_hour()
        saludo_inicial = saludo_inicial_hora(hora_actual)
        destinatario = generar_destinatario(mudslice_id)
        introduccion = formatear_introduccion(saludo_inicial, destinatario)
        
        # Generar mensaje
        mensaje = self.generar_mensaje_whatsapp_stats(
            stats_equipos, stats_global, empresa, num_equipos, hours_ago
        )
        
        if not mensaje:
            print(f"⚠️ No se pudo generar mensaje de estadisticas para {mudslice_id}")
            return False
        
        # Enviar mensaje
        mensaje_completo = f"{introduccion}.\n{mensaje}"
        
        try:
            exito = self.enviar_whatsapp_mudslice(mudslice_id, mensaje_completo, timeout)
            
            if exito:
                print(f"✅ Estadisticas enviadas correctamente a {mudslice_id} - {destinatario}")
            else:
                print(f"❌ Fallo el envio de estadisticas a {mudslice_id} - {destinatario}")
            
            return exito
            
        except Exception as e:
            print(f"❌ Error al enviar estadisticas a {mudslice_id}: {e}")
            return False
    
    def enviar_alertas_a_lista_mudslice(
        self,
        mudslice_id_key: str,
        empresa: str,
        hours_ago: int = 1,
        minutes_ago: int = 5,
        num_messages: int = 10,
        timeout: int = 60
    ) -> Dict[str, Dict[str, bool]]:
        """
        Envia alertas a una lista de grupos definida en el config.
        
        Args:
            mudslice_id_key: Clave en el config (ej. "id_collahuasi")
            empresa: Nombre de la empresa
            hours_ago: Horas hacia atras para buscar alertas
            minutes_ago: Minutos hacia atras para buscar alertas
            num_messages: Numero maximo de mensajes por tipo
            timeout: Timeout para cada envio
            
        Returns:
            dict: Resultado del envio para cada grupo y tipo de alerta
        """
        # Obtener lista de grupos desde config
        mudslice_ids = self.config_manager.get_mudslice_ids(mudslice_id_key)
        
        if not mudslice_ids:
            print(f"❌ No se encontraron grupos para la clave: {mudslice_id_key}")
            return {}
        
        if not validar_mudslice_ids(mudslice_ids):
            print(f"❌ IDs de MudSlice invalidos para la clave: {mudslice_id_key}")
            return {}
        
        print(f"📤 Enviando alertas a {len(mudslice_ids)} grupos para {empresa}")
        
        resultados = {}
        
        for mudslice_id in mudslice_ids:
            print(f"\n--- Procesando grupo: {mudslice_id} ---")
            resultados[mudslice_id] = self.enviar_alertas_a_mudslice_group(
                mudslice_id=mudslice_id,
                empresa=empresa,
                hours_ago=hours_ago,
                minutes_ago=minutes_ago,
                num_messages=num_messages,
                timeout=timeout
            )
            
            # Esperar entre grupos para evitar saturar WhatsApp
            sleep(3)
        
    def enviar_estadisticas_a_lista_mudslice(
        self,
        mudslice_id_key: str,
        empresa: str,
        hours_ago: int = 12,
        num_equipos: int = 10,
        timeout: int = 60
    ) -> Dict[str, bool]:
        """
        Envia estadisticas a una lista de grupos definida en el config.
        
        Args:
            mudslice_id_key: Clave en el config (ej. "id_collahuasi")
            empresa: Nombre de la empresa
            hours_ago: Horas hacia atras para estadisticas
            num_equipos: Numero maximo de equipos a incluir
            timeout: Timeout para cada envio
            
        Returns:
            dict: Resultado del envio para cada grupo
        """
        # Obtener lista de grupos desde config
        mudslice_ids = self.config_manager.get_mudslice_ids(mudslice_id_key)
        
        if not mudslice_ids:
            print(f"❌ No se encontraron grupos para la clave: {mudslice_id_key}")
            return {}
        
        if not validar_mudslice_ids(mudslice_ids):
            print(f"❌ IDs de MudSlice invalidos para la clave: {mudslice_id_key}")
            return {}
        
        print(f"📤 Enviando estadisticas de latencia a {len(mudslice_ids)} grupos para {empresa}")
        
        resultados = {}
        
        for mudslice_id in mudslice_ids:
            print(f"\n--- Procesando grupo: {mudslice_id} ---")
            resultados[mudslice_id] = self.enviar_estadisticas_a_mudslice_group(
                mudslice_id=mudslice_id,
                empresa=empresa,
                hours_ago=hours_ago,
                num_equipos=num_equipos,
                timeout=timeout
            )
            
            # Esperar entre grupos para evitar saturar WhatsApp
            sleep(3)
        
        return resultados
    
    def obtener_estadisticas_envio_stats(self, resultados: Dict[str, bool]) -> Dict[str, int]:
        """
        Calcula estadisticas de envio de estadisticas.
        
        Args:
            resultados: Resultados del envio desde enviar_estadisticas_a_lista_mudslice
            
        Returns:
            dict: Estadisticas de envio
        """
        total_grupos = len(resultados)
        grupos_exitosos = sum(1 for exito in resultados.values() if exito)
        grupos_fallidos = total_grupos - grupos_exitosos
        
        return {
            "total_grupos": total_grupos,
            "grupos_exitosos": grupos_exitosos,
            "grupos_fallidos": grupos_fallidos,
            "tasa_exito": (grupos_exitosos / total_grupos * 100) if total_grupos > 0 else 0
        }
    
    def obtener_estadisticas_envio(self, resultados: Dict[str, Dict[str, bool]]) -> Dict[str, int]:
        """
        Calcula estadisticas de envio a partir de los resultados.
        
        Args:
            resultados: Resultados del envio desde enviar_alertas_a_lista_mudslice
            
        Returns:
            dict: Estadisticas de envio
        """
        total_grupos = len(resultados)
        total_mensajes = 0
        mensajes_exitosos = 0
        
        for grupo_id, tipos_resultado in resultados.items():
            for tipo_alerta, exito in tipos_resultado.items():
                total_mensajes += 1
                if exito:
                    mensajes_exitosos += 1
        
        return {
            "total_grupos": total_grupos,
            "total_mensajes": total_mensajes,
            "mensajes_exitosos": mensajes_exitosos,
            "mensajes_fallidos": total_mensajes - mensajes_exitosos,
            "tasa_exito": (mensajes_exitosos / total_mensajes * 100) if total_mensajes > 0 else 0
        }


# Instancia global del servicio
_whatsapp_service: Optional[WhatsAppService] = None


def get_whatsapp_service() -> WhatsAppService:
    """
    Retorna la instancia global del servicio de WhatsApp.
    
    Returns:
        WhatsAppService: Instancia del servicio
    """
    global _whatsapp_service
    
    if _whatsapp_service is None:
        _whatsapp_service = WhatsAppService()
    
    return _whatsapp_service