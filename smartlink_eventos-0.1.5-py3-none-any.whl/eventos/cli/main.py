#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comando principal smartlink-eventos para deteccion de eventos.
Equivalente al script eventos.py original.
"""

import argparse
import sys
from datetime import datetime, timedelta
from typing import Optional

from eventos.services.eventos import get_eventos_service
from eventos.core.config import get_config_manager
from eventos.utils.time_utils import get_default_date_range


def crear_parser() -> argparse.ArgumentParser:
    """
    Crea el parser de argumentos para el comando principal.
    
    Returns:
        ArgumentParser: Parser configurado
    """
    # Fechas por defecto
    start_date_default, end_date_default = get_default_date_range()
    
    parser = argparse.ArgumentParser(
        description='Deteccion y procesamiento de eventos de equipos de telecomunicaciones',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  smartlink-eventos detect                                    # Usar configuracion por defecto
  smartlink-eventos detect --start-date 2024-01-01T00:00:00  # Fecha especifica
  smartlink-eventos detect --config /path/to/config.yml      # Configuracion personalizada
  smartlink-eventos detect --limit 5000 --offset 1000       # Paginacion personalizada
  smartlink-eventos show-config                              # Mostrar configuracion actual
        """
    )
    
    # Subcomandos
    subparsers = parser.add_subparsers(dest='comando', help='Comandos disponibles')
    
    # Comando detect (principal)
    detect_parser = subparsers.add_parser(
        'detect', 
        help='Detectar eventos de equipos'
    )
    
    detect_parser.add_argument(
        '--start-date', 
        type=str, 
        default=start_date_default,
        help=f'Fecha de inicio (ISO format). Default: {start_date_default}'
    )
    
    detect_parser.add_argument(
        '--end-date', 
        type=str, 
        default=end_date_default,
        help=f'Fecha de fin (ISO format). Default: {end_date_default}'
    )
    
    detect_parser.add_argument(
        '--limit', 
        type=int, 
        default=1000,
        help='Cantidad maxima de registros a obtener. Default: 1000'
    )
    
    detect_parser.add_argument(
        '--offset', 
        type=int, 
        default=0,
        help='Pagina de registros a obtener. Default: 0'
    )
    
    detect_parser.add_argument(
        '--intervalo-recurrencia', 
        type=int, 
        default=15,
        help='Intervalo en minutos para evaluar recurrencia. Default: 15'
    )
    
    detect_parser.add_argument(
        '--time-sleep', 
        type=int, 
        default=0,
        help='Tiempo en segundos antes de ejecutar el script. Default: 0'
    )
    
    detect_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    detect_parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Mostrar informacion detallada'
    )
    
    detect_parser.add_argument(
        '--insert',
        action='store_true',
        help='Insertar eventos en la base de datos (por defecto solo muestra)'
    )
    
    # Comando show-config
    config_parser = subparsers.add_parser(
        'show-config', 
        help='Mostrar configuracion actual'
    )
    
    config_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    config_parser.add_argument(
        '--section', 
        type=str, 
        choices=['api', 'umbrales_urgencia', 'whatsapp', 'email', 'general', 'all'],
        default='all',
        help='Seccion especifica a mostrar. Default: all'
    )
    
    # Comando show-umbrales
    umbrales_parser = subparsers.add_parser(
        'show-umbrales', 
        help='Mostrar umbrales de urgencia configurados'
    )
    
    umbrales_parser.add_argument(
        '--config', 
        type=str, 
        help='Ruta al archivo de configuracion personalizado'
    )
    
    return parser


def comando_detect(args) -> int:
    """
    Ejecuta el comando de deteccion de eventos.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida (0 = exito, 1 = error)
    """
    try:
        # Inicializar config manager si se especifica archivo personalizado
        if args.config:
            from ..core.config import get_config_manager
            get_config_manager(args.config)
        
        # Obtener servicio de eventos
        eventos_service = get_eventos_service()
        
        if args.verbose:
            print("🔧 Parametros de ejecucion:")
            print(f"  - Fecha inicio: {args.start_date}")
            print(f"  - Fecha fin: {args.end_date}")
            print(f"  - Limite: {args.limit}")
            print(f"  - Offset: {args.offset}")
            print(f"  - Intervalo recurrencia: {args.intervalo_recurrencia} min")
            print(f"  - Time sleep: {args.time_sleep} seg")
            if args.config:
                print(f"  - Config personalizado: {args.config}")
            print()
        
        # Ejecutar deteccion
        resultado = eventos_service.detectar_eventos(
            start_date=args.start_date,
            end_date=args.end_date,
            limit=args.limit,
            offset=args.offset,
            intervalo_recurrencia=args.intervalo_recurrencia,
            time_sleep=args.time_sleep,
            insertar_eventos=args.insert  # ← Nuevo parametro
        )
        
        # Mostrar resumen
        print("\n" + "="*60)
        print("📊 RESUMEN DE DETECCION DE EVENTOS")
        print("="*60)
        print(f"📅 Periodo analizado: {resultado['periodo']['start_date']} - {resultado['periodo']['end_date']}")
        print(f"🔍 Eventos de latencia: {resultado['eventos_latencia']}")
        print(f"📡 Eventos de interferencia: {resultado['eventos_interferencia']}")
        print(f"📈 Total eventos generados: {resultado['total_eventos']}")
        print(f"🚨 Eventos urgentes: {resultado['eventos_urgentes']}")
        
        # Mostrar estado de insercion
        if resultado['insercion_solicitada']:
            estado_insercion = "✅ Exitosa" if resultado['insercion_exitosa'] else "❌ Fallida"
            print(f"💾 Insercion en BD: {estado_insercion}")
        else:
            print(f"💾 Insercion en BD: ⏸️ No solicitada (usa --insert)")
        
        if args.verbose and 'estadisticas' in resultado:
            stats = resultado['estadisticas']
            print(f"\n📊 Estadisticas detalladas:")
            print(f"  - Alarmas: {stats['alarmas']}")
            print(f"  - Alertas: {stats['alertas']}")
            print(f"  - IPs afectadas: {stats['ips_afectadas']}")
            print(f"  - % Eventos urgentes: {stats['porcentaje_urgentes']:.1f}%")
        
        print("="*60)
        
        return 0
        
    except Exception as e:
        print(f"❌ Error en deteccion de eventos: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


def comando_show_config(args) -> int:
    """
    Muestra la configuracion actual.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar config manager
        config_manager = get_config_manager(args.config)
        config = config_manager.get_config()
        
        print("📋 CONFIGURACION ACTUAL")
        print("="*50)
        
        if args.section == 'all':
            import json
            print(json.dumps(config, indent=2, ensure_ascii=False))
        else:
            section_data = config.get(args.section, {})
            if section_data:
                import json
                print(f"\n[{args.section}]")
                print(json.dumps(section_data, indent=2, ensure_ascii=False))
            else:
                print(f"❌ Seccion '{args.section}' no encontrada")
                return 1
        
        return 0
        
    except Exception as e:
        print(f"❌ Error mostrando configuracion: {e}")
        return 1


def comando_show_umbrales(args) -> int:
    """
    Muestra los umbrales de urgencia configurados.
    
    Args:
        args: Argumentos parseados
        
    Returns:
        int: Codigo de salida
    """
    try:
        # Inicializar servicios
        if args.config:
            get_config_manager(args.config)
        
        eventos_service = get_eventos_service()
        umbrales = eventos_service.obtener_umbrales_urgencia()
        
        print("⚡ UMBRALES DE URGENCIA CONFIGURADOS")
        print("="*50)
        
        for tipo, config in umbrales.items():
            print(f"\n🔸 {tipo.upper()}:")
            
            if tipo == "interferencia":
                for subtipo, valores in config.items():
                    print(f"  📡 {subtipo}:")
                    print(f"    - Alerta: ≤ {valores.get('alerta', 'N/A')}")
                    print(f"    - Alarma: ≤ {valores.get('alarma', 'N/A')}")
                    print(f"    - Min recurrencia (Alerta): {valores.get('recurrencia_alerta', 'N/A')}")
                    print(f"    - Min recurrencia (Alarma): {valores.get('recurrencia_alarma', 'N/A')}")
            else:
                print(f"  - Alerta: ≥ {config.get('alerta', 'N/A')}")
                print(f"  - Alarma: ≥ {config.get('alarma', 'N/A')}")
                print(f"  - Min recurrencia (Alerta): {config.get('recurrencia_alerta', 'N/A')}")
                print(f"  - Min recurrencia (Alarma): {config.get('recurrencia_alarma', 'N/A')}")
        
        print("="*50)
        
        return 0
        
    except Exception as e:
        print(f"❌ Error mostrando umbrales: {e}")
        return 1


def main():
    """Funcion principal del comando smartlink-eventos."""
    parser = crear_parser()
    args = parser.parse_args()
    
    # Si no se especifica comando, mostrar ayuda
    if not args.comando:
        parser.print_help()
        return 0
    
    # Ejecutar comando correspondiente
    if args.comando == 'detect':
        return comando_detect(args)
    elif args.comando == 'show-config':
        return comando_show_config(args)
    elif args.comando == 'show-umbrales':
        return comando_show_umbrales(args)
    else:
        print(f"❌ Comando desconocido: {args.comando}")
        return 1


if __name__ == "__main__":
    sys.exit(main())