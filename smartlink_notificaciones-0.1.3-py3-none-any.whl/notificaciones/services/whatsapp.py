# src/notificaciones/services/whatsapp.py
# -*- coding: utf-8 -*-

import os
import subprocess
from typing import List, Dict, Optional

from notificaciones.core.config import load_config
from notificaciones.core.ai import get_openai_client, mensaje_chat_gpt


THRESHOLD_CRITICO = 1.0  # % mínima de latencia alta para considerar "crítico"
MAX_CRITICOS = 5
MAX_MSG_LEN = 1200  # límite práctico para WhatsApp


def _norm_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


def _seleccionar_criticos(stats_equipos: List[Dict]) -> List[Dict]:
    """Filtra y ordena equipos críticos por % alta y, secundariamente, por >200ms."""
    candidatos = [
        e for e in (stats_equipos or [])
        if _norm_float(e.get("porcentaje_latencia_alta")) >= THRESHOLD_CRITICO
    ]
    candidatos.sort(
        key=lambda e: (
            _norm_float(e.get("porcentaje_latencia_alta")),
            _norm_float(e.get("latencia_mayor_200")),
            _norm_float(e.get("max_latencia")),
        ),
        reverse=True,
    )
    return candidatos[:MAX_CRITICOS]


def _resumen_global_lines(g: Dict) -> List[str]:
    """Devuelve líneas de resumen global ya formateadas."""
    lines = []
    map_keys = [
        ("total_ips", "IPs"),
        ("total_mediciones", "Mediciones"),
        ("total_mediciones_validas", "Válidas (>0)"),
        ("desconexiones", "Desconexiones"),
        ("promedio_general", "Promedio (ms)"),
        ("max_global", "Máximo (ms)"),
        ("min_global", "Mínimo (ms)"),
        ("mediciones_altas", ">100 ms"),
        ("porcentaje_latencia_alta", "% alta (sobre válidas)"),
    ]
    for key, label in map_keys:
        val = g.get(key)
        if val is None:
            continue
        try:
            if key in {"promedio_general", "max_global", "min_global"}:
                val = f"{float(val):.1f}"
            elif key == "porcentaje_latencia_alta":
                fval = float(val)
                val = "~0%" if (0 <= fval < 0.00001) else f"{fval:.2f}%"
        except Exception:
            pass
        lines.append(f"• {label}: {val}")
    return lines


def _fallback_text(empresa: str, stats_equipos: List[Dict], stats_global: Dict) -> str:
    """Mensaje determinista de respaldo (sin IA)."""
    Empresa = empresa.capitalize() if empresa else "Cliente"
    criticos = _seleccionar_criticos(stats_equipos)

    lines = [f"📊 Reporte del turno – {Empresa}"]

    if criticos:
        lines.append("⚠️ Se detectaron equipos con mayor % de latencia durante el turno:")
        for e in criticos:
            tag = e.get("tag") or ""
            ip = e.get("ip") or ""
            pct = _norm_float(e.get("porcentaje_latencia_alta"))
            pct_txt = "~0%" if (0 <= pct < 0.00001) else f"{pct:.2f}%"
            max_ms = e.get("max_latencia")
            prom = e.get("promedio_latencia")
            lat100_200 = int(_norm_float(e.get("latencia_100_200")))
            lat200 = int(_norm_float(e.get("latencia_mayor_200")))
            recurrencia = lat100_200 + lat200
            marca = e.get("marca") or ""
            lines.append(
                f"🔴 {tag} ({ip})\n"
                f"   • % alta: {pct_txt}\n"
                f"   • Máx: {max_ms} ms | Prom: {prom:.1f} ms\n"
                f"   • Recurrencia >100ms: {recurrencia}\n"
                f"   • Marca: {marca}"
    )

    else:
        lines.append("✅ No se detectaron equipos críticos. El rendimiento general fue adecuado, con algunos eventos puntuales.")


    # Resumen global al final
    lines.append("Resumen:")
    lines.extend(_resumen_global_lines(stats_global or {}))

    text = "\n".join(lines)
    if len(text) > MAX_MSG_LEN:
        text = text[: MAX_MSG_LEN - 3] + "..."
    return text


def _message_with_ai(
    empresa: str,
    stats_equipos: List[Dict],
    stats_global: Dict,
) -> str:
    """Genera el mensaje con IA; si falla, usa fallback determinista."""
    client = get_openai_client()
    if not client:
        return _fallback_text(empresa, stats_equipos, stats_global)

    Empresa = empresa.capitalize() if empresa else "Cliente"
    criticos = _seleccionar_criticos(stats_equipos)

    datos = {
        "empresa": Empresa,
        "criticos": criticos,        # ya filtrados por ≥1%
        "global": stats_global or {}, 
        "max_criticos": MAX_CRITICOS,
        "umbral_pct_alta": THRESHOLD_CRITICO,
    }

    prompt = (
        "Eres un asistente que redacta un reporte técnico breve para WhatsApp (máx 2000 caracteres), "
        "en español de Chile, dirigido a supervisores de una faena minera. Sé formal.\n"
        "Este reporte es generado por Smartlink, un software de HC-GROUP para monitoreo de equipos de telecomunicaciones "
        "en faenas mineras. El reporte corresponde al último turno. "
        "Los equipos que vas a analizar están desplegados en una faena minera en distintas ubicaciones.\n"
        "\n"
        "INSTRUCCIONES DE FORMATO (MUY IMPORTANTES):\n"
        f" - La primera línea debe ser exactamente: '📊 Reporte del turno – {Empresa}'.\n"
        " - A continuación haz un breve saludo indicando quien eres y que haras."
        " - Si hay equipos críticos (definidos abajo), agrega despues de la introducción: "
        "   '⚠️ Se detectaron equipos con mayor % de latencia durante el turno:' y luego lista "
        "   hasta 5 equipos como bloques con este formato (una o varias líneas por equipo):\n"
        "     '🔴 <Tag o IP> (<IP>)\\n"
        "        • % alta: <porcentaje>\\n"
        "        • Máx: <ms> | Prom: <ms>\\n"
        "        • Recurrencia >100ms: <suma_100_200_y_>200>\\n"
        "        • Marca: <marca>'\n"
        " - Si NO hay equipos críticos, escribe en su lugar: "
        "   '✅ No se detectaron equipos críticos. El rendimiento general fue adecuado, con algunos eventos puntuales.'\n"
        " - Al final agrega el bloque 'Resumen:' con viñetas '•' y estas métricas si están en el JSON: "
        "   IPs, Mediciones, Válidas (>0), Desconexiones, "
        "   'Promedio: <ms> | Máximo: <ms> | Mínimo: <ms>', '>100ms', y '% alta'.\n"
        " - NO uses tablas, ni URLs, ni bloques de código; solo texto con viñetas y saltos de línea.\n"
        " - No inventes datos: usa estrictamente lo que viene en el JSON.\n"
        " - HC-GROUP se escribe siempre en mayúscula, es un detalle importante así que tenlo en cuenta.\n"
        " - Despidete recomendando revisar el informe completo en el correo."
        "\n"
        "CRITERIOS PARA 'EQUIPOS CRÍTICOS':\n"
        f" - Considera crítico solo si el porcentaje de latencia alta es ≥ {THRESHOLD_CRITICO}.\n"
        " - 'Recurrencia >100ms' es la suma de 'latencia_100_200' + 'latencia_mayor_200'.\n"
        "\n"
        "REGLAS DE NUMERACIÓN:\n"
        " - Muestra el símbolo % en los porcentajes. Si el porcentaje es 0 o muy cercano a 0 (<0.00001), muestra '~0%'.\n"
        " - Redondea los milisegundos a 1 decimal cuando sea razonable.\n"
        " - Mantén el mensaje por debajo de 2000 caracteres; si te acercas al límite prioriza claridad.\n"
        "\n"
        "JSON DE ENTRADA (usa exactamente estos valores):\n"
        f"{datos}\n"
        "\n"
        "Devuelve SOLO el texto final del mensaje (sin markdown, sin ``` y sin títulos adicionales)."
    ).replace("{empresa}", Empresa)


    text = mensaje_chat_gpt(client, prompt, is_windows=False) or ""
    # Seguridad: si la IA se fue por las ramas, usa fallback
    if not text.strip():
        text = _fallback_text(empresa, stats_equipos, stats_global)

    if len(text) > MAX_MSG_LEN:
        text = text[: MAX_MSG_LEN - 3] + "..."
    return text


class WhatsAppService:
    """
    Servicio de envío por WhatsApp usando 'mudslide'.
    En config YAML, define:
      whatsapp:
        mudslide:
          groups:
            collahuasi: ["+56977566595", "120363027104819888@g.us"]
            test: ["+56XXXXXXXXX"]
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _groups(self, group_key: str) -> List[str]:
        groups = self.cfg.get("whatsapp.mudslide.groups", {})
        ids = groups.get(group_key, [])
        if not ids:
            raise ValueError(
                f"No hay destinatarios para whatsapp.mudslide.groups.{group_key}"
            )
        return ids

    def _send(self, mudslide_id: str, text: str, timeout: int = 60) -> bool:
        """
        Envía con el binario 'mudslide' (ya instalado en el sistema).
        Ejemplos válidos de mudslide_id:
          '+56977566595'  (número)
          '120363027104819888@g.us' (grupo)
        """
        cmd = f'/usr/local/bin/mudslide send "{mudslide_id}" "{text}"'
        try:
            res = subprocess.run(
                cmd,
                shell=True,
                check=True,
                capture_output=True,
                timeout=timeout,
                text=True,
            )
            if res.stdout:
                print(res.stdout.strip()[:400])
            print(f"✅ WhatsApp enviado a {mudslide_id}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ mudslide error -> {mudslide_id}\n{(e.stderr or e.stdout)[:400]}")
        except subprocess.TimeoutExpired:
            print(f"❌ Timeout enviando a {mudslide_id}")
        except Exception as e:
            print(f"❌ Error enviando a {mudslide_id}: {e}")
        return False

    def enviar_reporte(
        self,
        empresa: str,
        horas: int,  # no se usa en el texto (turno variable), pero lo dejamos para mantener firma
        stats_equipos: List[Dict],
        stats_global: Dict,
        group_key: str,
        timeout: int = 60,
    ) -> Dict[str, bool]:
        text = _message_with_ai(empresa, stats_equipos, stats_global)
        if len(text) > MAX_MSG_LEN:
            text = text[: MAX_MSG_LEN - 3] + "..."
        resultados: Dict[str, bool] = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados
