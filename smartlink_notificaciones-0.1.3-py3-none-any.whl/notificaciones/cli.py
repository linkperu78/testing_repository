#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import sys
from datetime import datetime, timedelta
from typing import Tuple

from notificaciones.core.config import load_config
from notificaciones.core.api import API
from notificaciones.services.mail import MailService
from notificaciones.services.whatsapp import WhatsAppService


def _date_range(hours_back: int) -> Tuple[str, str]:
    """Devuelve (start_iso, end_iso) en UTC para las últimas `hours_back` horas."""
    end_dt = datetime.utcnow()
    start_dt = end_dt - timedelta(hours=hours_back)
    to_iso = lambda dt: dt.strftime("%Y-%m-%dT%H:%M:%S")
    return to_iso(start_dt), to_iso(end_dt)


def run_once_mail(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    horas = args.hours or int(cfg.get("general.default_hours_back", 12))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")

    start_date, end_date = _date_range(horas)
    stats = api.get_stats(start_date, end_date)
    summary = api.get_stats_summary(start_date, end_date)

    if args.dry_run:
        print("🧪 DRY-RUN mail")
        print(f"Empresa: {empresa} | Horas: {horas} | Equipos: {len(stats) if stats else 0}")
        if isinstance(summary, dict):
            print(f"Resumen: {summary}")
        return 0

    ms = MailService(args.config)
    ok = ms.enviar_reporte(empresa, horas, stats, summary)
    return 0 if ok else 1


def run_once_whatsapp(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    horas = args.hours or int(cfg.get("general.default_hours_back", 8))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")
    group = args.group or "test"

    start_date, end_date = _date_range(horas)
    stats = api.get_stats(start_date, end_date)
    summary = api.get_stats_summary(start_date, end_date)

    if args.dry_run:
        print("🧪 DRY-RUN whatsapp")
        print(f"Empresa: {empresa} | Horas: {horas} | Grupo: {group} | Equipos: {len(stats) if stats else 0}")
        if isinstance(summary, dict):
            print(f"Resumen: {summary}")
        return 0

    ws = WhatsAppService(args.config)
    res = ws.enviar_reporte(empresa, horas, stats, summary, group_key=group, timeout=args.timeout)
    if not res:
        print("❌ No se envió ningún mensaje")
        return 1
    fails = [k for k, v in res.items() if not v]
    if fails:
        print(f"⚠️ Fallaron {len(fails)} destinatarios: {', '.join(fails)}")
    return 0


def run_loop(args) -> int:
    """
    Bucle simple para ejecutar cada N horas (por defecto 8).
    Recomendación prod: usar cron/systemd, esto es un MVP.
    """
    import time

    every_h = args.every_h or 8
    print(f"⏱️ Ejecutando cada {every_h} horas. Ctrl+C para salir.")
    while True:
        try:
            if args.mode == "mail":
                run_once_mail(args)
            else:
                run_once_whatsapp(args)
        except Exception as e:
            print(f"❌ Error en ejecución: {e}")
        time.sleep(every_h * 3600)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="smartlink-notificaciones",
        description="Envío de reportes Smartlink por correo y WhatsApp (últimas N horas).",
    )
    sub = p.add_subparsers(dest="cmd")

    # mail
    mail = sub.add_parser("mail", help="Enviar reporte por correo (una vez)")
    mail.add_argument("--empresa", help="Empresa (fallback al YAML)")
    mail.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    mail.add_argument("--config", help="Ruta a configNotificaciones.yml")
    mail.add_argument("--dry-run", action="store_true", help="Simular sin enviar")
    mail.set_defaults(func=run_once_mail)

    # whatsapp
    wa = sub.add_parser("whatsapp", help="Enviar reporte por WhatsApp (una vez)")
    wa.add_argument("--empresa", help="Empresa (fallback al YAML)")
    wa.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    wa.add_argument("--group", help="Clave del grupo en whatsapp.mudslide_groups (p.e. collahuasi/test)")
    wa.add_argument("--timeout", type=int, default=60, help="Timeout por envío (seg)")
    wa.add_argument("--config", help="Ruta a configNotificaciones.yml")
    wa.add_argument("--dry-run", action="store_true", help="Simular sin enviar")
    wa.set_defaults(func=run_once_whatsapp)

    # loop
    loop = sub.add_parser("loop", help="Bucle que envía cada N horas (default 8)")
    loop.add_argument("mode", choices=["mail", "whatsapp"], help="Qué enviar en el loop")
    loop.add_argument("--every-h", type=int, default=8, help="Cada cuántas horas ejecutar")
    loop.add_argument("--empresa", help="Empresa (fallback al YAML)")
    loop.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
    loop.add_argument("--group", help="(solo whatsapp) clave de grupo")
    loop.add_argument("--timeout", type=int, default=60, help="(solo whatsapp) timeout por envío")
    loop.add_argument("--config", help="Ruta a configNotificaciones.yml")
    loop.set_defaults(func=run_loop)

    # show-config
    show = sub.add_parser("show-config", help="Mostrar configuración efectiva")
    show.add_argument("--config", help="Ruta a configNotificaciones.yml")
    show.set_defaults(func=lambda a: (print(load_config(a.config).raw), 0)[1])

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
