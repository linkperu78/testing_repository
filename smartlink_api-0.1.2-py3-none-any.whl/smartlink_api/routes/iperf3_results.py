# routes/rajant_performance.py
from fastapi import APIRouter, Query, Path
from datetime import datetime
from typing import Optional, List

from smartlink_api.connection import get_db_connection
from smartlink_api.models.rajant_performance_model import rajant_performance as RajantPerformance
from smartlink_api.routes.__utils__ import (
    insert_data,
    insert_bulk_data,
    fetch_data_with_dates,
    fetch_data_with_filter_and_pagination,
)

router = APIRouter()

@router.post("/add")
async def add_rajant_perf(single_model: RajantPerformance):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return insert_data(conn, "rajant_performance", single_model)

@router.post("/add_list")
async def add_rajant_perf_list(list_model: List[RajantPerformance]):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return insert_bulk_data(conn, "rajant_performance", list_model, RajantPerformance.model_fields.keys())

@router.get("/get", summary="Obtener rajant_performance por fechas con paginación")
async def get_rajant_perf(
    start_date: Optional[datetime] = Query(None, description="Fecha inicio"),
    end_date: Optional[datetime] = Query(None, description="Fecha fin"),
    offset: int = Query(0, description="Offset"),
    limit: int = Query(1000, description="Limit"),
    round_dates: Optional[bool] = Query(False, description="Redondear fecha")
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_dates(conn, "rajant_performance", start_date, end_date, limit, offset, round_dates)

@router.get("/get_ip/{ip}", summary="Obtener rajant_performance por IP y fechas")
async def get_rajant_perf_by_ip(
    ip: str = Path(..., description="IP"),
    start_date: Optional[datetime] = Query(None, description="Fecha inicio"),
    end_date: Optional[datetime] = Query(None, description="Fecha fin"),
    offset: int = Query(0, description="Offset"),
    limit: int = Query(1000, description="Limit"),
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_filter_and_pagination(conn, "rajant_performance", "ip", ip, start_date, end_date, limit, offset)
