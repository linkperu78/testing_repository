from fastapi import APIRouter, HTTPException, Query, Path, Depends
from datetime import datetime
from typing import Optional, List
from smartlink_api.connection import get_db_connection
from mariadb import IntegrityError
import json

from smartlink_api.models.predicciones_models import Predicciones
from smartlink_api.routes.__utils__ import insert_data, insert_bulk_data, fetch_data_with_dates, fetch_data_with_filter_and_pagination

router = APIRouter()

@router.post("/add")
async def add_prediccion(prediccion: Predicciones):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return insert_data(conn, "predicciones", prediccion)

@router.post("/add_list")
async def add_prediccion_list(list_model: List[Predicciones]):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return insert_bulk_data(conn, "predicciones", list_model, Predicciones.model_fields.keys())

@router.get("/get", summary="Obtener datos de predicciones de la base de datos por rangos de tiempo y con paginación")
async def get_prediccion(
    start_date: Optional[datetime] = Query(None, description="Fecha de inicio de la consulta"),
    end_date: Optional[datetime] = Query(None, description="Fecha de fin de la consulta"),
    offset: int = Query(0, description="Número de registros a omitir"),
    limit: int = Query(1000, description="Número de registros a mostrar")
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_dates(conn, "predicciones", start_date, end_date, limit, offset)

@router.get("/get_ip/{ip}", summary="Obtener datos de predicciones de la base de datos por IP, por rangos de tiempo y con paginación")
async def get_prediccion_by_ip(
    ip: str = Path(..., description="Dirección IP a filtrar"),
    start_date: Optional[datetime] = Query(None, description="Fecha de inicio de la consulta"),
    end_date: Optional[datetime] = Query(None, description="Fecha de fin de la consulta"),
    offset: int = Query(0, description="Número de registros a omitir"),
    limit: int = Query(1000, description="Número de registros a mostrar")
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        return fetch_data_with_filter_and_pagination(conn, "predicciones", "ip", ip, start_date, end_date, limit, offset)
    

@router.get("/get_data/{marca}", summary="Obtener datos de los valores de la base de datos por marca, por rangos de tiempo y con paginación. La idea es que estos datos se usen para predicciones forecast")
async def get_prediccion_by_marca(
    marca: str = Path(..., description="Marca a filtrar"),
    start_date: Optional[datetime] = Query(None, description="Fecha de inicio de la consulta"),
    end_date: Optional[datetime] = Query(None, description="Fecha de fin de la consulta"),
    offset: int = Query(0, description="Número de registros a omitir"),
    limit: int = Query(1000, description="Número de registros a mostrar")
):
    conn_dep = get_db_connection("smartlink")
    async with conn_dep as conn:
        try:
            cursor = conn.cursor()
            params = []
            if marca == "cambium":
                query = """
                    SELECT c.ip, c.fecha, i.marca, i.tipo, i.rol, i.snmp_conf, i.anotacion, i.gps, c.snr, c.link_radio
                    FROM cambium_data AS c
                    LEFT JOIN inventario AS i
                    ON c.ip = i.ip
                    WHERE 1=1
                """
                if start_date:
                    query += "AND fecha >= %s "
                    params.append(start_date)
                if end_date:
                    query += "AND fecha <= %s "
                    params.append(end_date)
                query += "ORDER BY fecha DESC LIMIT %s OFFSET %s"
                params.extend([limit, offset])

                cursor.execute(query, tuple(params))
                columnas = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()

                results = []
                for row in rows:
                    row_dict = dict(zip(columnas, row))
                    raw_snr = row_dict.get("snr")
                    snr_dict = None
                    if isinstance(raw_snr, str):
                        try:
                            snr_dict = json.loads(raw_snr)
                        except json.JSONDecodeError:
                            return {"error": "Error al decodificar JSON"}
                    elif isinstance(raw_snr, dict):
                        snr_dict = raw_snr
                    if snr_dict:
                        snr_h = snr_dict.get("H")
                        snr_v = snr_dict.get("V")

                    raw_link_radio = row_dict.get("link_radio")
                    link_radio_dict = None
                    if isinstance(raw_link_radio, str):
                        try:
                            link_radio_dict = json.loads(raw_link_radio)
                        except json.JSONDecodeError:
                            return {"error": "Error al decodificar JSON"}
                    elif isinstance(raw_link_radio, dict):
                        link_radio_dict = raw_link_radio
                    if link_radio_dict:
                        link_radio_rx = link_radio_dict.get("rx")

                    data = {
                        "ip": row_dict["ip"],
                        "fecha": row_dict["fecha"],
                        "marca": row_dict["marca"],
                        "tipo": row_dict["tipo"],
                        "rol": row_dict["rol"],
                        "snmp_conf": row_dict["snmp_conf"],
                        "anotacion": row_dict["anotacion"],
                        "gps": row_dict["gps"],
                        "snr": row_dict["snr"],
                        "link_radio": row_dict["link_radio"],
                        "snr_h": snr_h,
                        "snr_v": snr_v,
                        "rx": link_radio_rx
                    }
                    results.append(data)

                return results
            if marca == "mimosa":
                query = """
                    SELECT m.ip, m.fecha, i.marca, i.tipo, i.rol, i.snmp_conf, i.anotacion, i.gps, m.network,
                    FROM mimosa_data AS m
                    LEFT JOIN inventario AS i
                    ON m.ip = i.ip
                    WHERE 1=1
                """
                if start_date:
                    query += "AND fecha >= %s "
                    params.append(start_date)
                if end_date:
                    query += "AND fecha <= %s "
                    params.append(end_date)
                query += "ORDER BY fecha DESC LIMIT %s OFFSET %s"
                params.extend([limit, offset])

                cursor.execute(query, tuple(params))
                columnas = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()

                results = []
                for row in rows:
                    row_dict = dict(zip(columnas, row))
                    tipo = row_dict.get("tipo")
                    if tipo == "PMP-SM":
                        posicion_snr = 3
                    elif tipo == "PMP-AP":
                        posicion_snr = 5
                    else:
                        posicion_snr = 0

                    raw_snr = row_dict.get("network")
                    snr_dict = None
                    if isinstance(raw_snr, str):
                        try:
                            snr_dict = json.loads(raw_snr)
                        except json.JSONDecodeError:
                            return {"error": "Error al decodificar JSON"}
                    elif isinstance(raw_snr, dict):
                        snr_dict = raw_snr
                    if snr_dict:
                        snr_h = snr_dict.get("H")[posicion_snr]
                        snr_v = snr_dict.get("V")[posicion_snr]
                    data = {
                        "ip": row_dict["ip"],
                        "fecha": row_dict["fecha"],
                        "marca": row_dict["marca"],
                        "tipo": row_dict["tipo"],
                        "rol": row_dict["rol"],
                        "snmp_conf": row_dict["snmp_conf"],
                        "anotacion": row_dict["anotacion"],
                        "gps": row_dict["gps"],
                        "network": row_dict["network"],
                        "snr_h": snr_h,
                        "snr_v": snr_v,
                    }
                    results.append(data)

                return results
            
        except IntegrityError as e:
            return {"error": str(e)}
