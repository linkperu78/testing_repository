from fastapi import APIRouter, Request, HTTPException, Depends
from datetime import datetime, timedelta
from smartlink_api.connection import get_db_connection
from typing import Optional
from mariadb import IntegrityError
import json

from smartlink_api.routes.__utils__ import insert_data, fetch_data
from smartlink_api.models.rol_gestor_tareas_models import Rol

router = APIRouter()

@router.post("/add")
async def add_gestor(rol: Rol):
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        return insert_data(conn, "rol_users", rol)
    
@router.get("/get")
async def get_roles_gestor():
    conn_dep = get_db_connection("gestor_tareas")
    async with conn_dep as conn:
        return fetch_data(conn, "rol_users")