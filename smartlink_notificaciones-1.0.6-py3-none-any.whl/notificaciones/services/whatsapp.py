# src/notificaciones/services/whatsapp.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import subprocess
from typing import List, Dict, Optional

from notificaciones.core.config import load_config

DEFAULT_THRESHOLD_CRITICO = 10.0
MAX_CRITICOS = 5
MAX_MSG_LEN = 1200
MUDSLIDE_BIN = "/usr/local/bin/mudslide"

# -------------------- mapeos por métrica --------------------

METRIC_LABEL = {
    "latencia": "Latencia",
    "snr_h": "SNR-H",
    "snr_v": "SNR-V",
    "rx": "RX",
}

METRIC_UNITS = {
    "latencia": "ms",
    "snr_h": "dB",
    "snr_v": "dB",
    "rx": "dBm",
}

def _metric_fields(metric: str) -> Dict[str, str]:
    """
    NOMBRES DE CAMPOS HARD-CODEADOS tal como los entrega tu API actual.
    """
    if metric == "latencia":
        return {
            "avg": "promedio_latencia",
            "max": "max_latencia",
            "min": "min_latencia",
            "obs": "latencia_100_200",      # recuento 100–200 ms
            "crit": "latencia_mayor_200",   # recuento >200 ms
            "valid": "total_mediciones",
            "pct": "porcentaje_latencia_alta",  # si viene, úsalo directo
        }
    if metric == "snr_h":
        return {
            "avg": "promedio_h",
            "max": "max_h",
            "min": "min_h",
            "obs": "total_alertas_h",
            "crit": "total_alarmas_h",
            "valid": "total_mediciones",
        }
    if metric == "snr_v":
        return {
            "avg": "promedio_v",
            "max": "max_v",
            "min": "min_v",
            "obs": "total_alertas_v",
            "crit": "total_alarmas_v",
            "valid": "total_mediciones",
        }
    if metric == "rx":
        return {
            "avg": "promedio_rx",
            "max": "max_rx",
            "min": "min_rx",
            "obs": "total_alertas_rx",
            "crit": "total_alarmas_rx",
            "valid": "total_mediciones",
        }
    return {}

# -------------------- helpers numéricos y umbrales --------------------

def _fnum(x, dflt: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return dflt

def _threshold_for_metric(thresholds: Dict[str, float], metric: str) -> float:
    """
    Prioridad del umbral (% problemático mínimo):
      1) thresholds[f"threshold_pct_{metric}"]
      2) thresholds[metric]
      3) DEFAULT_THRESHOLD_CRITICO
    """
    key1 = f"threshold_pct_{metric}"
    if key1 in thresholds:
        return _fnum(thresholds.get(key1), DEFAULT_THRESHOLD_CRITICO)
    if metric in thresholds:
        return _fnum(thresholds.get(metric), DEFAULT_THRESHOLD_CRITICO)
    return DEFAULT_THRESHOLD_CRITICO

def _problematic_pct(metric: str, row: Dict, mode: str) -> float:
    """
    % problemático por fila.
    - Latencia: usa 'porcentaje_latencia_alta' si viene; si no, (obs+crit)/valid * 100.
    - SNR/RX: (obs+crit)/valid * 100. Si mode == "critical_only": solo 'crit'.
    """
    f = _metric_fields(metric)

    if metric == "latencia":
        # Si ya viene el porcentaje, úsalo
        pct_field = f.get("pct")
        if pct_field and row.get(pct_field) is not None:
            return _fnum(row.get(pct_field), 0.0)

        # Fallback: calcular
        valid = _fnum(row.get(f.get("valid"), 0.0))
        if valid <= 0:
            return 0.0
        obs = _fnum(row.get(f.get("obs"), 0.0))
        crit = _fnum(row.get(f.get("crit"), 0.0))
        return (obs + crit) * 100.0 / valid

    # SNR/RX
    valid = _fnum(row.get(f.get("valid"), 0.0))
    if valid <= 0:
        return 0.0
    obs = _fnum(row.get(f.get("obs"), 0.0))
    crit = _fnum(row.get(f.get("crit"), 0.0))
    num = crit if mode == "critical_only" else (obs + crit)
    return (num * 100.0) / valid

def _severity_key(metric: str, row: Dict) -> float:
    """
    Tie-break del ranking:
      - Latencia: mayor promedio = peor
      - SNR: menor promedio (dB) = peor  -> usamos -avg
      - RX: más negativo (promedio más bajo) = peor -> usamos -avg
    """
    f = _metric_fields(metric)
    avg = _fnum(row.get(f.get("avg")))
    if metric == "latencia":
        return avg
    if metric in ("snr_h", "snr_v", "rx"):
        return -avg
    return 0.0

# -------------------- selección por métrica (hasta 5 por métrica) --------------------

def _per_metric_problematic(
    stats_by_metric: Dict[str, List[Dict]],
    metrics: List[str],
    thresholds: Dict[str, float],
    mode_problematic: str,
    per_metric_limit: int = MAX_CRITICOS,
) -> Dict[str, List[Dict]]:
    """
    Devuelve {metric: [rows...]} con HASTA 'per_metric_limit' filas por métrica
    que superen su umbral correspondiente.
    """
    result: Dict[str, List[Dict]] = {}
    for m in metrics:
        rows = stats_by_metric.get(m) or []
        th = _threshold_for_metric(thresholds, m)

        # filtra por % problemático
        selected: List[Dict] = []
        for r in rows:
            pct = _problematic_pct(m, r, mode_problematic)
            if pct >= th:
                rr = dict(r)
                rr["_pct_problematico"] = pct  # para ordenar
                selected.append(rr)

        if not selected:
            result[m] = []
            continue

        selected.sort(key=lambda rr: (rr["_pct_problematico"], _severity_key(m, rr)), reverse=True)
        result[m] = selected[:per_metric_limit]
    return result

# -------------------- render del mensaje --------------------

def _join_labels(metrics: List[str]) -> str:
    labels = [METRIC_LABEL.get(m, m) for m in metrics]
    if not labels:
        return ""
    if len(labels) == 1:
        return labels[0]
    # "A, B y C"
    return ", ".join(labels[:-1]) + " y " + labels[-1]

def _render_whatsapp_text(empresa: str, per_metric_rows: Dict[str, List[Dict]], metrics: List[str]) -> str:
    Empresa = (empresa or "Cliente").capitalize()
    header = f"📊 Reporte del turno – {Empresa}"

    # ¿hay filas en alguna métrica?
    any_rows = any(per_metric_rows.get(m) for m in metrics)
    if not any_rows:
        labels = _join_labels(metrics)
        body = f"✅ Equipos con {labels} dentro del rango estándar Operacional."
        txt = f"{header}\n{body}"
        return txt[: MAX_MSG_LEN - 3] + "..." if len(txt) > MAX_MSG_LEN else txt

    lines = [header, "⚠️ Equipos con condiciones a observar:"]
    for m in metrics:
        rows = per_metric_rows.get(m) or []
        if not rows:
            continue
        label = METRIC_LABEL.get(m, m)
        units = METRIC_UNITS.get(m, "")
        f = _metric_fields(m)

        # título por métrica
        lines.append(f"— {label}:")
        for r in rows:
            tag  = r.get("tag") or r.get("ip") or ""
            ip   = r.get("ip") or ""
            mx   = _fnum(r.get(f.get("max")))
            pr   = _fnum(r.get(f.get("avg")))
            # Mensaje compacto (sin marca/tipo para mantenerlo breve)
            lines.append(f"• {tag} ({ip}) — Máx: {mx:.1f} {units} | Prom: {pr:.1f} {units}")

    txt = "\n".join(lines)
    return txt[: MAX_MSG_LEN - 3] + "..." if len(txt) > MAX_MSG_LEN else txt

# -------------------- Servicio WhatsApp (multi-métrica) --------------------

class WhatsAppService:
    """
    En config YAML:
      whatsapp:
        mudslide:
          groups:
            collahuasi: ["+56977566595", "120363027104819888@g.us"]
            test: ["+56977566595"]
    """

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def _groups(self, group_key: str) -> List[str]:
        groups = self.cfg.get("whatsapp.mudslide.groups", {})
        ids = groups.get(group_key, [])
        if not ids:
            raise ValueError(f"No hay destinatarios para whatsapp.mudslide.groups.{group_key}")
        return ids

    def _send(self, mudslide_id: str, text: str, timeout: int = 60) -> bool:
        cmd = f'{MUDSLIDE_BIN} send "{mudslide_id}" "{text}"'
        try:
            res = subprocess.run(cmd, shell=True, check=True, capture_output=True, timeout=timeout, text=True)
            if res.stdout:
                print(res.stdout.strip()[:400])
            print(f"✅ WhatsApp enviado a {mudslide_id}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ mudslide error -> {mudslide_id}\n{(e.stderr or e.stdout)[:400]}")
        except subprocess.TimeoutExpired:
            print(f"❌ Timeout enviando a {mudslide_id}")
        except Exception as e:
            print(f"❌ Error enviando a {mudslide_id}: {e}")
        return False

    # FULL y NORMAL no difieren en WhatsApp (no hay tablas).
    # Implementamos ambas por compatibilidad con el CLI.

    def enviar_reporte_simple_multi(
        self,
        empresa: str,
        horas: int,  # no usado
        stats_by_metric: Dict[str, List[Dict]],
        metrics: List[str],
        thresholds: Dict[str, float],
        mode_problematic: str,
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,  # ignorado (determinista)
    ) -> Dict[str, bool]:
        per_metric = _per_metric_problematic(
            stats_by_metric, metrics, thresholds, mode_problematic, per_metric_limit=MAX_CRITICOS
        )
        text = _render_whatsapp_text(empresa, per_metric, metrics)
        resultados: Dict[str, bool] = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados

    def enviar_reporte_multi(
        self,
        empresa: str,
        horas: int,  # no usado
        stats_by_metric: Dict[str, List[Dict]],
        metrics: List[str],
        thresholds: Dict[str, float],
        mode_problematic: str,
        group_key: str,
        timeout: int = 60,
        prompt_path: Optional[str] = None,  # ignorado (determinista)
    ) -> Dict[str, bool]:
        # mismo contenido que simple (WhatsApp no tiene tablas)
        per_metric = _per_metric_problematic(
            stats_by_metric, metrics, thresholds, mode_problematic, per_metric_limit=MAX_CRITICOS
        )
        text = _render_whatsapp_text(empresa, per_metric, metrics)
        resultados: Dict[str, bool] = {}
        for ms_id in self._groups(group_key):
            resultados[ms_id] = self._send(ms_id, text, timeout=timeout)
        return resultados
