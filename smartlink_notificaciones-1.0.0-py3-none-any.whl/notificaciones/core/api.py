# src/notificaciones/core/api.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

import requests

from notificaciones.core.config import load_config


class API:
    """
    Capa simple de acceso HTTP a la API backend.
    - Lee base_url y endpoints del YAML (con varios fallbacks).
    - Retorna siempre listas de dicts (datos crudos del backend).
    """

    def __init__(self, config_path: Optional[str] = None) -> None:
        self.cfg = load_config(config_path)

        # base_url: soporta claves históricas y nuevas
        self.base_url: str = (
            self.cfg.get("api.base_url")
            or self.cfg.get("database.api_url")
            or "http://localhost:8000"
        ).rstrip("/")

        # timeouts y retries
        self.timeout: int = int(self.cfg.get("database.timeout", 30))
        self.retries: int = int(self.cfg.get("database.retry_attempts", 3))

        # Endpoints por métrica (con varios posibles nombres de clave)
        self.ep_latencia = self._endpoint(
            [
                "api.latencia.get_latencia_stats",
                "api.latencia.stats",
                "api.latencia.get",  # legacy
                "api.latencia",      # si viene directo
            ],
            default="/get_latencia_stats",
        )
        self.ep_snr_h = self._endpoint(
            [
                "api.snr_h.get_stats",
                "api.snr_h.stats",
                "api.snr_h.get",
                "api.snr_h",
                "api.snrh.get_stats",  # por si acaso
            ],
            default="/get_snr_h_stats",
        )
        self.ep_snr_v = self._endpoint(
            [
                "api.snr_v.get_stats",
                "api.snr_v.stats",
                "api.snr_v.get",
                "api.snr_v",
                "api.snrv.get_stats",  # por si acaso
            ],
            default="/get_snr_v_stats",
        )
        self.ep_rx = self._endpoint(
            [
                "api.rx.get_stats",
                "api.rx.stats",
                "api.rx.get",
                "api.rx",
            ],
            default="/get_rx_stats",
        )

    # --------------------------- públicos (métricas) ---------------------------

    def get_latencia_stats(
        self,
        start_date: str,
        end_date: str,
        *,
        offset: int = 0,
        limit: int = 10_000,
        aprox_date: Optional[bool] = None,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Espera que el backend devuelva por IP (y opcionalmente tag, marca, tipo):
          - max_latencia, promedio_latencia, min_latencia
          - latencia_100_200, latencia_mayor_200
          - porcentaje_latencia_alta, desconexiones
        """
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "offset": offset,
            "limit": limit,
        }
        if aprox_date is not None:
            params["aprox_date"] = bool(aprox_date)
        if extra_params:
            params.update(extra_params)
        url = self._join(self.ep_latencia)
        return self._get_list(url, params)

    def get_snr_h_stats(
        self,
        start_date: str,
        end_date: str,
        *,
        offset: int = 0,
        limit: int = 10_000,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        SNR-H (dB). Campos esperados (o similares según tu backend):
          - promedio_snr_h, max_snr_h, min_snr_h
          - count_observe (16-19.99), count_critical (0-15.99)
          - count_valid / count_total
          - tag, ip, marca, tipo
        """
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "offset": offset,
            "limit": limit,
        }
        if extra_params:
            params.update(extra_params)
        url = self._join(self.ep_snr_h)
        return self._get_list(url, params)

    def get_snr_v_stats(
        self,
        start_date: str,
        end_date: str,
        *,
        offset: int = 0,
        limit: int = 10_000,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        SNR-V (dB). Campos esperados (o similares):
          - promedio_snr_v, max_snr_v, min_snr_v
          - count_observe, count_critical, count_valid / count_total
          - tag, ip, marca, tipo
        """
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "offset": offset,
            "limit": limit,
        }
        if extra_params:
            params.update(extra_params)
        url = self._join(self.ep_snr_v)
        return self._get_list(url, params)

    def get_rx_stats(
        self,
        start_date: str,
        end_date: str,
        *,
        offset: int = 0,
        limit: int = 10_000,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        RX (dBm). Campos esperados (o similares):
          - promedio_rx, max_rx, min_rx
          - count_observe (-80..-70), count_critical (-90..-80), count_valid / count_total
          - tag, ip, marca, tipo
        """
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "offset": offset,
            "limit": limit,
        }
        if extra_params:
            params.update(extra_params)
        url = self._join(self.ep_rx)
        return self._get_list(url, params)

    # --------------------------- helpers internos ------------------------------

    def _endpoint(self, keys: List[str], default: str) -> str:
        """
        Busca la primera clave existente en el YAML y la devuelve,
        fallback al valor por defecto. Acepta valores con o sin '/' inicial.
        """
        for k in keys:
            v = self.cfg.get(k)
            if isinstance(v, str) and v.strip():
                v = v.strip()
                return v if v.startswith("/") else f"/{v}"
        return default if default.startswith("/") else f"/{default}"

    def _join(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _get_list(self, url: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        GET con reintentos. Si la respuesta tiene {'data': [...]}, retorna 'data'.
        Si la respuesta ya es una lista, la devuelve tal cual.
        """
        last_err: Optional[Exception] = None
        for attempt in range(1, self.retries + 1):
            try:
                r = requests.get(url, params=params, timeout=self.timeout)
                r.raise_for_status()
                js = r.json()
                if isinstance(js, dict) and "data" in js and isinstance(js["data"], list):
                    return js["data"]
                if isinstance(js, list):
                    return js
                # Si viene en otra envoltura, intenta encontrar una lista
                for k in ("results", "items", "rows"):
                    v = js.get(k) if isinstance(js, dict) else None
                    if isinstance(v, list):
                        return v
                # Caso no reconocido, devuelve vacío pero loguea una pista
                print(f"⚠️ Respuesta sin lista clara desde {url}. Claves: {list(js) if isinstance(js, dict) else type(js)}")
                return []
            except Exception as e:
                last_err = e
                if attempt < self.retries:
                    time.sleep(min(2 * attempt, 6))  # backoff simple
                else:
                    print(f"❌ Error consultando {url}: {e}")
        return []
