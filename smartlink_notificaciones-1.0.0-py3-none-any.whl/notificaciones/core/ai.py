# src/notificaciones/core/api.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import requests
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin

from notificaciones.core.config import load_config


def _ensure_list_from_api(resp_json: Any) -> List[Dict[str, Any]]:
    """
    Algunas APIs devuelven {"data": [...]}, otras un [] directo.
    Normalizamos a list[dict].
    """
    if resp_json is None:
        return []
    if isinstance(resp_json, dict):
        if "data" in resp_json and isinstance(resp_json["data"], list):
            return resp_json["data"]
        # por compatibilidad, si no hay 'data' pero es dict, no rompemos:
        # puede haber otras claves; intentamos descubrir un array usable
        for v in resp_json.values():
            if isinstance(v, list):
                return v
        return []
    if isinstance(resp_json, list):
        return resp_json
    return []


class API:
    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)
        self.base_url: str = str(self.cfg.get("api.base_url", "")).rstrip("/")
        self.timeout: int = int(self.cfg.get("general.timeout", 30))
        self.session = requests.Session()
        self.session.headers.update({"accept": "application/json"})

    # --------------------- HTTP helper ---------------------

    def _get(self, path_or_url: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """
        Realiza GET a base_url + path (si no viene URL completa).
        """
        if not path_or_url:
            return None
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            url = path_or_url
        else:
            # asegura "/" intermedio correctamente
            url = urljoin(self.base_url + "/", path_or_url.lstrip("/"))

        try:
            r = self.session.get(url, params=params or {}, timeout=self.timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            print(f"❌ GET {url} -> {e}")
            return None

    # --------------------- Latencia ---------------------

    def get_stats(
        self,
        start_date: str,
        end_date: str,
        limit: int = 1000,
        offset: int = 0,
        aprox_date: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Llama a api.latencia.get_latencia_stats.
        YAML (ejemplo):
          api:
            latencia:
              get_latencia_stats: "/latencia/get_latencia_stats"
        """
        path = self.cfg.get("api.latencia.get_latencia_stats", "/latencia/get_latencia_stats")
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
            "offset": offset,
            "aprox_date": "true" if aprox_date else "false",
        }
        data = self._get(path, params=params)
        return _ensure_list_from_api(data)

    # --------------------- Cambium SNR-H ---------------------

    def get_stats_snr_h(
        self,
        start_date: str,
        end_date: str,
        limit_rows: int = 200000,
    ) -> List[Dict[str, Any]]:
        """
        Llama a api.snr_h.get_stats.
        En tu YAML ya viene con query fija:
          "/cambium_data/get_metric_stats_by_ip?column=snr&metric=h"
        Solo añadimos start_date, end_date, (y opcionalmente limit_rows).
        """
        path = self.cfg.get("api.snr_h.get_stats", "/cambium_data/get_metric_stats_by_ip?column=snr&metric=h")
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit_rows": limit_rows,
        }
        data = self._get(path, params=params)
        return _ensure_list_from_api(data)

    # --------------------- Cambium SNR-V ---------------------

    def get_stats_snr_v(
        self,
        start_date: str,
        end_date: str,
        limit_rows: int = 200000,
    ) -> List[Dict[str, Any]]:
        """
        Llama a api.snr_v.get_stats.
          "/cambium_data/get_metric_stats_by_ip?column=snr&metric=v"
        """
        path = self.cfg.get("api.snr_v.get_stats", "/cambium_data/get_metric_stats_by_ip?column=snr&metric=v")
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit_rows": limit_rows,
        }
        data = self._get(path, params=params)
        return _ensure_list_from_api(data)

    # --------------------- Cambium RX ---------------------

    def get_stats_rx(
        self,
        start_date: str,
        end_date: str,
        limit_rows: int = 200000,
    ) -> List[Dict[str, Any]]:
        """
        Llama a api.rx.get_stats.
          "/cambium_data/get_metric_stats_by_ip?column=link_radio&metric=rx"
        """
        path = self.cfg.get("api.rx.get_stats", "/cambium_data/get_metric_stats_by_ip?column=link_radio&metric=rx")
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "limit_rows": limit_rows,
        }
        data = self._get(path, params=params)
        return _ensure_list_from_api(data)
