# src/notificaciones/core/ai.py
# -*- coding: utf-8 -*-
"""
Helpers para usar OpenAI de forma opcional.
- Lee .env si existe (OPENAI_API_KEY u OPEN_API_KEY).
- Si no hay API key o la lib openai no está instalada, devuelve None / texto fallback.
"""

from __future__ import annotations

import os
from typing import Optional

try:
    # openai >= 1.0
    from openai import OpenAI  # type: ignore
except Exception:
    OpenAI = None  # type: ignore

try:
    # Cargar variables desde .env si existe
    from dotenv import load_dotenv  # type: ignore
    _ = load_dotenv()
except Exception:
    pass


def _get_api_key() -> Optional[str]:
    """
    Intenta varias variables conocidas.
    """
    for k in ("OPENAI_API_KEY", "OPEN_API_KEY", "OPENAI_KEY"):
        v = os.getenv(k)
        if v and v.strip():
            return v.strip()
    return None


def get_openai_client() -> Optional["OpenAI"]:
    """
    Devuelve un cliente de OpenAI o None si:
    - no hay API key
    - no está instalada la librería openai >= 1.0
    """
    api_key = _get_api_key()
    if not api_key:
        print("▲ Falta OPENAI_API_KEY/OPEN_API_KEY en .env o entorno.")
        return None
    if OpenAI is None:
        print("▲ Librería 'openai' no disponible. Instala openai>=1.0.")
        return None
    try:
        client = OpenAI(api_key=api_key)
        return client
    except Exception as e:
        print(f"▲ No se pudo inicializar OpenAI: {e}")
        return None


def mensaje_chat_gpt(
    client: Optional["OpenAI"],
    prompt: str,
    model: str = "gpt-4o-mini",
    is_windows: bool = False,
    temperature: float = 0.2,
    max_tokens: int = 600,
) -> str:
    """
    Llama a chat.completions si hay cliente; de lo contrario, retorna el prompt
    (o un breve fallback) para no romper el flujo.
    """
    if client is None:
        # Fallback determinista: no interrumpe el envío si no hay IA.
        print("▲ Sin cliente OpenAI: usando mensaje generado localmente.")
        return prompt[:max_tokens]

    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        text = resp.choices[0].message.content or ""
        if is_windows:
            text = text.replace("\n", "\\n")
        return text.strip()
    except Exception as e:
        print(f"▲ Error generando mensaje con OpenAI: {e}")
        # Devolvemos el prompt truncado como último recurso.
        return prompt[:max_tokens].strip()
