# src/notificaciones/core/ai.py
# -*- coding: utf-8 -*-

import os
import re
from typing import Optional

try:
    from dotenv import load_dotenv  # optional
except Exception:
    load_dotenv = None

try:
    # SDK oficial OpenAI >= 1.0
    from openai import OpenAI
except Exception:
    OpenAI = None


DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


def _load_env_once() -> None:
    """
    Carga .env desde el directorio actual si está disponible.
    No falla si no existe ni si falta python-dotenv.
    """
    if load_dotenv is not None:
        try:
            load_dotenv(override=False)
        except Exception:
            pass


def get_openai_client() -> Optional["OpenAI"]:
    """
    Devuelve el cliente de OpenAI o None si:
      - No está instalado el SDK
      - Falta OPENAI_API_KEY
    """
    _load_env_once()

    if OpenAI is None:
        print("ℹ️ openai SDK no disponible; IA desactivada.")
        return None

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("ℹ️ Falta OPENAI_API_KEY en entorno/.env; IA desactivada.")
        return None

    try:
        client = OpenAI(api_key=api_key)
        return client
    except Exception as e:
        print(f"ℹ️ No fue posible inicializar OpenAI: {e}")
        return None


_FENCE_RE = re.compile(r"```(?:html|HTML)?|```", re.MULTILINE)


def _sanitize(text: str) -> str:
    """
    Quita fences de markdown y espacios raros.
    """
    if not text:
        return ""
    s = _FENCE_RE.sub("", text).strip()
    # Normaliza espacios pegados a saltos de línea
    s = re.sub(r"[ \t]+\n", "\n", s)
    return s.strip()


def mensaje_chat_gpt(
    client: "OpenAI",
    prompt: str,
    *,
    model: Optional[str] = None,
    system: Optional[str] = None,
    temperature: float = 0.2,
    max_tokens: int = 600,
    char_limit: Optional[int] = None,
    is_windows: bool = False,
) -> str:
    """
    Solicita una completación de chat a OpenAI y devuelve el texto limpio.
    - char_limit: recorta la salida a ese número de caracteres (útil para WhatsApp).
    - is_windows: reemplaza '\n' por '\\n'.
    """
    if client is None:
        return ""

    mdl = model or DEFAULT_MODEL
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    try:
        resp = client.chat.completions.create(
            model=mdl,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        text = resp.choices[0].message.content or ""
    except Exception as e:
        print(f"ℹ️ Error en llamada a OpenAI: {e}")
        return ""

    text = _sanitize(text)

    if char_limit and char_limit > 0 and len(text) > char_limit:
        text = text[: char_limit - 3] + "..."

    if is_windows:
        text = text.replace("\n", "\\n")

    return text
