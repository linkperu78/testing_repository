#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import sys
from datetime import datetime, timedelta
from typing import Tuple, Dict, List, Optional

from notificaciones.core.config import load_config
from notificaciones.core.api import API
from notificaciones.services.mail import MailService
from notificaciones.services.whatsapp import WhatsAppService


DEFAULT_METRICS = ["latencia", "snr_h", "snr_v", "rx"]


def _date_range(hours_back: int) -> Tuple[str, str]:
    """Devuelve (start_iso, end_iso) en UTC para las últimas `hours_back` horas."""
    end_dt = datetime.utcnow()
    start_dt = end_dt - timedelta(hours=hours_back)
    to_iso = lambda dt: dt.strftime("%Y-%m-%dT%H:%M:%S")
    return to_iso(start_dt), to_iso(end_dt)


def _parse_metric_list(arg: Optional[List[str] | str]) -> List[str]:
    """
    Acepta:
      --metric [rx, snr_h]
      --metric rx snr_h
      --metric "rx,snr_h"
    Normaliza a lista en minúsculas, sin espacios.
    """
    if not arg:
        return DEFAULT_METRICS.copy()

    # argparse puede dar lista (nargs='+') o un string
    if isinstance(arg, list):
        tokens: List[str] = []
        for x in arg:
            if x is None:
                continue
            s = str(x).strip()
            if s.startswith("[") and s.endswith("]"):
                s = s[1:-1]
            for t in s.split(","):
                t2 = t.strip().lower()
                if t2:
                    tokens.append(t2)
        return tokens or DEFAULT_METRICS.copy()

    # string
    s = str(arg).strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    tokens = [t.strip().lower() for t in s.split(",")]
    tokens = [t for t in tokens if t]
    return tokens or DEFAULT_METRICS.copy()


def _thresholds_from_args_cfg(args, cfg) -> Dict[str, float]:
    """
    Arma el mapa de umbrales usando prioridad:
      flag específico -> YAML -> flag global --threshold -> 10.0
    """
    def pick(specific_key: str, yaml_key: str) -> float:
        if getattr(args, specific_key) is not None:
            return float(getattr(args, specific_key))
        if cfg.get(yaml_key) is not None:
            return float(cfg.get(yaml_key))
        if args.threshold is not None:
            return float(args.threshold)
        return 10.0

    return {
        "latencia": pick("th_lat", "general.threshold_pct_latencia"),
        "snr_h":   pick("th_snrh", "general.threshold_pct_snr_h"),
        "snr_v":   pick("th_snrv", "general.threshold_pct_snr_v"),
        "rx":      pick("th_rx", "general.threshold_pct_rx"),
    }


def _mode_problematic_from_args_cfg(args, cfg) -> str:
    return args.mode_problematic or cfg.get("general.problematic_mode", "observe_plus_critical")


def _fetch_stats_for_metrics(api: API, metrics: List[str], start_date: str, end_date: str) -> Dict[str, List[dict]]:
    """
    Llama a la API por cada métrica seleccionada.
    Espera que API tenga métodos:
      - get_latencia_stats
      - get_snr_h_stats
      - get_snr_v_stats
      - get_rx_stats
    Todos con firma (start_date, end_date) y retorno List[Dict].
    """
    out: Dict[str, List[dict]] = {}
    for m in metrics:
        try:
            if m == "latencia":
                out[m] = api.get_latencia_stats(start_date, end_date)  # antes: get_stats
            elif m == "snr_h":
                out[m] = api.get_snr_h_stats(start_date, end_date)
            elif m == "snr_v":
                out[m] = api.get_snr_v_stats(start_date, end_date)
            elif m == "rx":
                out[m] = api.get_rx_stats(start_date, end_date)
            else:
                print(f"⚠️ Métrica desconocida ignorada: {m}")
        except Exception as e:
            print(f"❌ Error obteniendo datos de '{m}': {e}")
            out[m] = []
    return out


def run_once_mail(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    horas = args.hours or int(cfg.get("general.default_hours_back", 12))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")
    metrics = _parse_metric_list(args.metric)
    thresholds = _thresholds_from_args_cfg(args, cfg)
    mode_problematic = _mode_problematic_from_args_cfg(args, cfg)

    start_date, end_date = _date_range(horas)
    stats_by_metric = _fetch_stats_for_metrics(api, metrics, start_date, end_date)

    if args.dry_run:
        print("🧪 DRY-RUN mail")
        print(f"Empresa: {empresa} | Horas: {horas} | Métricas: {metrics} | Modo: {mode_problematic}")
        print(f"Thresholds: { {k: thresholds[k] for k in metrics} }")
        for m in metrics:
            print(f"  - {m}: {len(stats_by_metric.get(m, []))} filas")
        return 0

    ms = MailService(args.config)

    # En modo simple: solo intro unificada (sin tablas).
    # En modo full: intro + tablas por cada métrica seleccionada.
    if args.full:
        ok = getattr(ms, "enviar_reporte_multi")(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            prompt_path=args.prompt,
        )
    else:
        ok = getattr(ms, "enviar_reporte_simple_multi")(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            prompt_path=args.prompt,
        )
    return 0 if ok else 1


def run_once_whatsapp(args) -> int:
    cfg = load_config(args.config)
    api = API(args.config)

    horas = args.hours or int(cfg.get("general.default_hours_back", 12))
    empresa = args.empresa or cfg.get("empresas.default.nombre_corto", "Cliente")
    group = args.group or "test"
    metrics = _parse_metric_list(args.metric)
    thresholds = _thresholds_from_args_cfg(args, cfg)
    mode_problematic = _mode_problematic_from_args_cfg(args, cfg)

    start_date, end_date = _date_range(horas)
    stats_by_metric = _fetch_stats_for_metrics(api, metrics, start_date, end_date)

    if args.dry_run:
        print("🧪 DRY-RUN whatsapp")
        print(f"Empresa: {empresa} | Horas: {horas} | Grupo: {group}")
        print(f"Métricas: {metrics} | Modo: {mode_problematic}")
        print(f"Thresholds: { {k: thresholds[k] for k in metrics} }")
        for m in metrics:
            print(f"  - {m}: {len(stats_by_metric.get(m, []))} filas")
        return 0

    ws = WhatsAppService(args.config)

    # En WhatsApp: intro unificada, sin tablas (full no cambia el contenido).
    if args.full:
        res = getattr(ws, "enviar_reporte_multi")(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            group_key=group,
            timeout=args.timeout,
            prompt_path=args.prompt,
        )
    else:
        res = getattr(ws, "enviar_reporte_simple_multi")(
            empresa=empresa,
            horas=horas,
            stats_by_metric=stats_by_metric,
            metrics=metrics,
            thresholds=thresholds,
            mode_problematic=mode_problematic,
            group_key=group,
            timeout=args.timeout,
            prompt_path=args.prompt,
        )

    if not res:
        print("❌ No se envió ningún mensaje")
        return 1
    fails = [k for k, v in res.items() if not v]
    if fails:
        print(f"⚠️ Fallaron {len(fails)} destinatarios: {', '.join(fails)}")
    return 0


def run_loop(args) -> int:
    """
    Bucle simple para ejecutar cada N horas (por defecto 8).
    Recomendación prod: usar cron/systemd, esto es un MVP.
    """
    import time

    every_h = args.every_h or 8
    print(f"⏱️ Ejecutando cada {every_h} horas. Ctrl+C para salir.")
    while True:
        try:
            if args.mode == "mail":
                run_once_mail(args)
            else:
                run_once_whatsapp(args)
        except Exception as e:
            print(f"❌ Error en ejecución: {e}")
        time.sleep(every_h * 3600)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="smartlink-notificaciones",
        description="Envío de reportes Smartlink por correo y WhatsApp (últimas N horas).",
    )
    sub = p.add_subparsers(dest="cmd")

    # --- argumentos comunes a mail/whatsapp/loop ---
    def add_common(sp: argparse.ArgumentParser, include_group: bool = False):
        sp.add_argument("--empresa", help="Empresa (fallback al YAML)")
        sp.add_argument("--hours", type=int, help="Horas hacia atrás (default del YAML)")
        sp.add_argument("--config", help="Ruta a configNotificaciones.yml")
        sp.add_argument("--dry-run", action="store_true", help="Simular sin enviar")

        sp.add_argument("--full", action="store_true", help="(mail) agrega tablas; en WhatsApp no cambia contenido")
        sp.add_argument("--prompt", help="Ruta a archivo de texto con prompt personalizado para IA (opcional)")

        # Métricas
        sp.add_argument(
            "--metric",
            nargs="+",
            help="Lista de métricas a evaluar. Ej: --metric [rx, snr_h]  o  --metric latencia snr_h",
        )

        # Thresholds (específicos + global)
        sp.add_argument("--threshold", type=float, help="Umbral % global por defecto (fallback si no hay específicos).")
        sp.add_argument("--th-lat", type=float, help="Umbral % para latencia.")
        sp.add_argument("--th-snrh", type=float, help="Umbral % para SNR-H.")
        sp.add_argument("--th-snrv", type=float, help="Umbral % para SNR-V.")
        sp.add_argument("--th-rx", type=float, help="Umbral % para RX.")

        # Modo de cómputo del 'problemático'
        sp.add_argument(
            "--mode-problematic",
            choices=["critical_only", "observe_plus_critical"],
            help="Cómo computar % problemático (default: observe_plus_critical).",
        )

        if include_group:
            sp.add_argument("--group", help="Clave del grupo en whatsapp.mudslide.groups (p.e. collahuasi/test)")
            sp.add_argument("--timeout", type=int, default=60, help="Timeout por envío (seg)")

    # mail
    mail = sub.add_parser("mail", help="Enviar reporte por correo (una vez)")
    add_common(mail, include_group=False)
    mail.set_defaults(func=run_once_mail)

    # whatsapp
    wa = sub.add_parser("whatsapp", help="Enviar reporte por WhatsApp (una vez)")
    add_common(wa, include_group=True)
    wa.set_defaults(func=run_once_whatsapp)

    # loop
    loop = sub.add_parser("loop", help="Bucle que envía cada N horas (default 8)")
    loop.add_argument("mode", choices=["mail", "whatsapp"], help="Qué enviar en el loop")
    loop.add_argument("--every-h", type=int, default=8, help="Cada cuántas horas ejecutar")
    add_common(loop, include_group=True)
    loop.set_defaults(func=run_loop)

    # show-config
    show = sub.add_parser("show-config", help="Mostrar configuración efectiva")
    show.add_argument("--config", help="Ruta a configNotificaciones.yml")
    show.set_defaults(func=lambda a: (print(load_config(a.config).raw), 0)[1])

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
