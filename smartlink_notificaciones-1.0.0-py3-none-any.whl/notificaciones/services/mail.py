# src/notificaciones/services/mail.py
# -*- coding: utf-8 -*-

from __future__ import annotations

import os
import smtplib
from typing import List, Dict, Optional, Tuple

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from notificaciones.core.config import load_config
from notificaciones.core.ai import get_openai_client, mensaje_chat_gpt

DEFAULT_THRESHOLD_CRITICO = 10.0
MAX_CRITICOS = 5

# -------------------- helpers básicos --------------------

def _cap(s: Optional[str], default: str = "Cliente") -> str:
    return (s or default).capitalize()

def _fnum(x, dflt=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return dflt

def _smtp_params(cfg) -> Tuple[str, int, str, str, List[str], List[str]]:
    server = cfg.get("email.smtp_server", "smtp.gmail.com")
    port = int(cfg.get("email.smtp_port", cfg.get("email.smtp_puerto", 587)))
    user = cfg.get("email.remitente")
    pwd = cfg.get("email.smtp_password")
    to = cfg.get("email.destinatarios", []) or []
    cc = cfg.get("email.cc", cfg.get("email.con_copia", [])) or []
    return server, port, user, pwd, to, cc

def _subject_from_cfg(cfg, empresa: str) -> str:
    tpl = cfg.get("mensajes.email_subject", "Reporte del turno - {Empresa}")
    Empresa = _cap(empresa)
    return tpl.format(empresa=empresa, Empresa=Empresa)

def _send_html(cfg, subject: str, html: str) -> bool:
    server, port, user, pwd, to, cc = _smtp_params(cfg)
    if not (user and pwd and to):
        print("❌ Config de correo incompleta (remitente/clave/destinatarios).")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)

    msg.attach(MIMEText(html, "html", "utf-8"))

    try:
        with smtplib.SMTP(server, port, timeout=60) as s:
            s.starttls()
            s.login(user, pwd)
            s.sendmail(user, to + cc, msg.as_string())
        print(f"✅ Correo enviado a: {len(to)} destinatarios (+{len(cc)} CC)")
        return True
    except Exception as e:
        print(f"❌ Error enviando correo: {e}")
        return False

# -------------------- mapeos por métrica --------------------

METRIC_LABEL = {
    "latencia": "Latencia",
    "snr_h": "SNR-H",
    "snr_v": "SNR-V",
    "rx": "RX",
}

METRIC_UNITS = {
    "latencia": "ms",
    "snr_h": "dB",
    "snr_v": "dB",
    "rx": "dBm",
}

def _metric_fields(metric: str) -> Dict[str, str]:
    """
    Nombres de campos esperados en los datos devueltos por la API por métrica.
    """
    if metric == "latencia":
        return {
            "avg": "promedio_latencia",
            "max": "max_latencia",
            "min": "min_latencia",
            "obs": "latencia_100_200",     # recuento intervalos 100–200 ms
            "crit": "latencia_mayor_200",  # recuento >200 ms
            "pct": "porcentaje_latencia_alta",
        }
    if metric == "snr_h":
        return {
            "avg": "promedio_snr_h",
            "max": "max_snr_h",
            "min": "min_snr_h",
            "obs": "count_observe",
            "crit": "count_critical",
            "valid": "count_valid",
        }
    if metric == "snr_v":
        return {
            "avg": "promedio_snr_v",
            "max": "max_snr_v",
            "min": "min_snr_v",
            "obs": "count_observe",
            "crit": "count_critical",
            "valid": "count_valid",
        }
    if metric == "rx":
        return {
            "avg": "promedio_rx",
            "max": "max_rx",
            "min": "min_rx",
            "obs": "count_observe",
            "crit": "count_critical",
            "valid": "count_valid",
        }
    return {}

# -------------------- cómputo de % problemático --------------------

def _problematic_pct(metric: str, row: Dict, mode: str) -> float:
    f = _metric_fields(metric)
    # Latencia: viene precomputado como porcentaje
    if metric == "latencia":
        return _fnum(row.get(f.get("pct"), 0.0))

    # SNR/RX: calcular desde conteos
    valid = _fnum(row.get(f.get("valid"), 0.0))
    obs = _fnum(row.get(f.get("obs"), 0.0))
    crit = _fnum(row.get(f.get("crit"), 0.0))
    if valid <= 0:
        return 0.0
    if mode == "critical_only":
        num = crit
    else:  # observe_plus_critical
        num = obs + crit
    return (num * 100.0) / valid

def _severity_key(metric: str, row: Dict) -> float:
    """
    Clave secundaria para ordenar si hay empate de % problemático:
    - latencia: mayor promedio es peor
    - SNR: menor promedio (dB) es peor -> usamos negativo
    - RX: más negativo es peor -> promedio más bajo (más negativo) es peor -> usamos -avg
    """
    f = _metric_fields(metric)
    avg = _fnum(row.get(f.get("avg")))
    if metric == "latencia":
        return avg
    if metric in ("snr_h", "snr_v"):
        return -avg
    if metric == "rx":
        return -avg
    return 0.0

def _top_problematic(stats_by_metric: Dict[str, List[Dict]], metrics: List[str],
                     thresholds: Dict[str, float], mode_problematic: str) -> List[Dict]:
    """
    Mezcla todas las métricas y devuelve hasta MAX_CRITICOS con mayor % problemático.
    Cada item: {'metric', 'row', 'pct'}
    """
    items: List[Dict] = []
    for m in metrics:
        for row in (stats_by_metric.get(m) or []):
            pct = _problematic_pct(m, row, mode_problematic)
            if pct >= float(thresholds.get(m, DEFAULT_THRESHOLD_CRITICO)):
                items.append({"metric": m, "row": row, "pct": pct})
    items.sort(key=lambda x: (x["pct"], _severity_key(x["metric"], x["row"])), reverse=True)
    return items[:MAX_CRITICOS]

# -------------------- render: intro y tablas --------------------

def _intro_html(empresa: str, items: List[Dict], metrics: List[str]) -> str:
    """
    Intro unificada. Si no hay items, mensaje estándar por las métricas seleccionadas.
    """
    Empresa = _cap(empresa)
    if not items:
        # "Equipos con <Métricas> dentro del rango estándar Operacional."
        labels = ", ".join(METRIC_LABEL.get(m, m) for m in metrics)
        return (
            f"<h2>Reporte del turno - {Empresa}</h2>"
            f"<p>Equipos con {labels} dentro del rango estándar Operacional.</p>"
        )

    lines = [f"<h2>Reporte del turno - {Empresa}</h2>", "<p>Equipos con condiciones a observar:</p>", "<ul>"]
    for it in items:
        m = it["metric"]
        row = it["row"]
        label = METRIC_LABEL.get(m, m)
        units = METRIC_UNITS.get(m, "")
        f = _metric_fields(m)

        tag = row.get("tag") or row.get("ip") or ""
        ip = row.get("ip") or ""
        mx = _fnum(row.get(f.get("max")))
        pr = _fnum(row.get(f.get("avg")))
        marca = row.get("marca") or ""
        tipo = row.get("tipo") or ""

        # • Tag (IP) — [Métrica] Máx: X unidad | Prom: Y unidad | Marca: M | Tipo: T
        lines.append(
            f"<li><strong>{tag}</strong> ({ip}) — "
            f"[{label}] Máx: {mx:.1f} {units} | Prom: {pr:.1f} {units} | Marca: {marca} | Tipo: {tipo}</li>"
        )
    lines.append("</ul>")
    return "\n".join(lines)

def _table_html_for_metric(metric: str, data: List[Dict]) -> str:
    label = METRIC_LABEL.get(metric, metric)
    units = METRIC_UNITS.get(metric, "")
    f = _metric_fields(metric)

    # Definir columnas por métrica
    if metric == "latencia":
        headers = [
            ("tag", "Tag"),
            ("ip", "IP"),
            (f["avg"], f"Promedio ({units})"),
            (f["max"], f"Máximo ({units})"),
            (f["min"], f"Mínimo ({units})"),
            (f["obs"], "100–200 ms"),
            (f["crit"], ">200 ms"),
            ("marca", "Marca"),
            ("tipo", "Tipo"),
        ]
    elif metric in ("snr_h", "snr_v"):
        headers = [
            ("tag", "Tag"),
            ("ip", "IP"),
            (f["avg"], f"Promedio ({units})"),
            (f["max"], f"Máximo ({units})"),
            (f["min"], f"Mínimo ({units})"),
            (f["obs"], "En observación"),
            (f["crit"], "Crítico"),
            ("marca", "Marca"),
            ("tipo", "Tipo"),
        ]
    else:  # rx
        headers = [
            ("tag", "Tag"),
            ("ip", "IP"),
            (f["avg"], f"Promedio ({units})"),
            (f["max"], f"Máximo ({units})"),
            (f["min"], f"Mínimo ({units})"),
            (f["obs"], "En observación"),
            (f["crit"], "Crítico"),
            ("marca", "Marca"),
            ("tipo", "Tipo"),
        ]

    def fmt_cell(k: str, v):
        if v is None:
            return ""
        try:
            # numéricos principales a 1 decimal
            if k in {f["avg"], f["max"], f["min"]}:
                return f"{float(v):.1f}"
            # contadores como enteros
            if k in {f.get("obs"), f.get("crit")}:
                return f"{int(float(v))}"
        except Exception:
            return v
        return v

    rows = ""
    for e in (data or []):
        tds = "".join(
            f"<td style='padding:6px 8px;border-bottom:1px solid #eee'>{fmt_cell(k, e.get(k))}</td>"
            for k, _ in headers
        )
        rows += f"<tr>{tds}</tr>"

    table = (
        f"<h3>{label}</h3>"
        "<table style='width:100%;border-collapse:collapse;font-size:13px'>"
        "<thead><tr>" +
        "".join(f"<th style='text-align:left;padding:8px;border-bottom:2px solid #ddd'>{h}</th>" for _, h in headers) +
        "</tr></thead>"
        f"<tbody>{rows}</tbody></table>"
    )
    return table

# -------------------- IA opcional (solo para parafrasear intro) --------------------

def _intro_with_ai(empresa: str, items: List[Dict], metrics: List[str], prompt_path: Optional[str]) -> str:
    """
    Si hay prompt y OpenAI, parafrasea la intro (sin inventar datos).
    Si no, devuelve cadena vacía para que se use la intro determinista.
    """
    if not prompt_path or not os.path.isfile(prompt_path):
        return ""

    client = get_openai_client()
    if not client:
        return ""

    datos = {
        "empresa": _cap(empresa),
        "metrics": [METRIC_LABEL.get(m, m) for m in metrics],
        # Simplificamos los items para IA
        "items": [
            {
                "metric": METRIC_LABEL.get(it["metric"], it["metric"]),
                "tag": it["row"].get("tag") or it["row"].get("ip"),
                "ip": it["row"].get("ip"),
                "promedio": _fnum(it["row"].get(_metric_fields(it["metric"]).get("avg"))),
                "maximo": _fnum(it["row"].get(_metric_fields(it["metric"]).get("max"))),
                "marca": it["row"].get("marca"),
                "tipo": it["row"].get("tipo"),
                "unidad": METRIC_UNITS.get(it["metric"], ""),
            }
            for it in items
        ],
    }

    with open(prompt_path, "r", encoding="utf-8") as f:
        user_prompt = f.read()

    # Prompt estricto para evitar alucinaciones y mantener formato simple
    system = (
        "Eres un asistente técnico que redacta una INTRO breve en HTML (<p> y <ul><li>) "
        "para un correo de reporte de turno en una faena minera. "
        "No inventes valores ni porcentajes; usa SOLO lo que viene en el JSON. "
        "No agregues tablas, ni títulos adicionales; no repitas el heading principal. "
        "Usa unidades (ms, dB, dBm) según 'unidad'. Evita palabras 'alarma' o 'alerta'; "
        "usa un tono sobrio (p.ej., 'condiciones a observar'). HC-GROUP siempre en mayúsculas."
    )

    prompt = (
        f"{user_prompt}\n\n"
        "FORMATO ESTRICTO:\n"
        " - Si 'items' está vacío, escribe: \"Equipos con {', '.join(metrics)} dentro del rango estándar Operacional.\"\n"
        " - Si NO está vacío, escribe una breve frase y una lista con ítems como: "
        "'• <Tag/IP> (<IP>) — [<Métrica>] Máx: <X> <unidad> | Prom: <Y> <unidad> | Marca: <M> | Tipo: <T>'\n"
        " - No incluyas porcentajes, URLs ni bloques de código.\n\n"
        f"JSON:\n{datos}\n"
        "Devuelve solo HTML (sin ```)."
    )

    html = mensaje_chat_gpt(
        client,
        prompt,
        system=system,
        temperature=0.2,
        max_tokens=400,
        char_limit=None,
        is_windows=False,
    )
    return html.strip()

# -------------------- Servicio de correo (multi-métrica) --------------------

class MailService:
    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)

    def enviar_reporte_simple_multi(
        self,
        empresa: str,
        horas: int,  # no usado, mantenido por compatibilidad
        stats_by_metric: Dict[str, List[Dict]],
        metrics: List[str],
        thresholds: Dict[str, float],
        mode_problematic: str = "observe_plus_critical",
        prompt_path: Optional[str] = None,
    ) -> bool:
        """
        Correo NORMAL: solo intro unificada (sin tablas).
        """
        top = _top_problematic(stats_by_metric, metrics, thresholds, mode_problematic)

        # IA opcional para parafrasear la intro; si falla -> determinista
        intro_ai = _intro_with_ai(empresa, top, metrics, prompt_path) if top or prompt_path else ""
        intro = intro_ai if intro_ai else _intro_html(empresa, top, metrics)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"{intro}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )
        subject = _subject_from_cfg(self.cfg, empresa)
        return _send_html(self.cfg, subject, html)

    def enviar_reporte_multi(
        self,
        empresa: str,
        horas: int,  # no usado
        stats_by_metric: Dict[str, List[Dict]],
        metrics: List[str],
        thresholds: Dict[str, float],
        mode_problematic: str = "observe_plus_critical",
        prompt_path: Optional[str] = None,
    ) -> bool:
        """
        Correo FULL: intro + tablas por cada métrica seleccionada.
        """
        top = _top_problematic(stats_by_metric, metrics, thresholds, mode_problematic)

        # IA opcional para parafrasear la intro; si falla -> determinista
        intro_ai = _intro_with_ai(empresa, top, metrics, prompt_path) if top or prompt_path else ""
        intro = intro_ai if intro_ai else _intro_html(empresa, top, metrics)

        tables = []
        for m in metrics:
            data = stats_by_metric.get(m) or []
            tables.append(_table_html_for_metric(m, data))
        tables_html = "".join(tables)

        html = (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"{intro}"
            f"{tables_html}"
            "<p style='color:#666'>Este es un reporte automático de Smartlink - HC-GROUP.</p>"
            "</body></html>"
        )
        subject = _subject_from_cfg(self.cfg, empresa)
        return _send_html(self.cfg, subject, html)
