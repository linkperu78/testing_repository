import argparse
import sys
from datetime import datetime, timedelta


def create_parser():
    """Crea el parser principal de argumentos"""
    # Fechas por defecto
    now = datetime.now()
    one_day_ago = now - timedelta(days=1)
    
    parser = argparse.ArgumentParser(
        prog='smartlink-forecast',
        description="SmartLink Forecast - Sistema de prediccion para equipos de telecomunicaciones",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  # Entrenar modelos con configuracion por defecto (1 dia atras, 1 min, snr_v,snr_h,rx)
  smartlink-forecast getmodels --marca Cambium
  
  # Entrenar con parametros especificos
  smartlink-forecast getmodels --marca Mimosa --start_date "2025-01-01 00:00:00" --intervalo 15
  
  # Predecir con configuracion por defecto
  smartlink-forecast predict --marca Cambium
  
  # Predecir tipos especificos e insertar en BD
  smartlink-forecast predict --marca Mimosa --forecast_type snr_v,snr_h --insert true
        """
    )
    
    # Subcomandos
    subparsers = parser.add_subparsers(dest='command', help='Comandos disponibles')
    
    # ==================== COMANDO GETMODELS ====================
    getmodels_parser = subparsers.add_parser(
        'getmodels',
        help='Entrenar modelos de prediccion',
        description='Entrena modelos NeuralProphet usando datos historicos'
    )
    
    getmodels_parser.add_argument(
        '--marca',
        choices=['Cambium', 'Mimosa'],
        required=True,
        help='Marca de equipos (Cambium o Mimosa)'
    )
    getmodels_parser.add_argument(
        '--start_date',
        default=one_day_ago.strftime("%Y-%m-%d %H:%M:%S"),
        help=f'Fecha inicio (YYYY-MM-DD HH:MM:SS). Defecto: {one_day_ago.strftime("%Y-%m-%d %H:%M:%S")}'
    )
    getmodels_parser.add_argument(
        '--end_date', 
        default=now.strftime("%Y-%m-%d %H:%M:%S"),
        help=f'Fecha fin (YYYY-MM-DD HH:MM:SS). Defecto: {now.strftime("%Y-%m-%d %H:%M:%S")}'
    )
    getmodels_parser.add_argument(
        '--intervalo',
        type=int,
        default=1,
        help='Intervalo de agregacion en minutos (1, 15, 60). Defecto: 1'
    )
    getmodels_parser.add_argument(
        '--forecast_type',
        default='snr_v,snr_h,rx',
        help='Tipos de forecast separados por coma. Defecto: snr_v,snr_h,rx'
    )
    getmodels_parser.add_argument(
        '--zone',
        help='Zona horaria (ej: America/Santiago). Opcional'
    )
    getmodels_parser.add_argument(
        '--limit',
        type=int,
        default=20000,
        help='Maximo registros por consulta API. Defecto: 20000'
    )
    getmodels_parser.add_argument(
        '--offset',
        type=int,
        default=0,
        help='Offset en consulta API. Defecto: 0'
    )
    
    # ==================== COMANDO PREDICT ====================
    predict_parser = subparsers.add_parser(
        'predict',
        help='Generar predicciones usando modelos entrenados',
        description='Genera predicciones con modelos previamente entrenados'
    )
    
    predict_parser.add_argument(
        '--marca',
        choices=['Cambium', 'Mimosa'],
        required=True,
        help='Marca de equipos (Cambium o Mimosa)'
    )
    predict_parser.add_argument(
        '--forecast_type',
        default='snr_v,snr_h,rx',
        help='Tipos de forecast separados por coma. Defecto: snr_v,snr_h,rx'
    )
    predict_parser.add_argument(
        '--insert',
        choices=['true', 'false'],
        default='false',
        help='Insertar predicciones en BD. Defecto: false'
    )
    predict_parser.add_argument(
        '--limit',
        type=int,
        default=1000,
        help='Maximo registros por consulta API. Defecto: 1000'
    )
    predict_parser.add_argument(
        '--offset',
        type=int,
        default=0,
        help='Offset en consulta API. Defecto: 0'
    )
    predict_parser.add_argument(
        '--last_hours',
        type=int,
        default=5,
        help='Horas historicas para prediccion. Defecto: 5'
    )
    predict_parser.add_argument(
        '--show_predictions',
        action='store_true',
        help='Mostrar predicciones en consola. Por defecto: false'
    )
    
    return parser


def main():
    """Punto de entrada principal del CLI"""
    parser = create_parser()
    args = parser.parse_args()
    
    # Validar que se especifico un comando
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Procesar forecast_types como lista
    if hasattr(args, 'forecast_type'):
        args.forecast_types = [ft.strip() for ft in args.forecast_type.split(',')]
        
        # Validar tipos de forecast
        valid_types = ['snr_v', 'snr_h', 'rx', 'per', 'airrx']
        for ft in args.forecast_types:
            if ft not in valid_types:
                print(f"Error: '{ft}' no es un tipo de forecast valido.")
                print(f"Tipos validos: {', '.join(valid_types)}")
                sys.exit(1)
    
    # Ejecutar comando
    if args.command == 'getmodels':
        run_getmodels(args)
    elif args.command == 'predict':
        run_predict(args)
    else:
        parser.print_help()
        sys.exit(1)


def run_getmodels(args):
    """Ejecuta el entrenamiento de modelos"""
    print(f"Entrenando modelos...")
    print(f"  Marca: {args.marca}")
    print(f"  Periodo: {args.start_date} -> {args.end_date}")
    print(f"  Intervalo: {args.intervalo} min")
    print(f"  Tipos: {', '.join(args.forecast_types)}")
    
    # Importar y ejecutar getmodels
    try:
        from forecast import getmodels
        getmodels.main(args)
    except ImportError as e:
        print(f"Error importando getmodels: {e}")
        sys.exit(1)


def run_predict(args):
    """Ejecuta la generacion de predicciones"""
    print(f"Generando predicciones...")
    print(f"  Marca: {args.marca}")
    print(f"  Tipos: {', '.join(args.forecast_types)}")
    print(f"  Insertar en BD: {args.insert}")
    print(f"  Horas historicas: {args.last_hours}")
    
    # Importar y ejecutar predict
    try:
        from forecast import predict
        predict.main(args)
    except ImportError as e:
        print(f"Error importando predict: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()