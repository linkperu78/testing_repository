import sys
import os
import pandas as pd
import warnings
import argparse
import pickle
import traceback
import logging
from datetime import datetime
from pathlib import Path
from datetime import datetime, timedelta

# Imports de nuestros modulos
from forecast.config import load_config
from forecast.utils.extraction import get_all_equipment_data, post_predictions
from forecast.utils.transformation import prepare_dataframe_for_training, prepare_prediction_data
from forecast.utils.helpers import (
    forecast_setting, get_model_path, format_prediction_result,
    print_status, validate_forecast_types, get_valid_forecast_types
)

warnings.filterwarnings("ignore")


def load_model(model_path):
    """
    Carga un modelo NeuralProphet desde archivo
    
    Args:
        model_path: Ruta al archivo .pkl del modelo
        
    Returns:
        Modelo NeuralProphet cargado o None si hay error
    """
    try:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        model.restore_trainer()
        return model
    except FileNotFoundError:
        print_status(f"Modelo no encontrado: {model_path}", 'warning')
        return None
    except Exception as e:
        print_status(f"Error cargando modelo {model_path}: {e}", 'error')
        return None


def generate_prediction_for_ip(df_ip, ip, forecast_name, marca, last_hours=5, base_path=None):
    """
    Genera prediccion para una IP especifica
    
    Args:
        df_ip: DataFrame con datos de la IP
        ip: IP del equipo
        forecast_name: Tipo de forecast (snr_v, snr_h, rx, per)
        marca: Marca del equipo (Cambium, Mimosa)
        last_hours: Numero de horas historicas para prediccion
        base_path: Ruta base de modelos
        
    Returns:
        Diccionario con resultado de prediccion o None si hay error
    """
    print_status(f"Generando prediccion para IP: {ip} - Tipo: {forecast_name}")
    
    try:
        # Cargar modelo
        model_path = get_model_path(ip, forecast_name, marca, base_path)
        model = load_model(model_path)
        
        if model is None:
            return None
        
        # Preparar datos para prediccion
        df_processed = prepare_prediction_data(df_ip, last_hours)
        
        # Verificar que hay suficientes horas
        if len(df_processed) != last_hours:
            print_status(f"Error en IP {ip}: se encontraron {len(df_processed)} horas, se esperaban {last_hours}", 'warning')
            return None
        
        # Generar predicciones
        future = model.make_future_dataframe(df_processed)
        forecast = model.predict(future, decompose=False)
        
        # Extraer resultado
        prediction_value = float(forecast["yhat3"].loc[forecast["yhat3"].first_valid_index()])
        prediction_date = str(forecast["ds"].loc[forecast["yhat3"].first_valid_index()])
        
        print_status(f"Prediccion para {ip}: {prediction_value} en {prediction_date}")
        
        # Formatear resultado
        result = format_prediction_result(ip, forecast_name, prediction_value, prediction_date)
        
        return result
        
    except Exception as e:
        print_status(f"Error generando prediccion para IP {ip}: {e}", 'error')
        return None


def predict_for_marca(marca, forecast_types, insert_db, limit, offset, last_hours, base_path=None):
    """
    Genera predicciones para una marca especifica
    
    Args:
        marca: Marca de equipos ('Cambium' o 'Mimosa')
        forecast_types: Lista de tipos de forecast
        insert_db: Si True, inserta predicciones en BD
        limit: Limite de registros por consulta
        offset: Offset de registros
        last_hours: Horas historicas para prediccion
        base_path: Ruta base para modelos
        
    Returns:
        Lista de predicciones generadas
    """
    print_status(f"Iniciando predicciones para marca: {marca}")
    
    # Cargar configuracion
    config = load_config()
    
    all_predictions = []
    
    # Procesar cada tipo de forecast
    for forecast_type in forecast_types:
        print_status(f"Procesando forecast: {forecast_type}")
        
        try:
            # Obtener configuracion del forecast
            forecast_name, _ = forecast_setting(forecast_type.upper())
            
            # Obtener datos recientes (sin fechas especificas para prediccion)
            now = datetime.now()
            hours_ago = now - timedelta(hours=6)
            print_status(f"Obteniendo datos recientes para {marca} entre {hours_ago} y {now} (ultimas 6 horas)")
            
            raw_data = get_all_equipment_data(config, marca, 
                                            start_date=hours_ago.strftime("%Y-%m-%dT%H:%M:%S"), end_date=now.strftime("%Y-%m-%dT%H:%M:%S"), 
                                            limit=limit, offset=offset)
            
            if not raw_data:
                print_status(f"No se obtuvieron datos para {marca} - {forecast_type}", 'warning')
                continue
            
            # Preparar DataFrame
            inventory_type = None
            if marca == 'Mimosa':
                inventory_type = 'PMP-AP'  # Simplificacion, se podria mejorar
            
            df = prepare_dataframe_for_training(raw_data, forecast_name, marca, inventory_type)
            
            if df.empty:
                print_status(f"No hay datos validos para procesar - {marca} - {forecast_type}", 'warning')
                continue
            
            # Agrupar por IP y generar predicciones
            df_grouped = df.groupby('ip')
            ips = list(df_grouped.groups.keys())
            
            print_status(f"Generando predicciones para {len(ips)} IPs")
            
            forecast_predictions = []
            
            for i, ip in enumerate(ips, 1):
                print_status(f"Procesando IP {i}/{len(ips)}: {ip}")
                
                # Obtener datos de la IP y eliminar duplicados
                df_ip = df_grouped.get_group(ip)
                df_ip = df_ip.drop_duplicates(subset=['ds'])
                
                # Generar prediccion
                prediction = generate_prediction_for_ip(
                    df_ip, ip, forecast_name, marca, last_hours, base_path
                )
                
                if prediction:
                    forecast_predictions.append(prediction)
            
            all_predictions.extend(forecast_predictions)
            print_status(f"Predicciones generadas para {forecast_type}: {len(forecast_predictions)}", 'success')
            
        except Exception as e:
            print_status(f"Error procesando forecast {forecast_type}: {e}", 'error')
            continue
    
    # Insertar en BD si se solicita
    if insert_db and all_predictions:
        print_status("Insertando predicciones en base de datos...")
        success = post_predictions(config, all_predictions)
        if success:
            print_status("Predicciones insertadas correctamente", 'success')
        else:
            print_status("Error insertando predicciones", 'error')
    
    return all_predictions


def setup_logging(marca, forecast_types, base_path=None):
    """
    Configura logging para las predicciones
    
    Args:
        marca: Marca de equipos
        forecast_types: Lista de tipos de forecast
        base_path: Ruta base para logs
    """
    if base_path:
        log_dir = Path(base_path) / marca.lower()
    else:
        log_dir = Path(__file__).parent / "models" / marca.lower()
    
    log_dir.mkdir(parents=True, exist_ok=True)
    
    log_file = log_dir / f"prediction_{datetime.now().strftime('%Y%m%d')}.log"
    
    logging.basicConfig(
        filename=str(log_file),
        level=logging.INFO,
        format='%(asctime)s:%(levelname)s:%(message)s',
        filemode='a'
    )
    
    logging.info(f"Iniciando predicciones - Marca: {marca}, Tipos: {','.join(forecast_types)}")


def main(args=None):
    """
    Funcion principal para generacion de predicciones
    
    Args:
        args: Argumentos parseados (opcional, para uso desde CLI)
    """
    if args is None:
        # Crear parser solo si no se pasan argumentos
        parser = argparse.ArgumentParser(description="Generar predicciones con modelos NeuralProphet")
        parser.add_argument('--marca', choices=['Cambium', 'Mimosa'], required=True,
                           help='Marca de equipos')
        parser.add_argument('--forecast_type', default='snr_v,snr_h,rx',
                           help='Tipos de forecast separados por coma')
        parser.add_argument('--insert', choices=['true', 'false'], default='false',
                           help='Insertar predicciones en BD')
        parser.add_argument('--limit', type=int, default=1000,
                           help='Limite de registros por consulta')
        parser.add_argument('--offset', type=int, default=0,
                           help='Offset de registros')
        parser.add_argument('--last_hours', type=int, default=5,
                           help='Horas historicas para prediccion')
        parser.add_argument('--model_path', help='Ruta base para modelos (opcional)')
        parser.add_argument('--show_predictions', action='store_true',
                           help='Mostrar predicciones en consola')
        
        args = parser.parse_args()
    
    # Procesar argumentos
    marca = args.marca
    forecast_types = [ft.strip() for ft in args.forecast_type.split(',')]
    insert_db = getattr(args, 'insert', 'false').lower() == 'true'
    limit = getattr(args, 'limit', 1000)
    offset = getattr(args, 'offset', 0)
    last_hours = getattr(args, 'last_hours', 5)
    model_path = getattr(args, 'model_path', None)
    show_predictions = getattr(args, 'show_predictions', False)
    
    # Validaciones
    if not validate_forecast_types(forecast_types):
        print_status("Error: Tipos de forecast invalidos", 'error')
        print_status(f"Tipos validos: {', '.join(get_valid_forecast_types())}", 'info')
        sys.exit(1)
    
    # Configurar logging
    setup_logging(marca, forecast_types, model_path)
    
    # Mostrar informacion
    print_status("=== GENERACION DE PREDICCIONES ===")
    print_status(f"Marca: {marca}")
    print_status(f"Tipos: {', '.join(forecast_types)}")
    print_status(f"Insertar en BD: {insert_db}")
    print_status(f"Horas historicas: {last_hours}")
    print_status(f"Limite: {limit}, Offset: {offset}")
    
    # Ejecutar predicciones
    try:
        predictions = predict_for_marca(marca, forecast_types, insert_db, limit, offset, last_hours, model_path)
        
        if predictions:
            print_status(f"=== PREDICCIONES COMPLETADAS: {len(predictions)} ===", 'success')
            
            if show_predictions or not insert_db:
                print_status("Predicciones generadas:")
                for i, pred in enumerate(predictions, 1):
                    print(f"  {i}. IP: {pred['ip']}, Tipo: {pred['tipo_prediccion']}, "
                          f"Valor: {pred['value']}, Fecha: {pred['fecha_prediccion']}")
        else:
            print_status("No se generaron predicciones", 'warning')
    
    except Exception as e:
        print_status(f"Error en predicciones: {e}", 'error')
        logging.error(f"Error en predicciones: {e}")
        logging.error(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()