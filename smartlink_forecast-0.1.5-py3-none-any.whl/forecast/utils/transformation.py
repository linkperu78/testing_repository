import pandas as pd
import numpy as np
import json
import re
from typing import List, Dict, Any, Optional, Union


def filter_data(sublist: List, snr_type: str) -> List:
    """
    Filtra y procesa datos segun el tipo de SNR o metrica
    
    Args:
        sublist: Lista de datos a filtrar
        snr_type: Tipo de filtro ('AirRx', 'RX', 'V', 'H')
        
    Returns:
        Lista de datos filtrados y procesados
    """
    if snr_type == "AirRx":
        # Postprocesamiento: concatenar ip y oid en una sola columna llamada 'ip'
        processed_list = []
        for result in sublist:
            concatenated_ip = f"{result['IP']}_{result['OID']}_{result['CodeName']}"
            processed_result = {
                'ip': concatenated_ip,
                'ds': result['Datetime'],
                'y': result['Value']
            }
            processed_list.append(processed_result)
        return processed_list
    
    if snr_type == "RX":
        return sublist
    else:
        # Procesar datos V y H
        filtered_list = []
        for item in sublist:
            ip, timestamp, snr_data = item
            match_v = re.search(r'([\d\.]+) V', snr_data)  # Captura numeros decimales
            match_h = re.search(r'([\d\.]+) H', snr_data)  # Captura numeros decimales
            
            if match_v and snr_type == "V":
                snr = float(match_v.group(1))  # Convertir a decimal (float)
            elif match_h and snr_type == "H":
                snr = float(match_h.group(1))  # Convertir a decimal (float)
            else:
                snr = None
                
            filtered_list.append([ip, timestamp, snr])
    
    return filtered_list


def extract_value(column: Any, raw_key: str, mimosa: bool = False, 
                 inventory_type: Optional[str] = None) -> Optional[float]:
    """
    Extrae un valor de un JSON o string JSON, promediando si es una lista
    
    Args:
        column: Columna que contiene el JSON o string JSON
        raw_key: Clave a extraer ('H', 'V', 'rx', 'PER')
        mimosa: Si es True, aplica logica especifica de Mimosa
        inventory_type: Tipo de inventario ('PMP-AP', 'PMP-SM')
        
    Returns:
        Valor extraido o None si no se puede extraer
    """
    if pd.isna(column):  # Si es NaN, devolver None
        return None
    
    try:
        # Si es un string, intenta cargarlo como JSON
        if isinstance(column, str):
            column = json.loads(column)

        # Si es un diccionario, intenta obtener la clave deseada
        if raw_key == "rx" and mimosa:
            key = "H"
        else:
            key = raw_key
            
        if isinstance(column, dict):
            value = column.get(key, None)

            # Si el valor es una lista, calcular el promedio o extraer posicion especifica
            if isinstance(value, list) and len(value) > 0:
                if not mimosa:
                    # Si no es un caso de mimosa, calcular el promedio
                    return sum(value) / len(value)
                else:
                    # Logica especifica para Mimosa
                    if raw_key == "H" or raw_key == "V":
                        if inventory_type == "PMP-AP":
                            return value[5] if len(value) > 5 else None
                        elif inventory_type == "PMP-SM":
                            return value[3] if len(value) > 3 else None
                    elif raw_key == "rx":
                        if inventory_type == "PMP-AP":
                            return value[4] if len(value) > 4 else None
                        elif inventory_type == "PMP-SM":
                            return value[2] if len(value) > 2 else None
                    elif raw_key == "PER":
                        if inventory_type == "PMP-AP":
                            return max(value) if len(value) > 0 else None
                        elif inventory_type == "PMP-SM":
                            return max(value) if len(value) > 0 else None
            
            return value  # Retornar el valor si es un numero
        else:
            return None  # Si no es diccionario, devolver None
            
    except (json.JSONDecodeError, TypeError, ValueError):
        return None  # Si hay error al parsear, devolver None


def agregar_ruido_si_igual(df_group: pd.DataFrame) -> pd.DataFrame:
    """
    Agrega ruido minimo si todos los valores de 'y' son iguales
    
    Args:
        df_group: DataFrame agrupado
        
    Returns:
        DataFrame con ruido agregado si es necesario
    """
    # Verificar si todos los valores de 'y' son iguales
    if df_group['y'].nunique() == 1:
        print("Todos los valores de 'y' son iguales. Agregando ruido...")
        ruido = np.random.normal(0, 1e-6, df_group.shape[0])
        df_group = df_group.copy()
        df_group['y'] = df_group['y'] + ruido
        return df_group
    else:
        print("Los valores de 'y' no son todos iguales. No se agregara ruido.")
        return df_group


def prepare_dataframe_for_training(raw_data: List[Dict], forecast_name: str, 
                                  marca: str, inventory_type: Optional[str] = None) -> pd.DataFrame:
    """
    Prepara un DataFrame a partir de datos raw para entrenamiento
    
    Args:
        raw_data: Lista de diccionarios con datos raw
        forecast_name: Nombre del tipo de forecast ('snr_v', 'snr_h', 'rx', 'per')
        marca: Marca del equipo ('Cambium', 'Mimosa')
        inventory_type: Tipo de inventario para Mimosa ('PMP-AP', 'PMP-SM')
        
    Returns:
        DataFrame preparado para entrenamiento
    """
    df_raw = pd.DataFrame(raw_data)
    if df_raw.empty:
        print("No hay datos para procesar.")
        return pd.DataFrame()

    # Aplicar transformaciones segun la marca
    if marca == 'Cambium':
        df_raw['snr_h'] = df_raw['snr'].apply(lambda x: extract_value(x, 'H'))
        df_raw['snr_v'] = df_raw['snr'].apply(lambda x: extract_value(x, 'V'))
        df_raw['rx'] = df_raw['link_radio'].apply(lambda x: extract_value(x, 'rx'))
        
        # Seleccionar columna de prediccion
        prediction_column = forecast_name
        df = df_raw[['fecha', 'ip', prediction_column]]
        
    elif marca == 'Mimosa':
        df_raw['snr_h'] = df_raw['network'].apply(lambda x: extract_value(x, 'H', True, inventory_type))
        df_raw['snr_v'] = df_raw['network'].apply(lambda x: extract_value(x, 'V', True, inventory_type))
        df_raw['per'] = df_raw['network'].apply(lambda x: extract_value(x, 'PER', True, inventory_type))
        
        # Seleccionar columna de prediccion
        prediction_column = forecast_name
        df = df_raw[['fecha', 'ip', prediction_column]]
    
    else:
        raise ValueError(f"Marca no reconocida: {marca}")

    # Renombrar columnas para NeuralProphet
    df = df.rename(columns={'fecha': 'ds', prediction_column: 'y'})

    # Procesar fechas y datos
    df['ds'] = pd.to_datetime(df['ds'])
    df['ds'] = df['ds'].apply(lambda x: x.replace(second=0, microsecond=0))
    
    # Redondear segun la marca
    if marca == 'Cambium':
        df['ds'] = df['ds'].dt.round('15min')
    elif marca == 'Mimosa':
        df['ds'] = df['ds'].dt.round('1min')
    
    # Convertir valores a numerico
    df['y'] = pd.to_numeric(df['y'], errors='coerce')

    # Filtrar IPs que tengan al menos 10 valores numericos validos (para Mimosa)
    if marca == 'Mimosa':
        df = df.groupby('ip').filter(lambda x: x['y'].notna().sum() >= 10)

    # Imputar valores faltantes
    if df['y'].isna().sum() > 0:
        print(f"Advertencia: {df['y'].isna().sum()} valores no convertibles a numerico. Se imputaran con la media.")
        if marca == 'Cambium':
            df['y'] = df['y'].fillna(df['y'].mean())
        elif marca == 'Mimosa':
            df['y'] = df.groupby('ip')['y'].transform(lambda x: x.fillna(x.mean()))

    return df


def prepare_timeseries_data(df_group: pd.DataFrame, n_forecasts: int, n_lags: int) -> pd.DataFrame:
    """
    Prepara datos de serie temporal para entrenamiento con NeuralProphet
    
    Args:
        df_group: DataFrame agrupado por IP
        n_forecasts: Numero de periodos a predecir
        n_lags: Numero de lags para el modelo
        
    Returns:
        DataFrame preparado para serie temporal
    """
    df_group = df_group.reset_index(drop=True)

    start_date = df_group['ds'].min()
    end_date = df_group['ds'].max()
    print(f"Rango de fechas: {start_date} -> {end_date}")
    
    # Crear rango completo de fechas por minuto
    dall = pd.date_range(start=start_date, end=end_date, freq="1T")
    print(f"Rango completo: {len(dall)} registros")
    
    # Eliminar duplicados
    df_group = df_group.drop_duplicates(subset=['ds', 'ip'], keep='last')
    df_group = df_group.set_index('ds')
    
    # Verificar indices duplicados
    duplicated_index = df_group.index.duplicated(keep=False)
    if duplicated_index.any():
        duplicated_rows = df_group[duplicated_index]
        print("Filas con indices duplicados:")
        print(duplicated_rows)
    
    # Reindexar con rango completo
    df_group = df_group.reindex(dall, method='bfill')
    df_group = df_group.reset_index()
    df_group.rename(columns={"index": "ds"}, inplace=True)
    df_group = df_group[["ds", "y"]]
    
    print(f"Numero de filas en el DataFrame: {len(df_group)}. Suma de N_FORECAST + N_LAGS: {n_forecasts + n_lags}.")
    
    # Agregar ruido si todos los valores son iguales
    df_group = agregar_ruido_si_igual(df_group)
    
    # Validar que hay suficientes datos
    if len(df_group) < n_forecasts + n_lags:
        raise ValueError("Error: No hay suficientes datos para el modelo.")
    
    return df_group


def prepare_prediction_data(df_ip: pd.DataFrame, last_hours: int = 5) -> pd.DataFrame:
    """
    Prepara datos para generar predicciones
    
    Args:
        df_ip: DataFrame con datos de una IP
        last_hours: Numero de horas historicas a usar
        
    Returns:
        DataFrame preparado para prediccion
    """
    # Eliminar duplicados en 'ds', manteniendo el primer valor
    df_processed = df_ip.drop_duplicates(subset=['ds'], keep='first')
    df_processed = df_processed.reset_index()[["ds", "y"]]
    
    # Obtener las ultimas horas
    ultima_fecha = df_processed['ds'].max()
    ultimas_horas = pd.date_range(end=ultima_fecha, periods=last_hours, freq='H')
    df_processed = df_processed[df_processed['ds'].isin(ultimas_horas)]

    # Si no hay suficientes horas, rellenar con la primera hora disponible
    if len(df_processed) < last_hours:
        missing_hours = last_hours - len(df_processed)
        first_row = df_processed.loc[df_processed['ds'].idxmin()].copy()
        
        new_rows = []
        for i in range(missing_hours):
            new_row = first_row.copy()
            new_row['ds'] = new_row['ds'] - pd.Timedelta(hours=i+1)
            new_rows.append(new_row)
        
        df_processed = pd.concat([pd.DataFrame(new_rows), df_processed], ignore_index=True)
        
    # Ordenar por fecha
    df_processed = df_processed.sort_values(by='ds').reset_index(drop=True)
    
    return df_processed


# Para uso como modulo independiente
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Probar funciones de transformacion de datos")
    parser.add_argument('--test', choices=['extract', 'noise', 'prepare'], help='Tipo de test a ejecutar')
    
    args = parser.parse_args()
    
    if args.test == 'extract':
        # Test de extraccion de valores
        test_json = '{"H": [1, 2, 3, 4, 5], "V": [6, 7, 8, 9, 10]}'
        print("Test extract_value:")
        print(f"  JSON: {test_json}")
        print(f"  H promedio: {extract_value(test_json, 'H')}")
        print(f"  V promedio: {extract_value(test_json, 'V')}")
        print(f"  H Mimosa PMP-AP: {extract_value(test_json, 'H', True, 'PMP-AP')}")
        
    elif args.test == 'noise':
        # Test de ruido
        df_test = pd.DataFrame({
            'ds': pd.date_range('2025-01-01', periods=5, freq='H'),
            'y': [10.0, 10.0, 10.0, 10.0, 10.0]  # Todos iguales
        })
        print("Test agregar_ruido_si_igual:")
        print(f"  Antes: {df_test['y'].tolist()}")
        df_with_noise = agregar_ruido_si_igual(df_test)
        print(f"  Despues: {df_with_noise['y'].tolist()}")
        
    elif args.test == 'prepare':
        # Test de preparacion de datos
        print("Test prepare_prediction_data:")
        df_test = pd.DataFrame({
            'ds': pd.date_range('2025-01-01', periods=3, freq='H'),
            'y': [1.0, 2.0, 3.0]
        })
        print(f"  Datos originales: {len(df_test)} filas")
        df_prepared = prepare_prediction_data(df_test, last_hours=5)
        print(f"  Datos preparados: {len(df_prepared)} filas")
        print(f"  Fechas: {df_prepared['ds'].tolist()}")
        
    else:
        print("Uso: python3 -m forecast.utils.transformation --test extract|noise|prepare")